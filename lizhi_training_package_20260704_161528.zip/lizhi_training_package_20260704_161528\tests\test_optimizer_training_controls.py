from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from arena.optimizer import BoundaryOptimizer, EvalResult, OpponentSpec, parse_opponent_spec


class OptimizerTrainingControlsTest(unittest.TestCase):
    def test_opponent_spec_can_pin_params_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            params_path = Path(tmp) / "params.json"
            params_path.write_text(json.dumps({"fresh_weight": 1.5}), encoding="utf-8")

            spec = parse_opponent_spec(f".\\client@{params_path}")

        self.assertEqual(spec.path, Path(".\\client"))
        self.assertEqual(spec.params_path, params_path)
        self.assertEqual(spec.params["fresh_weight"], 1.5)
        self.assertIn("LYCHEE_PARAMS_JSON", spec.env() or {})

    def test_summary_counts_high_score_matches(self) -> None:
        result = EvalResult(
            params={},
            fitness=1.0,
            wins=1,
            losses=0,
            draws=1,
            league_points=4,
            score_margins=[100, 0],
            details=[
                {"candidateScore": 699, "opponentScore": 500, "candidateTaskScore": 90, "candidateDelivered": True},
                {"candidateScore": 700, "opponentScore": 700, "candidateTaskScore": 110, "candidateDelivered": True},
            ],
        )

        summary = result.summary()

        self.assertEqual(summary["score650Matches"], 2)
        self.assertEqual(summary["score700Matches"], 1)
        self.assertEqual(summary["task90Matches"], 2)
        self.assertEqual(summary["task110Matches"], 1)
        self.assertEqual(summary["avgTaskBase"], 100)
        self.assertEqual(summary["candidateId"], "checkpoint")

    def test_summary_breaks_down_results_by_opponent(self) -> None:
        result = EvalResult(
            params={},
            fitness=1.0,
            wins=1,
            losses=1,
            draws=0,
            league_points=3,
            score_margins=[100, -10],
            details=[
                {
                    "opponent": "players/direct_runner",
                    "candidateScore": 700,
                    "opponentScore": 600,
                    "candidateTaskScore": 110,
                    "candidateDelivered": True,
                },
                {
                    "opponent": "players/direct_runner",
                    "candidateScore": 590,
                    "opponentScore": 600,
                    "candidateTaskScore": 75,
                    "candidateDelivered": True,
                },
            ],
            generation=2,
            index=3,
        )

        summary = result.summary()

        self.assertEqual(summary["candidateId"], "G3-C4")
        self.assertEqual(summary["opponentBreakdown"][0]["wins"], 1)
        self.assertEqual(summary["opponentBreakdown"][0]["losses"], 1)
        self.assertEqual(summary["opponentBreakdown"][0]["score700Matches"], 1)
        self.assertEqual(summary["opponentBreakdown"][0]["task90Matches"], 1)

    def test_seed_window_rotates_by_block_not_every_generation(self) -> None:
        opt = BoundaryOptimizer(
            candidate_path=Path("client"),
            opponents=[OpponentSpec(Path("players/direct_runner"))],
            out_dir=Path("runs/test_unused"),
            seeds=[1, 2, 3, 4, 5, 6, 7, 8],
            obstacles=[0],
            population=1,
            generations=1,
            timeout_ms=80,
            rounds=600,
            rng_seed=1,
            seed_window_size=4,
            seed_block_size=3,
            anchor_seed_count=2,
        )

        self.assertEqual(opt.active_seeds_for_generation(0), [1, 2, 3, 4])
        self.assertEqual(opt.active_seeds_for_generation(2), [1, 2, 3, 4])
        self.assertEqual(opt.active_seeds_for_generation(3), [1, 2, 5, 6])

    def test_self_play_promotes_elites_as_future_opponents(self) -> None:
        opt = BoundaryOptimizer(
            candidate_path=Path("client"),
            opponents=[OpponentSpec(Path("players/direct_runner"))],
            out_dir=Path("runs/test_unused"),
            seeds=[1],
            obstacles=[0],
            population=1,
            generations=2,
            timeout_ms=80,
            rounds=600,
            rng_seed=1,
            self_play_opponents=1,
            self_play_elite_count=1,
        )
        opt._log = lambda _message: None
        elite = EvalResult(
            params={"fresh_weight": 1.0},
            fitness=10.0,
            wins=1,
            losses=0,
            draws=0,
            league_points=3,
            generation=0,
            index=0,
        )

        self.assertEqual([op.path.name for op in opt.active_opponents_for_generation(0)], ["direct_runner"])
        opt._promote_self_play_opponents(0, [elite])

        labels = [op.label for op in opt.active_opponents_for_generation(1)]
        self.assertEqual(labels[-1], "selfplay:G1-C1")

    def test_inherited_seed_params_are_loaded_as_presets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            params_path = Path(tmp) / "best_params.json"
            params_path.write_text(json.dumps({"task_base_target": 123}), encoding="utf-8")
            opt = BoundaryOptimizer(
                candidate_path=Path("client"),
                opponents=[OpponentSpec(Path("players/direct_runner"))],
                out_dir=Path("runs/test_unused"),
                seeds=[1],
                obstacles=[0],
                population=3,
                generations=1,
                timeout_ms=80,
                rounds=600,
                rng_seed=1,
                seed_params_paths=[params_path],
            )

            inherited = opt._inherited_param_presets()

        self.assertTrue(any(params.get("task_base_target") == 123 for params in inherited))


if __name__ == "__main__":
    unittest.main()
