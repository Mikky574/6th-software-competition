#!/bin/bash
set -e

if [ "$#" -lt 3 ]; then
  echo "Usage: $0 <playerId> <host> <port>"
  exit 1
fi

PLAYER_ID="$1"
HOST="$2"
PORT="$3"
TEAM_NAME="myProject"

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python

exec "$PY" "$HERE/main.py" \
  --host "$HOST" --port "$PORT" \
  --playerId "$PLAYER_ID" --playerName "$TEAM_NAME"
