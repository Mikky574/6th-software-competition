"""Submission strategy configuration with frozen trained parameters."""

from __future__ import annotations

import json
import os
from typing import Any

from core import Agent, World

STRATEGY_NAME = "trainable-freshness-max-submission"
PARAMS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "best_params.json")

with open(PARAMS_PATH, "r", encoding="utf-8") as fp:
    BASE_PARAMS: dict[str, Any] = json.load(fp)

PARAMS = dict(BASE_PARAMS)


def make_agent(world: World) -> Agent:
    return Agent(world, PARAMS)
