# 荔枝争运战客户端设计说明

## 目标

本项目采用“协议层 + 运行时 + 世界模型 + 策略引擎 + 策略配置”的接口化结构。网络收发、消息封装、地图状态解析和具体决策互相隔离，后续可以只调整策略参数或替换单个模块，不需要改动整套客户端。

参考 `2` 目录中的策略实现，本设计优先保证：

- 平台启动参数兼容：`start.sh <playerId> <host> <port>`。
- 通信协议稳定：5 位长度前缀 + JSON 消息体。
- 决策逻辑可测试：策略只依赖已解析的 `World` 状态，不直接访问 socket。
- 策略可扩展：通过 `Agent` 接口和参数字典切换不同打法。
- 失败可降级：单回合决策异常时返回空动作，避免客户端退出。

## 模块划分

| 模块 | 建议文件 | 职责 | 对外接口 |
|---|---|---|---|
| 协议层 | `protocol.py` | 帧读取、帧发送、注册/ready/action 消息构造 | `read_frame()`、`write_frame()`、`registration_message()`、`ready_message()`、`action_message()` |
| 运行时 | `client.py` 或 `client_runtime.py` | 建立 TCP 连接，处理 `start` / `inquire` / `over` / `error` 消息，驱动策略 | `Client.run()` 或 `run(agent_factory)` |
| 世界模型 | `world.py` | 解析开局地图和每回合状态，提供查询接口 | `World.load_start()`、`World.load_inquire()`、`World.shortest_path()` |
| 动作模型 | `actions.py` | 统一动作构造，避免各处手写字段 | `move()`、`wait()`、`claim_resource()`、`claim_task()`、`use_resource()`、`deliver()` 等 |
| 策略接口 | `agent.py` | 定义决策引擎抽象，承载通用流程 | `Agent.decide() -> list[dict]` |
| 具体策略 | `strategy.py` | 只保留参数、权重和少量 hook，便于调参 | `make_agent(world)` |

当前 `myProject` 已有 `protocol.py`、`client.py`、`strategy.py`。后续实现可以先在现有文件上演进，再按上表拆分为更多模块。

## 核心接口

### Strategy / Agent

策略层只接收结构化状态，返回动作列表：

```python
class Strategy:
    def on_start(self, data: dict) -> None:
        ...

    def decide(self, data: dict) -> list[dict]:
        ...
```

升级为模块化引擎后建议使用：

```python
class Agent:
    def __init__(self, world: World, params: dict) -> None:
        ...

    def decide(self) -> list[dict]:
        ...
```

这样 `client_runtime.py` 只负责 `world.load_inquire(data)`，策略不再重复解析玩家、节点、任务和资源。

### World

`World` 保存两类数据：

- 静态数据：`matchId`、玩家阵营、起点、宫门、终点、节点、边、地形。
- 动态数据：当前回合、阶段、我方状态、对手状态、节点资源、任务、争夺窗口、天气、事件。

建议接口：

```python
class World:
    def load_start(self, data: dict, player_id: int) -> None:
        ...

    def load_inquire(self, data: dict) -> None:
        ...

    def shortest_path(self, source: str, goal: str, fresh_weight: float = 4.0) -> list[str]:
        ...

    def edge_between(self, source: str, target: str) -> dict | None:
        ...
```

世界模型里可以集中处理字段兼容，例如 `fromNodeId/fromNode`、`toNodeId/toNode`，避免策略层到处写兼容判断。

### Action

所有动作统一由函数构造：

```python
def act(action: str, **kwargs) -> dict:
    data = {"action": action}
    data.update({k: v for k, v in kwargs.items() if v is not None})
    return data
```

例如：

```python
act("MOVE", targetNodeId="S02")
act("CLAIM_RESOURCE", targetNodeId="S05", resourceType="ICE_BOX")
act("USE_RESOURCE", resourceType="ICE_BOX")
act("VERIFY_GATE")
act("DELIVER")
```

这样可以把字段拼写集中起来，减少比赛时因为小写错导致动作无效。

## 决策流程

建议每回合按固定优先级决策：

1. 如果已交付或退赛，返回空动作。
2. 如果存在独立动作窗口，先处理窗口卡牌或小队动作。
3. 如果正在移动、处理、验证或强行通过，不重复发送主动作。
4. 如果到达终点且已验证，执行 `DELIVER`。
5. 如果在宫门且冲刺阶段开启，执行 `VERIFY_GATE`。
6. 根据鲜度、库存和阶段判断是否使用冰鉴、护果令或马匹。
7. 在当前节点领取高价值任务或目标资源。
8. 必要节点执行 `PROCESS` / `DOCK`。
9. 寻路到当前目标，遇到障碍或守卫时清除、绕路或强行通过。
10. 无可行动作时返回 `WAIT` 或空动作。

这个流程让动作不会互相抢占，主车动作、窗口动作、小队动作也能自然并行。

## 策略参数

参考 `myProject/2/strategy.py`，建议具体打法通过参数控制：

```python
PARAMS = {
    "fresh_weight": 2.0,
    "do_tasks": True,
    "task_min_score": 15,
    "task_base_target": 130,
    "task_detour_dist": 30,
    "ice_target": 3,
    "ice_detour_dist": 15,
    "ice_end_save": False,
    "ice_use_threshold": 88.0,
    "ice_emergency": 62.0,
    "grab_horses": True,
    "permit_target": 1,
    "use_protect": True,
    "protect_freshness_below": 110.0,
    "window_mode": "value",
    "combat_mode": "none",
    "squad_mode": "none",
}
```

这组参数的核心思想是：先保证任务基础分和交付，再通过冰鉴持续补鲜、护果令锁住末段损耗，尽量提高好果和鲜度得分。

## 寻路设计

寻路使用 Dijkstra，边权由以下因素组成：

- 基础移动帧数：由距离和地形系数估算。
- 鲜度损耗：低损耗路径按 `fresh_weight` 得到额外收益。
- 节点处理耗时：必要处理点加上处理回合。
- 风险惩罚：障碍、敌方守卫、绕路风险增加成本。

目标点按阶段切换：

- 未验证：目标为宫门。
- 已验证：目标为终点。
- 前期资源或任务足够近：允许短距离绕路领取。
- 冲刺阶段：停止大绕路，优先验证和交付。

## 错误处理与调试

- 协议层校验长度前缀，超过 `99999` 字节直接报错。
- 运行时捕获单回合策略异常，记录日志并发送空动作。
- 支持 `LYCHEE_DEBUG` 或 `--debug` 输出每回合状态、位置、鲜度、好果、动作。
- 本地调试时优先查看 `调测/server/data.csv`、`client_debug.txt`、`log.txt` 和 `replay.txt`。

## 实施顺序

1. 保留现有 `protocol.py`，补齐协议测试或语法检查。
2. 将 `client.py` 的消息循环升级为 `client_runtime.py` 风格，接收 `agent_factory`。
3. 新增 `world.py`，把地图解析、玩家状态、寻路逻辑从策略中抽出来。
4. 新增 `actions.py`，集中动作构造。
5. 将 `strategy.py` 改为 `PARAMS + make_agent(world)`，让具体打法只负责调参。
6. 跑本地调测包，与官方 demo 对战，依据 `data.csv` 和回放继续调参。

