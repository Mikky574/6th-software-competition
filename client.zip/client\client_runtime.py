"""Client runtime: protocol loop that drives an Agent.

Usage from a team entry point:

    from core import World, Agent
    from client_runtime import run
    run(agent_factory=lambda world: Agent(world, PARAMS))

Command-line arguments (compatible with release/*/start.bat):
    --host / -i        server host (default 127.0.0.1)
    --port / -p        server port (default 8080)
    --playerId         our player id
    --playerName       our team name (defaults to folder name via caller)
    --version          client version string
"""

from __future__ import annotations

import argparse
import os
import socket
import sys
import time
import traceback
from typing import Any, Callable, Optional

from core import World, Agent, read_frame, write_frame


def parse_args(default_name: str = "team") -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", "-i", dest="host", default=os.environ.get("LYCHEE_HOST", "127.0.0.1"))
    ap.add_argument("--port", "-p", dest="port", type=int, default=int(os.environ.get("LYCHEE_PORT", "8080")))
    ap.add_argument("--playerId", dest="player_id", default=os.environ.get("LYCHEE_PID", "1001"))
    ap.add_argument("--playerName", dest="player_name", default=default_name)
    ap.add_argument("--version", dest="version", default="1.0")
    ap.add_argument("--debug", dest="debug", default=os.environ.get("LYCHEE_DEBUG", ""))
    # tolerate unknown extra args passed by the launcher
    args, _ = ap.parse_known_args()
    return args


class _Debug:
    def __init__(self, path: str) -> None:
        self._fh = open(path, "w", encoding="utf-8") if path else None

    def log(self, msg: str) -> None:
        if self._fh:
            self._fh.write(msg + "\n")
            self._fh.flush()

    def close(self) -> None:
        if self._fh:
            self._fh.close()


def run(agent_factory: Callable[[World], Agent], default_name: str = "team",
        args: Optional[argparse.Namespace] = None) -> int:
    if args is None:
        args = parse_args(default_name)
    dbg = _Debug(args.debug)

    sock = socket.create_connection((args.host, args.port), timeout=30)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    world = World()
    agent: Optional[Agent] = None
    match_id = ""
    # Accept string ids from the platform (e.g. "player1"); keep numeric ids as
    # ints so a strict local server still matches. World comparisons are
    # str-based, so either type is safe.
    raw_pid = str(args.player_id)
    player_id = int(raw_pid) if raw_pid.lstrip("-").isdigit() else raw_pid

    # registration
    write_frame(sock, {
        "msg_name": "registration",
        "msg_data": {"playerId": player_id, "playerName": args.player_name, "version": args.version},
    })
    dbg.log(f"registered pid={player_id} name={args.player_name}")

    try:
        while True:
            try:
                msg = read_frame(sock)
            except (EOFError, ConnectionError, OSError) as exc:
                dbg.log(f"connection closed: {exc}")
                return 0

            name = msg.get("msg_name")
            data = msg.get("msg_data") or {}

            if name == "start":
                match_id = data.get("matchId", "")
                world.load_start(data, player_id)
                agent = agent_factory(world)
                write_frame(sock, {
                    "msg_name": "ready",
                    "msg_data": {"matchId": match_id, "round": data.get("round", 1), "playerId": player_id},
                })
                dbg.log(f"start match={match_id} team={world.my_team} opp={world.opp_id} "
                        f"nodes={len(world.nodes)} edges={sum(len(v) for v in world.adj.values())}")

            elif name == "inquire":
                world.load_inquire(data)
                round_no = data.get("round", 0)
                actions: list = []
                if agent is not None:
                    try:
                        actions = agent.decide()
                    except Exception:  # never crash the match on a decision bug
                        dbg.log("decide error:\n" + traceback.format_exc())
                        actions = []
                write_frame(sock, {
                    "msg_name": "action",
                    "msg_data": {"matchId": match_id, "round": round_no, "playerId": player_id, "actions": actions},
                })
                if args.debug:
                    me = world.me
                    dbg.log(f"r{round_no} ph={world.phase} st={me.get('state')} "
                            f"node={me.get('currentNodeId')} nxt={me.get('nextNodeId')} "
                            f"fresh={me.get('freshness')} gf={me.get('goodFruit')} "
                            f"task={me.get('taskScore')} v={me.get('verified')} d={me.get('delivered')} "
                            f"-> {actions}")

            elif name == "over":
                _log_over(dbg, data, player_id)
                return 0

            elif name == "error":
                dbg.log(f"error: {msg}")
                # protocol errors are fatal-ish; keep looping unless connection drops

            else:
                dbg.log(f"ignored msg={name}")
    finally:
        dbg.close()
        try:
            sock.close()
        except OSError:
            pass


def _log_over(dbg: _Debug, data: dict, player_id: int) -> None:
    winner = data.get("winnerPlayerId")
    result = data.get("resultType")
    line = f"OVER round={data.get('overRound')} result={result} winner={winner}"
    for p in data.get("players", []) or []:
        line += (f"\n  pid={p.get('playerId')} name={p.get('playerName')} "
                 f"delivered={p.get('delivered')} total={p.get('totalScore')} "
                 f"detail={p.get('scoreDetail')}")
    dbg.log(line)
    print(line)
