"""Team client entry point.

The team name reported to the server is passed by start.sh (--playerName) and
defaults to this folder's name otherwise. Launch flags mirror the official
release client:

    python3 main.py --host 127.0.0.1 --port 30000 --playerId 1001 --playerName 1

All game logic lives in the shared engine (core.py); this team's behaviour is
defined entirely by strategy.py (PARAMS + make_agent).
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from client_runtime import run, parse_args  # noqa: E402
from strategy import make_agent, STRATEGY_NAME  # noqa: E402

TEAM_NAME = os.path.basename(os.path.dirname(os.path.abspath(__file__)))


def main() -> int:
    args = parse_args(default_name=TEAM_NAME)
    print(f"[team {args.player_name}] strategy={STRATEGY_NAME} "
          f"host={args.host} port={args.port} pid={args.player_id} name={args.player_name}",
          flush=True)
    return run(agent_factory=make_agent, default_name=TEAM_NAME, args=args)


if __name__ == "__main__":
    raise SystemExit(main())
