# myProject

Python strategy client for the Lychee arena.

## Files

- `client.py`: TCP connection, message loop, registration/ready/action.
- `main.py`: current contest entry point, using the modular runtime.
- `core.py`: world model, path finding, and reusable decision engine.
- `client_runtime.py`: registration/start/inquire/over protocol loop.
- `protocol.py`: 5-digit frame protocol and message builders.
- `strategy.py`: trainable policy parameters and agent factory.
- `DESIGN.md`: modular/interface-oriented design for the next implementation.
- `start.bat`: Windows local debug entry, compatible with the debug kit.
- `start.sh`: formal package entry, accepts `<playerId> <host> <port>`.

## Local Run

```powershell
python .\client.py --player-id 1001 --host 127.0.0.1 --port 30000 --player-name my-python-client
```

Current contest entry:

```powershell
.\start.bat 1001 127.0.0.1 30000 myProject
```

## Training

Training tools are kept outside this upload folder in `..\training_module`.
After training, run `..\training_module\apply_best_to_myProject.bat` to write
the best parameters back into `strategy.py`.
