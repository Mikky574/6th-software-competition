"""Shared client core for 《一骑红尘：荔枝争运战》.

Only the Python standard library is used (competition forbids third-party deps).

This module provides:
  * TCP 5-digit length-prefixed framing with half/pack handling.
  * A world model that parses `start` and each `inquire`.
  * A weighted graph + Dijkstra path finder over the live edge list.
  * A configurable decision engine (Agent) driven by a PARAMS dict and a set of
    optional strategy hooks, so each team can specialise behaviour without
    forking the engine.

The engine is deliberately reactive: it reads the authoritative server state
every frame and never hard-codes "on round N do X". All map facts (nodes,
edges, resources, tasks, process points) come from the live `start`/`inquire`
payloads, so the same code generalises to unseen map variants and opponents.
"""

from __future__ import annotations

import json
import math
import socket
import sys
import heapq
from typing import Any, Dict, List, Optional, Tuple

# --------------------------------------------------------------------------- #
# Constants derived from the task book (rules are fixed even if the map varies)
# --------------------------------------------------------------------------- #

# Route cost coefficient (移动量 per 1 distance) and freshness loss per frame.
ROUTE_COEFF = {"ROAD": 1380, "WATER": 1250, "MOUNTAIN": 1780, "BRANCH": 1550}
FRESH_RATE = {"ROAD": 0.055, "WATER": 0.045, "MOUNTAIN": 0.07, "BRANCH": 0.065}
BASE_MOVE_PER_FRAME = 1000
MOVE_BUFF_PER_FRAME = {"FAST_HORSE": 1200, "SHORT_HORSE": 1150, "RUSH_SPEED": 1300}
NORMAL_WEATHER_MULTIPLIER = 1000
RAIN_WATER_MULTIPLIER = 1350
FOG_MOUNTAIN_MULTIPLIER = 1100
HOT_FRESH_MULTIPLIER = 1.5
RAIN_WATER_FRESH_MULTIPLIER = 1.3
RAIN_WATER_PROCESS_EXTRA = 4
WATER_PROCESS_TYPES = {"BOARD", "WATER_TRANSFER"}

MANDATORY_PROCESS = {
    "TRANSFER", "BOARD", "WATER_TRANSFER", "PASS_TRANSFER", "PALACE_TRANSFER",
}

# Task template base scores (fixed by rules).
TASK_SCORE = {
    "T01": 30, "T02": 30, "T04": 30, "T06": 30, "T08": 30, "T11": 30,
    "T12": 15, "T13": 15, "T14": 15,
}
RESOURCE_WINDOW_VALUE = {
    "ICE_BOX": 18,
    "PASS_TOKEN": 18,
    "OFFICIAL_PERMIT": 18,
    "FAST_HORSE": 16,
    "SHORT_HORSE": 12,
    "INTEL": 8,
}
CARD_RESULT = {
    ("YAN_DIE", "QIANG_XING"): 1,
    ("YAN_DIE", "XIAN_GONG"): -1,
    ("YAN_DIE", "BING_ZHENG"): -1,
    ("QIANG_XING", "YAN_DIE"): -1,
    ("QIANG_XING", "XIAN_GONG"): 1,
    ("QIANG_XING", "BING_ZHENG"): -1,
    ("XIAN_GONG", "YAN_DIE"): 1,
    ("XIAN_GONG", "QIANG_XING"): -1,
    ("XIAN_GONG", "BING_ZHENG"): 1,
    ("BING_ZHENG", "YAN_DIE"): 1,
    ("BING_ZHENG", "QIANG_XING"): 1,
    ("BING_ZHENG", "XIAN_GONG"): -1,
}

MAX_BODY = 99999
MOVE_STATES = {"MOVING", "WAITING"}
BUSY_STATES = {"PROCESSING", "VERIFYING", "FORCED_PASSING"}


# --------------------------------------------------------------------------- #
# Framing (robust half/pack handling)
# --------------------------------------------------------------------------- #

def read_exact(sock: socket.socket, length: int) -> bytes:
    chunks = []
    remaining = length
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise EOFError("connection closed")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def read_frame(sock: socket.socket) -> dict:
    prefix = read_exact(sock, 5)
    try:
        length = int(prefix.decode("ascii"))
    except ValueError as exc:
        raise ValueError(f"invalid frame prefix: {prefix!r}") from exc
    if length < 0 or length > MAX_BODY:
        raise ValueError(f"invalid frame length: {length}")
    body = read_exact(sock, length)
    return json.loads(body.decode("utf-8"))


def write_frame(sock: socket.socket, message: dict) -> None:
    body = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_BODY:
        raise ValueError(f"message too large: {len(body)}")
    sock.sendall(f"{len(body):05d}".encode("ascii") + body)


# --------------------------------------------------------------------------- #
# World model
# --------------------------------------------------------------------------- #

class World:
    """Holds static map info (from `start`) and the latest `inquire` snapshot."""

    def __init__(self) -> None:
        self.match_id: str = ""
        self.duration: int = 600
        self.my_id: int = 0
        self.my_team: str = ""
        self.opp_id: int = 0
        self.opp_team: str = ""
        self.start_node: str = "S01"
        self.gate_node: str = "S14"
        self.terminal_nodes: List[str] = ["S15"]
        self.nodes: Dict[str, dict] = {}          # static node info
        self.adj: Dict[str, List[dict]] = {}      # nodeId -> list of {to, routeType, distance, edgeId}
        self.node_coord: Dict[str, Tuple[int, int]] = {}
        self.route_task_buckets: Dict[str, set] = {}

        # per-frame snapshot
        self.round: int = 0
        self.phase: str = "NORMAL"
        self.me: dict = {}
        self.opp: dict = {}
        self.node_state: Dict[str, dict] = {}
        self.tasks: List[dict] = []
        self.contests: List[dict] = []
        self.bounties: List[dict] = []
        self.weather: dict = {}
        self.events: List[dict] = []
        self.action_results: List[dict] = []

    # ---- static parsing ---------------------------------------------------- #
    def load_start(self, data: dict, my_id: int) -> None:
        self.match_id = data.get("matchId", "")
        self.duration = int(data.get("durationRound", 600) or 600)
        self.my_id = my_id
        players = data.get("players", []) or []
        for p in players:
            if str(p.get("playerId")) == str(my_id):
                self.my_team = p.get("teamId", "")
        for p in players:
            if str(p.get("playerId")) != str(my_id):
                self.opp_id = p.get("playerId", 0)
                self.opp_team = p.get("teamId", "")

        gp = (data.get("map", {}) or {}).get("gameplay", {}) or {}
        roles = gp.get("roles", {}) or {}
        self.start_node = roles.get("startNodeId", "S01")
        self.gate_node = roles.get("gateNodeId", "S14")
        self.terminal_nodes = roles.get("terminalNodeIds", ["S15"]) or ["S15"]
        self.route_task_buckets = {
            str(bucket).upper(): set(nodes or [])
            for bucket, nodes in (gp.get("routeTaskBuckets", {}) or {}).items()
        }

        nodes = data.get("nodes") or (data.get("map", {}) or {}).get("nodes") or []
        for n in nodes:
            nid = n.get("nodeId")
            if not nid:
                continue
            self.nodes[nid] = n
            self.node_coord[nid] = (n.get("x", 0), n.get("y", 0))

        edges = data.get("edges") or (data.get("map", {}) or {}).get("edges") or []
        self._build_adjacency(edges)

    def _build_adjacency(self, edges: List[dict]) -> None:
        adj: Dict[str, List[dict]] = {nid: [] for nid in self.nodes}
        for e in edges:
            a = e.get("fromNodeId") or e.get("fromNode")
            b = e.get("toNodeId") or e.get("toNode")
            if not a or not b:
                continue
            rt = e.get("routeType", "ROAD")
            dist = int(e.get("distance", 1) or 1)
            eid = e.get("edgeId", "")
            bidir = e.get("bidirectional", True)
            adj.setdefault(a, []).append({"to": b, "routeType": rt, "distance": dist, "edgeId": eid})
            if bidir:
                adj.setdefault(b, []).append({"to": a, "routeType": rt, "distance": dist, "edgeId": eid})
        self.adj = adj

    # ---- per-frame parsing ------------------------------------------------- #
    def load_inquire(self, data: dict) -> None:
        self.round = int(data.get("round", 0) or 0)
        self.phase = data.get("phase", "NORMAL")
        players = data.get("players", []) or []
        self.me = {}
        self.opp = {}
        for p in players:
            if str(p.get("playerId")) == str(self.my_id):
                self.me = p
            else:
                self.opp = p
        self.node_state = {}
        for n in data.get("nodes", []) or []:
            nid = n.get("nodeId")
            if nid:
                self.node_state[nid] = n
        # refresh adjacency if edges provided (map is static but stay safe)
        if data.get("edges"):
            self._build_adjacency(data["edges"])
        self.tasks = data.get("tasks", []) or []
        self.contests = data.get("contests", []) or []
        self.bounties = data.get("bounties", []) or []
        self.weather = data.get("weather", {}) or {}
        self.events = data.get("events", []) or []
        self.action_results = data.get("actionResults", []) or []

    # ---- helpers ----------------------------------------------------------- #
    def _weather_windows(self) -> List[dict]:
        windows: List[dict] = []
        weather = self.weather or {}
        for item in weather.get("active", []) or []:
            start = int(item.get("startRound", self.round) or self.round)
            if item.get("remainRound") is not None:
                # Active weather often omits startRound; anchor remaining time at the
                # current public round so planning reacts to the live state.
                start = self.round
                duration = int(item.get("remainRound", 0) or 0)
            else:
                duration = int(item.get("durationRound", 0) or 0)
            if duration > 0:
                event = dict(item)
                event["_start"] = start
                event["_end"] = start + duration - 1
                windows.append(event)
        for item in weather.get("forecast", []) or []:
            start = int(item.get("startRound", 0) or 0)
            duration = int(item.get("durationRound", item.get("remainRound", 0)) or 0)
            if start > 0 and duration > 0:
                event = dict(item)
                event["_start"] = start
                event["_end"] = start + duration - 1
                windows.append(event)
        return windows

    def _weather_at(self, round_no: int) -> List[dict]:
        return [w for w in self._weather_windows() if int(w.get("_start", 0)) <= round_no <= int(w.get("_end", -1))]

    @staticmethod
    def _weather_region_matches(event: dict, route_type: str) -> bool:
        region = str(event.get("region", "") or "").upper()
        if region in ("", "ALL"):
            return True
        return region == route_type

    def weather_travel_multiplier(self, route_type: str, round_no: int) -> int:
        route_type = route_type.upper()
        multiplier = NORMAL_WEATHER_MULTIPLIER
        for event in self._weather_at(round_no):
            etype = str(event.get("type", "") or "").upper()
            if etype == "HEAVY_RAIN" and route_type == "WATER" and self._weather_region_matches(event, route_type):
                multiplier = max(multiplier, RAIN_WATER_MULTIPLIER)
            elif etype == "MOUNTAIN_FOG" and route_type == "MOUNTAIN" and self._weather_region_matches(event, route_type):
                multiplier = max(multiplier, FOG_MOUNTAIN_MULTIPLIER)
        return multiplier

    def weather_fresh_multiplier(self, route_type: str, round_no: int) -> float:
        route_type = route_type.upper()
        multiplier = 1.0
        for event in self._weather_at(round_no):
            etype = str(event.get("type", "") or "").upper()
            if etype == "HOT":
                multiplier = max(multiplier, HOT_FRESH_MULTIPLIER)
            elif etype == "HEAVY_RAIN" and route_type == "WATER" and self._weather_region_matches(event, route_type):
                multiplier = max(multiplier, RAIN_WATER_FRESH_MULTIPLIER)
        return multiplier

    def edge_travel(
        self,
        distance: int,
        route_type: str,
        per_frame: float = BASE_MOVE_PER_FRAME,
        depart_round: Optional[int] = None,
    ) -> Tuple[int, float]:
        route_type = str(route_type or "ROAD").upper()
        coeff = ROUTE_COEFF.get(route_type, 1380)
        remaining = math.ceil(distance * coeff)
        round_no = self.round if depart_round is None else int(depart_round)
        frames = 0
        fresh_loss = 0.0
        base_fresh = FRESH_RATE.get(route_type, 0.06)
        while remaining > 0:
            travel_multiplier = self.weather_travel_multiplier(route_type, round_no + frames)
            step = math.floor(max(1.0, per_frame) * NORMAL_WEATHER_MULTIPLIER / max(1, travel_multiplier))
            remaining -= max(1, step)
            fresh_loss += base_fresh * self.weather_fresh_multiplier(route_type, round_no + frames)
            frames += 1
        return max(1, frames), fresh_loss

    def edge_frames(
        self,
        distance: int,
        route_type: str,
        per_frame: float = BASE_MOVE_PER_FRAME,
        depart_round: Optional[int] = None,
    ) -> int:
        frames, _fresh_loss = self.edge_travel(distance, route_type, per_frame, depart_round)
        return frames

    def edge_cost(
        self,
        distance: int,
        route_type: str,
        fresh_weight: float,
        per_frame: float = BASE_MOVE_PER_FRAME,
        depart_round: Optional[int] = None,
    ) -> Tuple[float, int, float]:
        frames, fresh_loss = self.edge_travel(distance, route_type, per_frame, depart_round)
        return frames + fresh_weight * fresh_loss, frames, fresh_loss

    def _water_process_hit_by_rain(self, process_type: str, start_round: int, base_rounds: int) -> bool:
        if process_type not in WATER_PROCESS_TYPES or base_rounds <= 0:
            return False
        end_round = start_round + base_rounds - 1
        for event in self._weather_windows():
            etype = str(event.get("type", "") or "").upper()
            region = str(event.get("region", "") or "").upper()
            if etype != "HEAVY_RAIN" or region not in ("", "ALL", "WATER"):
                continue
            if int(event.get("_start", 0)) <= end_round and start_round <= int(event.get("_end", -1)):
                return True
        return False

    def node_process_round(self, nid: str, start_round: Optional[int] = None) -> int:
        n = self.node_state.get(nid) or self.nodes.get(nid) or {}
        pt = n.get("processType")
        if pt in MANDATORY_PROCESS:
            base = int(n.get("processRound", 0) or 0)
            if self._water_process_hit_by_rain(pt, self.round if start_round is None else int(start_round), base):
                return base + RAIN_WATER_PROCESS_EXTRA
            return base
        return 0

    def path_metrics(
        self,
        path: List[str],
        fresh_weight: float = 0.0,
        per_frame: float = BASE_MOVE_PER_FRAME,
        depart_round: Optional[int] = None,
    ) -> Tuple[float, float, float]:
        cost = 0.0
        frames_total = 0.0
        fresh_loss_total = 0.0
        current_round = self.round if depart_round is None else int(depart_round)
        for i in range(len(path) - 1):
            e = self.edge_between(path[i], path[i + 1])
            if not e:
                return float("inf"), float("inf"), float("inf")
            edge_cost, frames, fresh_loss = self.edge_cost(
                e["distance"],
                e["routeType"],
                fresh_weight,
                per_frame=per_frame,
                depart_round=current_round,
            )
            cost += edge_cost
            frames_total += frames
            fresh_loss_total += fresh_loss
            current_round += frames
            process_rounds = self.node_process_round(path[i + 1], start_round=current_round)
            cost += process_rounds
            frames_total += process_rounds
            current_round += process_rounds
        return cost, frames_total, fresh_loss_total

    def path_cost(
        self,
        source: str,
        goal: str,
        fresh_weight: float = 4.0,
        obstacle_penalty: float = 10.0,
        guard_penalty: float = 90.0,
        depart_round: Optional[int] = None,
    ) -> float:
        path = self.shortest_path(
            source,
            goal,
            fresh_weight=fresh_weight,
            obstacle_penalty=obstacle_penalty,
            guard_penalty=guard_penalty,
            depart_round=depart_round,
        )
        if not path:
            return float("inf")
        cost, _frames, _fresh_loss = self.path_metrics(
            path,
            fresh_weight=fresh_weight,
            depart_round=depart_round,
        )
        return cost

    def squad_scout_weather_delay(self, nid: str, submit_round: Optional[int] = None) -> int:
        n = self.node_state.get(nid) or self.nodes.get(nid) or {}
        ntype = str(n.get("nodeType", "") or "").upper()
        mountain_nodes = self.route_task_buckets.get("MOUNTAIN", set())
        if nid not in mountain_nodes and ntype not in ("MOUNTAIN_NODE", "MOUNTAIN_PASS", "KEY_PASS"):
            return 0
        round_no = self.round if submit_round is None else int(submit_round)
        for event in self._weather_at(round_no):
            etype = str(event.get("type", "") or "").upper()
            region = str(event.get("region", "") or "").upper()
            if etype == "MOUNTAIN_FOG" and region in ("", "ALL", "MOUNTAIN"):
                return 2
        return 0

    def squad_scout_delay(self, source: str, target: str, submit_round: Optional[int] = None) -> int:
        sx, sy = self.node_coord.get(source, (0, 0))
        tx, ty = self.node_coord.get(target, (0, 0))
        distance = max(abs(tx - sx), abs(ty - sy))
        base = min(15, max(3, int(math.ceil(distance / 3.0))))
        extra = self.squad_scout_weather_delay(target, submit_round)
        return min(15, base + extra)

    def node_has_obstacle(self, nid: str) -> bool:
        n = self.node_state.get(nid) or {}
        return bool(n.get("hasObstacle"))

    def enemy_guard(self, nid: str) -> Optional[dict]:
        n = self.node_state.get(nid) or {}
        g = n.get("guard")
        if not g:
            return None
        if g.get("ownerTeamId") and g.get("ownerTeamId") != self.my_team and int(g.get("defense", 0) or 0) > 0:
            return g
        return None

    def my_guard(self, nid: str) -> Optional[dict]:
        n = self.node_state.get(nid) or {}
        g = n.get("guard")
        if not g:
            return None
        if g.get("ownerTeamId") == self.my_team and int(g.get("defense", 0) or 0) > 0:
            return g
        return None

    # ---- Dijkstra path finder --------------------------------------------- #
    def shortest_path(self, source: str, goal: str, fresh_weight: float = 4.0,
                      obstacle_penalty: float = 10.0, guard_penalty: float = 90.0,
                      avoid_nodes: Optional[set] = None,
                      depart_round: Optional[int] = None) -> List[str]:
        """Return node list source..goal minimising a frame+freshness+risk cost."""
        avoid_nodes = avoid_nodes or set()
        start_round = self.round if depart_round is None else int(depart_round)
        dist: Dict[str, float] = {source: 0.0}
        prev: Dict[str, str] = {}
        pq: List[Tuple[float, int, str]] = [(0.0, 0, source)]
        while pq:
            d, elapsed, u = heapq.heappop(pq)
            if d > dist.get(u, float("inf")) + 1e-9:
                continue
            if u == goal:
                break
            for e in self.adj.get(u, []):
                v = e["to"]
                if v in avoid_nodes and v != goal:
                    continue
                edge_cost, frames, _fresh_loss = self.edge_cost(
                    e["distance"],
                    e["routeType"],
                    fresh_weight,
                    depart_round=start_round + elapsed,
                )
                arrival_round = start_round + elapsed + frames
                process_rounds = self.node_process_round(v, start_round=arrival_round)
                cost = edge_cost + process_rounds
                if v != goal and self.node_has_obstacle(v):
                    cost += obstacle_penalty
                if v != goal and self.enemy_guard(v):
                    cost += guard_penalty
                nd = d + cost
                next_elapsed = elapsed + frames + process_rounds
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(pq, (nd, next_elapsed, v))
        if goal not in prev and goal != source:
            return []
        path = [goal]
        while path[-1] != source:
            p = prev.get(path[-1])
            if p is None:
                return []
            path.append(p)
        path.reverse()
        return path

    def path_distance(self, source: str, goal: str) -> float:
        """Accumulated raw route distance (for INTEL range / rush estimates)."""
        dist: Dict[str, float] = {source: 0.0}
        pq: List[Tuple[float, str]] = [(0.0, source)]
        visited = set()
        while pq:
            d, u = heapq.heappop(pq)
            if u in visited:
                continue
            visited.add(u)
            if u == goal:
                return d
            for e in self.adj.get(u, []):
                v = e["to"]
                nd = d + e["distance"]
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    heapq.heappush(pq, (nd, v))
        return dist.get(goal, float("inf"))

    def edge_between(self, a: str, b: str) -> Optional[dict]:
        for e in self.adj.get(a, []):
            if e["to"] == b:
                return e
        return None


# --------------------------------------------------------------------------- #
# Action helpers
# --------------------------------------------------------------------------- #

def act(action: str, **kw) -> dict:
    d = {"action": action}
    d.update({k: v for k, v in kw.items() if v is not None})
    return d


# --------------------------------------------------------------------------- #
# Default tunable parameters. Each team overrides a subset in strategy.py.
# --------------------------------------------------------------------------- #

DEFAULT_PARAMS: Dict[str, Any] = {
    # routing
    "fresh_weight": 4.0,          # how strongly to favour low-freshness-loss routes
    "obstacle_penalty": 12.0,     # reroute cost added for an obstacle on a node
    "guard_penalty": 12.0,        # light path cost; guard handling compares real pass vs detour costs
    "guard_reroute_margin": 24.0, # only detour if it beats direct guard solving by this many frames
    "reroute_slack": 1.4,         # accept a detour if <= slack * (blocked path cost)
    # tasks
    "do_tasks": True,
    "task_min_score": 15,         # ignore tasks below this
    "task_base_target": 110,      # chase tasks until base reaches this
    "task_base_cap": 999,         # never chase past this (detours stop)
    "task_detour_dist": 0,        # max extra route-distance to detour for a task
    "task_candidate_limit": 8,    # bound per-frame detour search work
    "preferred_task_route": "WATER",  # off-path detours must match this route bucket
    "ice_detour_dist": 0,         # max extra route-distance to detour for an ICE_BOX
    "ice_candidate_limit": 6,     # bound per-frame ice search work
    "spend_horse_on_t06": False,  # let T06 consume a horse
    # resources
    "ice_target": 2,              # how many ICE_BOX to stock
    "grab_horses": True,          # claim horse resources on route
    "fast_horse_target": 1,
    "short_horse_target": 1,
    "permit_target": 1,           # PASS_TOKEN/OFFICIAL_PERMIT for window cards
    "claim_intel": False,
    # freshness management
    "ice_end_save": True,         # hold ICE_BOX and dump it in the final approach
    "ice_end_frames": 55,         # 'final approach' = this many frames from terminal
    "ice_end_cap": 97.0,          # stop dumping ice once freshness reaches this
    "ice_emergency": 58.0,        # always use ice below this (avoid good->bad)
    "ice_use_threshold": 78.0,    # non end-save mode: use ice below this
    "ice_use_min_gap": 5,         # min frames between ice uses (threshold mode)
    # horses
    "use_horses": True,
    "horse_min_frames": 24,       # only pop a horse if this many frames of travel remain
    # end-game
    "use_protect": True,          # pop 护果令 for the final stretch
    "protect_freshness_below": 101.0,  # only if freshness below this when popping
    "use_rush_speed": False,      # alternative: 疾行令 for speed
    "rush_tactic_mode": "auto",   # 'auto' | 'speed' | 'protect' | 'break_gate' | 'save_for_guard'
    "gate_break_order": True,     # bind 破关令 to S14 VERIFY_GATE when selected
    # windows / combat
    "window_mode": "value",       # 'none' | 'value' | 'aggressive'
    "window_clinch_abstain": True, # save cards once a 3-round window is already 2-0/0-2
    "window_repeat_counter": True, # counter the opponent's last revealed card when worth it
    "window_repeat_counter_min_value": 15,
    "window_repeat_draw_abstain_after": 1, # optional low-value windows: stop feeding repeat draws
    "window_optional_min_value": 14,
    "window_task_critical_score": 30,
    "window_good_reserve": 1,
    "window_token_reserve": 1,
    "window_horse_reserve": 1,
    "window_guard_point_reserve": 1,
    "combat_mode": "none",        # 'none' | 'aggressive'
    "guard_fruit_budget": 6,      # keep at least this many good fruit before guarding
    "guard_extra_fruit": 1,       # extra good fruit invested per SET_GUARD
    "squad_mode": "none",         # 'none' | 'scout' | 'combat'
    "squad_min_gap": 12,          # min frames between squad dispatches
    "squad_scout_reserve": 0,     # keep this many squad hands unused
    "squad_scout_max_eta": 55,    # only scout nodes likely reached before marker expiry
    "squad_scout_min_process": 4,  # scout only read-bars at least this long
    "squad_scout_tasks": True,     # scout high-value task nodes on the chosen route
    "squad_scout_task_min_score": 30,
    "squad_clear_obstacles": True,
    "squad_weaken_guards": True,
}


class Agent:
    """Reactive decision engine. Subclass and override hooks for team flavour."""

    def __init__(self, world: World, params: Optional[Dict[str, Any]] = None) -> None:
        self.w = world
        self.p = dict(DEFAULT_PARAMS)
        if params:
            self.p.update(params)
        # per-visit trackers
        self.visit_node: Optional[str] = None
        self.processed_here = False
        self.claimed_res_here: set = set()
        self.tried_tasks_here: set = set()
        self.force_process = False
        # global trackers
        self.done_tasks: set = set()
        self.used_endgame = False
        self.last_ice_round = -999
        self.task_base = 0
        self.squad_used_round = -999
        self.last_state = ""
        self._active_obj: Optional[str] = None
        self.ms_per_frame: float = 700.0
        # combat trackers
        self.guards_set = 0
        self.guard_nodes: set = set()
        self.scouted_by_us: set = set()
        self.process_blocked_until: Dict[str, int] = {}
        self.window_seen_reveals: set = set()
        self.window_opp_cards: Dict[str, List[str]] = {}
        self.window_my_cards: Dict[str, List[str]] = {}
        self.window_draws: Dict[str, int] = {}
        self._cache_round = -1
        self._path_cache: Dict[tuple, List[str]] = {}
        self._metrics_cache: Dict[tuple, Tuple[float, float, float]] = {}

    # ---- public API -------------------------------------------------------- #
    def decide(self) -> List[dict]:
        w = self.w
        me = w.me
        state = me.get("state", "IDLE")
        node = me.get("currentNodeId")
        if w.round != self._cache_round:
            self._cache_round = w.round
            self._path_cache.clear()
            self._metrics_cache.clear()
        self.used_endgame = int(me.get("rushTacticUsedCount", 0) or 0) > 0

        self._absorb_events()

        if state == "IDLE" and node and node != self.visit_node:
            self.visit_node = node
            self.processed_here = False
            self.claimed_res_here = set()
            self.tried_tasks_here = set()
            self.force_process = False

        actions: List[dict] = []

        # window card is an independent action category
        wc = self.decide_window()
        if wc:
            actions.append(wc)
        # squad is an independent action category
        sq = self.decide_squad()
        if sq:
            actions.append(sq)

        main = self._decide_main(state, node)
        if main:
            actions.append(main)

        self.last_state = state
        return actions

    # ---- main-car action --------------------------------------------------- #
    def _decide_main(self, state: str, node: Optional[str]) -> Optional[dict]:
        me = self.w.me
        if me.get("delivered"):
            return None
        # A live read-bar (process/verify/claim/clear/forced-pass) occupies the
        # main car; the authoritative signal is currentProcess. Just heartbeat.
        if me.get("currentProcess"):
            return None
        if state == "RESTING":
            return act("WAIT")
        if state == "CONTESTING":
            return None
        if state == "MOVING":
            return self.decide_moving()
        # IDLE / WAITING at a node / anything else without a read-bar
        return self.decide_idle(node)

    # ---- IDLE logic (overridable pieces via hooks) ------------------------- #
    def decide_idle(self, node: Optional[str]) -> Optional[dict]:
        w = self.w
        me = w.me
        if not node:
            return act("WAIT")

        # 1. terminal delivery
        if node in w.terminal_nodes:
            if me.get("verified") and me.get("goodFruit", 0) > 0 and me.get("freshness", 0) > 0:
                return act("DELIVER")
            if not me.get("verified"):
                return self._step_toward(w.gate_node)
            return act("WAIT")

        # 2. gate verify
        if node == w.gate_node:
            if not me.get("verified"):
                if w.phase == "RUSH":
                    eg = self._maybe_endgame_before_gate()
                    if eg:
                        return eg
                    payload = {"targetNodeId": w.gate_node}
                    if self._should_bind_gate_break_order():
                        self.used_endgame = True
                        payload["rushTactic"] = "BREAK_ORDER"
                    return act("VERIFY_GATE", **payload)
                return act("WAIT")  # gate not open yet; wait for rush
            return self._step_toward(w.terminal_nodes[0])

        # freshness upkeep (independent of node type)
        ice = self._maybe_use_ice()
        if ice:
            return ice

        # 3. mandatory station process forced retry
        if self.force_process and w.node_process_round(node) > 0 and not self.processed_here:
            if self._process_temporarily_blocked(node):
                return act("WAIT")
            self.force_process = False
            return self._process_action(node)

        # 4. claim a valuable task standing here
        if self.p["do_tasks"]:
            ta = self._claim_task_here(node)
            if ta:
                return ta

        # 5. claim a wanted resource here
        ra = self._claim_resource_here(node)
        if ra:
            return ra

        # 6. mandatory station process
        if w.node_process_round(node) > 0 and not self.processed_here:
            if self._process_temporarily_blocked(node):
                return act("WAIT")
            return self._process_action(node)

        # 6.5 combat: drop a guard behind us at a chokepoint to delay the opponent
        if self.p["combat_mode"] == "aggressive":
            g = self._maybe_set_guard(node)
            if g:
                return g

        # 7. advance toward the goal (possibly via a task detour)
        return self._advance(node)

    def decide_moving(self) -> Optional[dict]:
        # continue moving (empty heartbeat keeps progress); optionally pop a horse
        horse = self._maybe_use_horse(moving=True)
        if horse:
            return horse
        return None

    # ---- advancing / obstacles / guards ------------------------------------ #
    def _advance(self, node: str) -> Optional[dict]:
        w = self.w
        goal = self._current_goal(node)
        path = self._plan_path(node, goal)
        if len(path) < 2:
            return act("WAIT")
        nxt = path[1]

        if w.node_has_obstacle(nxt):
            return self._handle_obstacle(node, nxt)
        guard = w.enemy_guard(nxt)
        if guard:
            return self._handle_guard(node, nxt, goal)

        horse = self._maybe_use_horse(moving=False)
        if horse:
            return horse
        return act("MOVE", targetNodeId=nxt)

    def _plan_path(self, node: str, goal: str) -> List[str]:
        key = (
            node,
            goal,
            round(float(self.p["fresh_weight"]), 4),
            round(float(self.p["obstacle_penalty"]), 4),
            round(float(self.p["guard_penalty"]), 4),
            None,
        )
        if key in self._path_cache:
            return list(self._path_cache[key])
        path = self.w.shortest_path(
            node, goal,
            fresh_weight=self.p["fresh_weight"],
            obstacle_penalty=self.p["obstacle_penalty"],
            guard_penalty=self.p["guard_penalty"],
        )
        self._path_cache[key] = list(path)
        return path

    def _planned_metrics(
        self,
        source: str,
        goal: str,
        depart_round: Optional[int] = None,
        fresh_weight: Optional[float] = None,
        per_frame: Optional[float] = None,
    ) -> Tuple[float, float, float]:
        weight = self.p["fresh_weight"] if fresh_weight is None else fresh_weight
        key = (
            source,
            goal,
            depart_round,
            round(float(weight), 4),
            round(float(BASE_MOVE_PER_FRAME if per_frame is None else per_frame), 4),
            round(float(self.p["obstacle_penalty"]), 4),
            round(float(self.p["guard_penalty"]), 4),
        )
        if key in self._metrics_cache:
            return self._metrics_cache[key]
        path = self.w.shortest_path(
            source, goal,
            fresh_weight=weight,
            obstacle_penalty=self.p["obstacle_penalty"],
            guard_penalty=self.p["guard_penalty"],
            depart_round=depart_round,
        )
        if not path:
            return float("inf"), float("inf"), float("inf")
        metrics = self.w.path_metrics(
            path,
            fresh_weight=weight,
            per_frame=BASE_MOVE_PER_FRAME if per_frame is None else per_frame,
            depart_round=depart_round,
        )
        self._metrics_cache[key] = metrics
        return metrics

    def _step_toward(self, goal: str) -> Optional[dict]:
        node = self.w.me.get("currentNodeId")
        if not node:
            return act("WAIT")
        path = self._plan_path(node, goal)
        if len(path) < 2:
            return act("WAIT")
        return act("MOVE", targetNodeId=path[1])

    def _current_goal(self, node: str) -> str:
        """Gate/terminal, unless an ice or task detour within budget is worthwhile."""
        me = self.w.me
        final = self.w.gate_node if not me.get("verified") else self.w.terminal_nodes[0]
        if me.get("verified") or self.w.phase == "RUSH":
            return final

        base_cost = [None]  # lazily computed
        best = [None]
        best_extra = [None]

        def consider(targets, budget):
            if budget <= 0 or not targets:
                return
            if base_cost[0] is None:
                base_cost[0] = self._planned_metrics(node, final)[0]
            if not math.isfinite(base_cost[0]):
                return
            for tn in targets:
                if not tn or tn == node:
                    continue
                to_cost, to_frames, _to_fresh = self._planned_metrics(node, tn)
                if not math.isfinite(to_cost):
                    continue
                depart_after_target = self.w.round + int(math.ceil(to_frames))
                onward_cost = self._planned_metrics(tn, final, depart_round=depart_after_target)[0]
                if not math.isfinite(onward_cost):
                    continue
                extra = to_cost + onward_cost - base_cost[0]
                if extra <= budget and (best_extra[0] is None or extra < best_extra[0]):
                    best_extra[0] = extra
                    best[0] = tn

        # ice pickups (freshness play): route via nodes that still hold ICE_BOX
        if self._held("ICE_BOX") < self.p["ice_target"]:
            ice_nodes = [nid for nid, ns in self.w.node_state.items()
                         if int((ns.get("resourceStock") or {}).get("ICE_BOX", 0) or 0) > 0]
            consider(self._nearest_targets(node, ice_nodes, int(self.p.get("ice_candidate_limit", 6) or 6)),
                     self.p["ice_detour_dist"])

        # task pickups
        if self.p["do_tasks"] and self.task_base < self.p["task_base_target"]:
            task_nodes = []
            direct_nodes: Optional[set] = None
            preferred_route = str(self.p.get("preferred_task_route", "") or "").upper()
            for t in self.w.tasks:
                if not t.get("active") or t.get("completed") or t.get("failed"):
                    continue
                if not self._task_free(t):
                    continue
                tmpl = t.get("taskTemplateId", "")
                score = int(t.get("score", TASK_SCORE.get(tmpl, 0)) or 0)
                if score < self.p["task_min_score"]:
                    continue
                if tmpl == "T06" and not self.p["spend_horse_on_t06"]:
                    continue
                tn = t.get("nodeId")
                if tn and tn != node and tn not in self.done_tasks:
                    if preferred_route and preferred_route != "ANY":
                        if direct_nodes is None:
                            direct_nodes = set(self._plan_path(node, final))
                        route_bucket = str(t.get("routeBucket", "") or "").upper()
                        route_buckets = {
                            str(bucket or "").upper()
                            for bucket in (t.get("routeBuckets") or [])
                        }
                        if route_bucket:
                            route_buckets.add(route_bucket)
                        if tn not in direct_nodes and preferred_route not in route_buckets:
                            continue
                    task_nodes.append(tn)
            consider(self._nearest_targets(node, task_nodes, int(self.p.get("task_candidate_limit", 8) or 8)),
                     self.p["task_detour_dist"])

        return best[0] if best[0] else final

    def _nearest_targets(self, node: str, targets: List[str], limit: int) -> List[str]:
        if limit <= 0:
            return []
        seen = set()
        unique = []
        for target in targets:
            if target and target not in seen:
                seen.add(target)
                unique.append(target)
        unique.sort(key=lambda target: (self.w.path_distance(node, target), target))
        return unique[:limit]

    def _maybe_set_guard(self, node: str) -> Optional[dict]:
        """Set one strong guard at a true chokepoint once we've passed, to tax the
        opponent's transit. Only when the opponent is clearly behind us."""
        me = self.w.me
        if self.guards_set >= 1 or node in self.guard_nodes or self.w.phase == "RUSH":
            return None
        ntype = (self.w.node_state.get(node) or self.w.nodes.get(node) or {}).get("nodeType", "")
        if ntype not in ("KEY_PASS", "PASS"):
            return None
        need = self.p["guard_fruit_budget"] + 1 + self.p["guard_extra_fruit"]
        if int(me.get("goodFruit", 0) or 0) < need:
            return None
        opp = self.w.opp
        onode = opp.get("currentNodeId")
        if not onode or opp.get("verified") or opp.get("delivered"):
            return None
        # opponent must be further from the gate than we are (i.e. behind us)
        if self.w.path_distance(onode, self.w.gate_node) <= self.w.path_distance(node, self.w.gate_node):
            return None
        self.guard_nodes.add(node)
        self.guards_set += 1
        return act("SET_GUARD", targetNodeId=node, extraGoodFruit=self.p["guard_extra_fruit"])

    def _handle_obstacle(self, node: str, nxt: str) -> Optional[dict]:
        w = self.w
        me = w.me
        # Prefer clearing via a T04 task (clears + 30 points) if one targets nxt.
        for t in w.tasks:
            if (t.get("taskTemplateId") == "T04" and t.get("nodeId") == nxt
                    and t.get("active") and not t.get("completed") and not t.get("failed")
                    and t.get("taskId") not in self.tried_tasks_here
                    and self._task_free(t)):
                self.tried_tasks_here.add(t.get("taskId"))
                return act("CLAIM_TASK", taskId=t.get("taskId"))
        # Reroute if a comparable clear path exists.
        alt = w.shortest_path(node, (w.gate_node if not me.get("verified") else w.terminal_nodes[0]),
                              fresh_weight=self.p["fresh_weight"],
                              obstacle_penalty=self.p["obstacle_penalty"],
                              guard_penalty=self.p["guard_penalty"],
                              avoid_nodes={nxt})
        if len(alt) >= 2:
            return act("MOVE", targetNodeId=alt[1])
        # Clear it ourselves if we can spare a good fruit.
        if me.get("goodFruit", 0) > 3:
            return act("CLEAR", targetNodeId=nxt)
        return act("FORCED_PASS", targetNodeId=nxt)

    def _handle_guard(self, node: str, nxt: str, goal: str) -> Optional[dict]:
        w = self.w
        me = w.me
        guard = w.enemy_guard(nxt) or {}
        defense = int(guard.get("defense", 0) or 0)

        # A guard is usually cheaper to solve in place than to route around and
        # replay previous edges. First try the zero-time guard break.
        breaker = self._break_guard_action(nxt, defense)
        if breaker:
            return breaker

        direct_cost = self._forced_pass_path_cost_estimate(node, nxt, goal, defense)
        alt = w.shortest_path(
            node,
            goal,
            fresh_weight=0.0,
            obstacle_penalty=self.p["obstacle_penalty"],
            guard_penalty=0.0,
            avoid_nodes={nxt},
        )
        alt_cost = self._guarded_path_frame_estimate(alt)
        margin = float(self.p.get("guard_reroute_margin", 0.0) or 0.0)
        has_pass_card = self._held("PASS_TOKEN") > 0 or self._held("OFFICIAL_PERMIT") > 0
        if (
            len(alt) >= 2
            and alt[1] != nxt
            and math.isfinite(alt_cost)
            and not has_pass_card
            and alt_cost + margin < direct_cost
        ):
            return act("MOVE", targetNodeId=alt[1])
        return act("FORCED_PASS", targetNodeId=nxt)

    def _guard_time_tax_estimate(self, target: str, defense: int) -> int:
        n = self.w.node_state.get(target) or self.w.nodes.get(target) or {}
        ntype = str(n.get("nodeType", "") or "").upper()
        if ntype == "KEY_PASS":
            return min(50, 15 + defense * 5)
        if target == self.w.gate_node:
            return min(32, 12 + defense * 5)
        if self.w.node_has_obstacle(target):
            return min(28, 8 + defense * 5)
        return min(40, 10 + defense * 5)

    def _forced_pass_path_cost_estimate(self, node: str, target: str, goal: str, defense: int) -> float:
        _cost, frames, _fresh = self.w.path_metrics(
            [node, target],
            fresh_weight=0.0,
            per_frame=self._move_per_frame(),
        )
        if not math.isfinite(frames):
            return float("inf")
        total = frames + self._guard_time_tax_estimate(target, defense)
        if target != goal:
            depart_round = self.w.round + int(math.ceil(total))
            _to_goal_cost, to_goal_frames, _to_goal_fresh = self._planned_metrics(
                target,
                goal,
                depart_round=depart_round,
                fresh_weight=0.0,
                per_frame=self._move_per_frame(),
            )
            if not math.isfinite(to_goal_frames):
                return float("inf")
            total += to_goal_frames
        return total

    def _guarded_path_frame_estimate(self, path: List[str]) -> float:
        if len(path) < 2:
            return float("inf")
        _cost, frames, _fresh = self.w.path_metrics(
            path,
            fresh_weight=0.0,
            per_frame=self._move_per_frame(),
        )
        if not math.isfinite(frames):
            return float("inf")
        for target in path[1:]:
            guard = self.w.enemy_guard(target)
            if guard:
                frames += self._guard_time_tax_estimate(target, int(guard.get("defense", 0) or 0))
        return frames

    def _break_guard_action(self, target: str, defense: int) -> Optional[dict]:
        me = self.w.me
        max_good = min(2, int(me.get("goodFruit", 0) or 0))
        max_bad = min(2, int(me.get("badFruit", 0) or 0))
        tactic_mode = str(self.p.get("rush_tactic_mode", "auto") or "auto").lower()
        use_break_order = (
            self.w.phase == "RUSH"
            and not self.used_endgame
            and tactic_mode in ("auto", "save_for_guard")
        )
        bonus = 3 if use_break_order else 0
        best: Optional[tuple[int, int, int]] = None
        for gf in range(max_good + 1):
            for bf in range(max_bad + 1):
                if gf == 0 and bf == 0 and bonus <= 0:
                    continue
                if gf * 2 + bf * 3 + bonus < defense:
                    continue
                candidate = (gf, gf + bf, -bf)
                if best is None or candidate < best:
                    best = candidate
        if best is None:
            return None
        gf, _total, neg_bad = best
        bf = -neg_bad
        payload = {"targetNodeId": target, "goodFruit": gf, "badFruit": bf}
        if use_break_order:
            self.used_endgame = True
            payload["rushTactic"] = "BREAK_ORDER"
        return act("BREAK_GUARD", **payload)

    # ---- tasks ------------------------------------------------------------- #
    def _task_free(self, t: dict) -> bool:
        owner = t.get("ownerPlayerId", 0) or 0
        prot = t.get("protectionPlayerId", 0) or 0
        return owner in (0, self.w.my_id) and prot in (0, self.w.my_id)

    def _claim_task_here(self, node: str) -> Optional[dict]:
        if self.task_base >= self.p["task_base_cap"]:
            return None
        best = None
        best_score = -1
        for t in self.w.tasks:
            if t.get("nodeId") != node:
                continue
            if not t.get("active") or t.get("completed") or t.get("failed"):
                continue
            tid = t.get("taskId")
            if tid in self.tried_tasks_here or tid in self.done_tasks:
                continue
            if not self._task_free(t):
                continue
            tmpl = t.get("taskTemplateId", "")
            score = int(t.get("score", TASK_SCORE.get(tmpl, 0)) or 0)
            if score < self.p["task_min_score"]:
                continue
            if tmpl == "T06" and not self.p["spend_horse_on_t06"]:
                continue  # T06 consumes a horse; skip unless allowed
            if score > best_score:
                best_score = score
                best = t
        if best:
            self.tried_tasks_here.add(best.get("taskId"))
            return act("CLAIM_TASK", taskId=best.get("taskId"))
        return None

    # ---- resources --------------------------------------------------------- #
    def _held(self, rtype: str) -> int:
        return int((self.w.me.get("resources", {}) or {}).get(rtype, 0) or 0)

    def _want_resource(self, rtype: str) -> bool:
        p = self.p
        if rtype == "ICE_BOX":
            return self._held("ICE_BOX") < p["ice_target"]
        if rtype == "FAST_HORSE":
            return p["grab_horses"] and self._held("FAST_HORSE") < p["fast_horse_target"]
        if rtype == "SHORT_HORSE":
            return (p["grab_horses"] and self._held("SHORT_HORSE") < p["short_horse_target"]
                    and self._held("FAST_HORSE") == 0)
        if rtype in ("PASS_TOKEN", "OFFICIAL_PERMIT"):
            return (self._held("PASS_TOKEN") + self._held("OFFICIAL_PERMIT")) < p["permit_target"]
        if rtype == "INTEL":
            return p["claim_intel"] and self._held("INTEL") < 2
        return False

    def _claim_resource_here(self, node: str) -> Optional[dict]:
        n = self.w.node_state.get(node) or {}
        stock = n.get("resourceStock", {}) or {}
        for rtype, cnt in stock.items():
            if cnt and cnt > 0 and rtype not in self.claimed_res_here and self._want_resource(rtype):
                self.claimed_res_here.add(rtype)
                return act("CLAIM_RESOURCE", targetNodeId=node, resourceType=rtype)
        return None

    # ---- freshness / horses / endgame -------------------------------------- #
    def _has_move_buff(self) -> bool:
        for b in self.w.me.get("buffs", []) or []:
            if b.get("type") in ("FAST_HORSE", "SHORT_HORSE", "RUSH_SPEED") and int(b.get("remainingRound", 0) or 0) > 0:
                return True
        return False

    def _move_per_frame(self) -> int:
        per_frame = BASE_MOVE_PER_FRAME
        for b in self.w.me.get("buffs", []) or []:
            if int(b.get("remainingRound", 0) or 0) <= 0:
                continue
            per_frame = max(per_frame, MOVE_BUFF_PER_FRAME.get(str(b.get("type", "") or "").upper(), per_frame))
        return per_frame

    def _use_ice(self) -> dict:
        self.last_ice_round = self.w.round
        return act("USE_RESOURCE", resourceType="ICE_BOX")

    def _maybe_use_ice(self) -> Optional[dict]:
        me = self.w.me
        fresh = float(me.get("freshness", 100) or 100)
        if fresh <= 0 or self._held("ICE_BOX") <= 0:
            return None
        if self.w.round - self.last_ice_round < 1:
            return None
        # Emergency: prevent good->bad spoilage regardless of mode.
        if fresh < self.p["ice_emergency"]:
            return self._use_ice()
        if self.p["ice_end_save"]:
            # Hold ice for the final approach, then dump it so the +10 sticks.
            rem = self._remaining_frames(me.get("currentNodeId"), self.w.terminal_nodes[0])
            if rem <= self.p["ice_end_frames"] and fresh < self.p["ice_end_cap"]:
                return self._use_ice()
            return None
        # Threshold mode.
        if fresh < self.p["ice_use_threshold"] and self.w.round - self.last_ice_round >= self.p["ice_use_min_gap"]:
            return self._use_ice()
        return None

    def _maybe_use_horse(self, moving: bool) -> Optional[dict]:
        if not self.p["use_horses"]:
            return None
        me = self.w.me
        if self._has_move_buff():
            return None
        node = me.get("currentNodeId")
        goal = self.w.gate_node if not me.get("verified") else self.w.terminal_nodes[0]
        # estimate remaining frames roughly from remaining route distance
        remain = self._remaining_frames(node, goal)
        if remain < self.p["horse_min_frames"]:
            return None
        if self._held("FAST_HORSE") > 0:
            return act("USE_RESOURCE", resourceType="FAST_HORSE")
        if self._held("SHORT_HORSE") > 0:
            return act("USE_RESOURCE", resourceType="SHORT_HORSE")
        return None

    def _remaining_frames(self, node: Optional[str], goal: str) -> float:
        if not node:
            return 0.0
        _cost, frames, _fresh_loss = self._planned_metrics(
            node,
            goal,
            fresh_weight=0.0,
            per_frame=self._move_per_frame(),
        )
        return frames

    def _maybe_endgame_before_gate(self) -> Optional[dict]:
        if self.used_endgame:
            return None
        me = self.w.me
        tactic_mode = str(self.p.get("rush_tactic_mode", "auto") or "auto").lower()
        if tactic_mode in ("break_gate", "save_for_guard"):
            return None
        if (
            tactic_mode in ("auto", "protect")
            and self.p["use_protect"]
            and float(me.get("freshness", 100) or 100) < self.p["protect_freshness_below"]
        ):
            self.used_endgame = True
            return act("RUSH_PROTECT")
        if tactic_mode in ("auto", "speed") and self.p["use_rush_speed"] and not self._has_move_buff():
            self.used_endgame = True
            return act("RUSH_SPEED")
        return None

    def _should_bind_gate_break_order(self) -> bool:
        if self.used_endgame or not self.p.get("gate_break_order", True):
            return False
        tactic_mode = str(self.p.get("rush_tactic_mode", "auto") or "auto").lower()
        if tactic_mode not in ("auto", "break_gate"):
            return False
        me = self.w.me
        return int(me.get("badFruit", 0) or 0) >= 2 or int(me.get("goodFruit", 0) or 0) >= 1

    def _process_action(self, node: str) -> dict:
        n = self.w.node_state.get(node) or {}
        if n.get("processType") == "BOARD":
            return act("DOCK", targetNodeId=node)
        return act("PROCESS", targetNodeId=node)

    def _process_temporarily_blocked(self, node: str) -> bool:
        until = int(self.process_blocked_until.get(node, 0) or 0)
        if until <= 0:
            return False
        if self.w.round < until:
            return True
        self.process_blocked_until.pop(node, None)
        return False

    # ---- window & squad hooks (overridable) -------------------------------- #
    def decide_window(self) -> Optional[dict]:
        mode = self.p["window_mode"]
        w = self.w
        for c in w.contests:
            if c.get("status") == "SUPPRESSED" or c.get("resolved"):
                continue
            if c.get("redPlayerId") != w.my_id and c.get("bluePlayerId") != w.my_id:
                continue
            ctype = c.get("contestType")
            mandatory = ctype in ("GATE", "DOCK", "PASS", "OBSTACLE")
            if mode == "none" and not mandatory:
                return None
            value = self._window_value(c)
            valuable = mandatory or value >= float(self.p.get("window_optional_min_value", 0) or 0)
            if ctype == "TASK" and value >= float(self.p.get("window_task_critical_score", 30) or 30):
                valuable = True
            if ctype == "RESOURCE" and self.p["window_mode"] == "aggressive" and value > 0:
                valuable = value >= float(self.p.get("window_optional_min_value", 0) or 0)
            if not valuable and self.p["window_mode"] != "aggressive":
                return act("WINDOW_CARD", contestId=c.get("contestId"), card="ABSTAIN")
            if not valuable:
                return act("WINDOW_CARD", contestId=c.get("contestId"), card="ABSTAIN")
            if self.p.get("window_clinch_abstain", True) and self._window_already_clinched(c):
                return act("WINDOW_CARD", contestId=c.get("contestId"), card="ABSTAIN")
            card = self._repeat_counter_card(c, value, mandatory)
            if not card and self._should_abstain_repeated_window(c, value, mandatory):
                card = "ABSTAIN"
            if not card:
                card = self._best_card(c)
            if self._should_conserve_window_card(card, c, value, mandatory):
                card = "ABSTAIN"
            return act("WINDOW_CARD", contestId=c.get("contestId"), card=card)
        return None

    def _window_points(self, contest: dict) -> Tuple[int, int]:
        red = int(contest.get("redPoint", 0) or 0)
        blue = int(contest.get("bluePoint", 0) or 0)
        if self.w.my_team == "RED":
            return red, blue
        return blue, red

    def _window_already_clinched(self, contest: dict) -> bool:
        my_point, opp_point = self._window_points(contest)
        return my_point >= 2 or opp_point >= 2

    def _window_value(self, contest: dict) -> float:
        ctype = contest.get("contestType")
        if ctype in ("GATE", "DOCK", "PASS", "OBSTACLE"):
            return 100.0
        if ctype == "TASK":
            tid = contest.get("taskId")
            for t in self.w.tasks:
                if t.get("taskId") == tid:
                    tmpl = t.get("taskTemplateId", "")
                    return float(int(t.get("score", TASK_SCORE.get(tmpl, 0)) or 0))
            return 0.0
        if ctype == "RESOURCE":
            return float(RESOURCE_WINDOW_VALUE.get(str(contest.get("resourceType", "") or "").upper(), 6))
        return 0.0

    def _should_conserve_window_card(self, card: str, contest: dict, value: float, mandatory: bool) -> bool:
        if card == "ABSTAIN" or mandatory:
            return False
        me = self.w.me
        high_value = value >= float(self.p.get("window_task_critical_score", 30) or 30)
        if high_value:
            return False
        if card == "XIAN_GONG":
            reserve = int(self.p.get("window_good_reserve", 0) or 0)
            return int(me.get("goodFruit", 0) or 0) <= reserve
        if card == "YAN_DIE":
            reserve = int(self.p.get("window_token_reserve", 0) or 0)
            return self._held("PASS_TOKEN") + self._held("OFFICIAL_PERMIT") <= reserve
        if card == "QIANG_XING":
            if self._has_move_buff():
                return False
            reserve = int(self.p.get("window_horse_reserve", 0) or 0)
            return self._held("FAST_HORSE") + self._held("SHORT_HORSE") <= reserve
        if card == "BING_ZHENG":
            reserve = int(self.p.get("window_guard_point_reserve", 0) or 0)
            return int(me.get("guardActionPoint", 0) or 0) <= reserve
        return False

    def _should_abstain_repeated_window(self, contest: dict, value: float, mandatory: bool) -> bool:
        if mandatory:
            return False
        cid = str(contest.get("contestId", "") or "")
        threshold = int(self.p.get("window_repeat_draw_abstain_after", 0) or 0)
        if threshold <= 0 or self.window_draws.get(cid, 0) < threshold:
            return False
        critical = float(self.p.get("window_task_critical_score", 30) or 30)
        return value < critical

    def _repeat_counter_card(self, contest: dict, value: float, mandatory: bool) -> Optional[str]:
        if not self.p.get("window_repeat_counter", True):
            return None
        cid = str(contest.get("contestId", "") or "")
        opp_cards = self.window_opp_cards.get(cid) or []
        if not opp_cards:
            return None
        if not mandatory and value < float(self.p.get("window_repeat_counter_min_value", 0) or 0):
            return None
        last_opp = opp_cards[-1]
        for card in self._winning_cards_against(last_opp):
            if not self._card_available(card):
                continue
            if self._should_conserve_window_card(card, contest, value, mandatory):
                continue
            return card
        return None

    @staticmethod
    def _card_wins(card: str, opponent_card: str) -> bool:
        if card == "ABSTAIN":
            return False
        if opponent_card == "ABSTAIN":
            return True
        if card == opponent_card:
            return False
        return CARD_RESULT.get((card, opponent_card), 0) > 0

    def _winning_cards_against(self, opponent_card: str) -> List[str]:
        preferred = ["BING_ZHENG", "XIAN_GONG", "YAN_DIE", "QIANG_XING"]
        return [card for card in preferred if self._card_wins(card, opponent_card)]

    def _card_available(self, card: str) -> bool:
        me = self.w.me
        if card == "YAN_DIE":
            return self._held("PASS_TOKEN") > 0 or self._held("OFFICIAL_PERMIT") > 0
        if card == "QIANG_XING":
            return self._has_move_buff() or self._held("FAST_HORSE") > 0 or self._held("SHORT_HORSE") > 0
        if card == "XIAN_GONG":
            return float(me.get("freshness", 0) or 0) >= 80 and int(me.get("goodFruit", 0) or 0) >= 1
        if card == "BING_ZHENG":
            return int(me.get("guardActionPoint", 0) or 0) > 0
        return card == "ABSTAIN"

    def _best_card(self, contest: Optional[dict] = None) -> str:
        me = self.w.me
        ctype = (contest or {}).get("contestType")
        mandatory = ctype in ("GATE", "DOCK", "PASS", "OBSTACLE")
        fresh = float(me.get("freshness", 0) or 0)
        good = int(me.get("goodFruit", 0) or 0)
        opp = self.w.opp or {}
        if ctype == "PASS":
            attacker = (contest or {}).get("attackerTeamId")
            if attacker == self.w.my_team:
                if int(opp.get("guardActionPoint", 0) or 0) > 0 and fresh >= 80 and good >= 1:
                    return "XIAN_GONG"
                if self._held("PASS_TOKEN") or self._held("OFFICIAL_PERMIT"):
                    return "YAN_DIE"
                if fresh >= 80 and good >= 1:
                    return "XIAN_GONG"
            elif int(me.get("guardActionPoint", 0) or 0) > 0:
                return "BING_ZHENG"
        if mandatory and fresh >= 80 and good >= 1:
            return "XIAN_GONG"
        # BING_ZHENG beats YAN_DIE+QIANG_XING; XIAN_GONG beats YAN_DIE+BING_ZHENG.
        if int(me.get("guardActionPoint", 0) or 0) > 0:
            return "BING_ZHENG"
        if fresh >= 80 and good >= 1:
            return "XIAN_GONG"
        if self._has_move_buff() or self._held("FAST_HORSE") or self._held("SHORT_HORSE"):
            return "QIANG_XING"
        if self._held("PASS_TOKEN") or self._held("OFFICIAL_PERMIT"):
            return "YAN_DIE"
        return "ABSTAIN"

    def decide_squad(self) -> Optional[dict]:
        mode = self.p["squad_mode"]
        if mode == "none":
            return None
        w = self.w
        me = w.me
        if w.phase == "RUSH":
            return None  # no new squads allowed after rush starts
        if me.get("state") == "MOVING":
            return None
        avail = int(me.get("squadAvailable", 0) or 0)
        if avail <= self.p["squad_scout_reserve"]:
            return None
        if w.round - self.squad_used_round < self.p["squad_min_gap"]:
            return None
        node = me.get("currentNodeId")
        if not node:
            return None

        if mode == "combat":
            goal = self._current_goal(node)
            path = self._plan_path(node, goal)
            # 1) weaken an enemy guard on our forward path
            if self.p.get("squad_weaken_guards", True) and avail >= 2:
                for v in path[1:]:
                    g = w.enemy_guard(v)
                    if g and int(g.get("defense", 0) or 0) > 0:
                        self.squad_used_round = w.round
                        return act("SQUAD_WEAKEN", targetNodeId=v)
            # 2) clear an obstacle on our forward path (needs 2 hands)
            if self.p.get("squad_clear_obstacles", True) and avail >= 2:
                for v in path[1:]:
                    if w.node_has_obstacle(v):
                        self.squad_used_round = w.round
                        return act("SQUAD_CLEAR", targetNodeId=v)

        # scout a heavy-process node ahead to cut its read-bar (>=4 rounds saves most)
        tgt = self._scout_target(node)
        if tgt:
            self.squad_used_round = w.round
            self.scouted_by_us.add(tgt)
            return act("SQUAD_SCOUT", targetNodeId=tgt)
        return None

    def _scout_target(self, node: str) -> Optional[str]:
        """Pick the next heavy mandatory-process node ahead that we haven't scouted."""
        w = self.w
        goal = self._current_goal(node)
        path = self._plan_path(node, goal)
        for v in path[1:]:
            live = w.node_state.get(v) or {}
            static = w.nodes.get(v) or {}
            if self._should_scout_task_node(v) and self._scout_target_viable(node, v, live):
                return v
            # Scout markers can shorten live processRound; use static rounds to
            # keep the first heavy station as the gate for later scout targets.
            pr = int(static.get("processRound", live.get("processRound", 0)) or 0)
            ptype = live.get("processType") or static.get("processType")
            # scout stations with a real read-bar (mandatory transfer or gate verify)
            min_process = int(self.p.get("squad_scout_min_process", 4) or 4)
            if pr >= min_process and (ptype in MANDATORY_PROCESS or v == w.gate_node):
                if self._scout_target_viable(node, v, live):
                    return v
        return None

    def _should_scout_task_node(self, target: str) -> bool:
        if not self.p.get("squad_scout_tasks", True):
            return False
        min_score = int(self.p.get("squad_scout_task_min_score", 30) or 30)
        for t in self.w.tasks:
            if not t.get("active") or t.get("completed") or t.get("failed"):
                continue
            if t.get("nodeId") != target:
                continue
            if not self._task_free(t):
                continue
            tmpl = t.get("taskTemplateId", "")
            score = int(t.get("score", TASK_SCORE.get(tmpl, 0)) or 0)
            if score >= min_score:
                return True
        return False

    def _scout_target_viable(self, source: str, target: str, live: dict) -> bool:
        if target in self.scouted_by_us:
            return False
        for marker in (live.get("scouted") or []):
            if marker.get("teamId") == self.w.my_team and int(marker.get("remainRound", 0) or 0) > 0:
                return False
        max_eta = float(self.p.get("squad_scout_max_eta", 0) or 0)
        eta = self._remaining_frames(source, target)
        scout_delay = self.w.squad_scout_delay(source, target, submit_round=self.w.round)
        if eta <= scout_delay:
            return False
        if max_eta > 0 and eta > scout_delay + max_eta:
            return False
        return True

    # ---- event absorption -------------------------------------------------- #
    def _absorb_events(self) -> None:
        w = self.w
        me = w.me
        node = me.get("currentNodeId")

        # Track the live read-bar object. When it clears, a station PROCESS
        # only a PROCESS_COMPLETE event means we may now leave this node.
        proc = me.get("currentProcess")
        if proc:
            self._active_obj = proc.get("objectKey") or self._active_obj
        else:
            self._active_obj = None

        # task base from completed tasks I own
        base = 0
        for t in w.tasks:
            if t.get("completed") and (t.get("ownerPlayerId", 0) or 0) == w.my_id:
                tmpl = t.get("taskTemplateId", "")
                base += TASK_SCORE.get(tmpl, int(t.get("score", 0) or 0))
                self.done_tasks.add(t.get("taskId"))
        # trust the server's own taskScore if present
        self.task_base = max(self.task_base, base, int(me.get("taskScore", 0) or 0))

        # calibrate ms-per-frame from live movement telemetry
        if me.get("state") == "MOVING":
            mpr = int(me.get("moveProgressRound", 0) or 0)
            ems = int(me.get("edgeProgressMs", 0) or 0)
            if mpr > 0 and ems > 0:
                self.ms_per_frame = max(100.0, ems / mpr)

        for ev in w.events:
            etype = ev.get("type")
            pl = ev.get("payload", {}) or {}
            if etype == "WINDOW_CARD_REVEAL":
                cid = str(pl.get("contestId", "") or "")
                idx = int(pl.get("roundIndex", 0) or 0)
                key = (cid, idx)
                if cid and idx and key not in self.window_seen_reveals:
                    self.window_seen_reveals.add(key)
                    my_card = pl.get("redCard") if w.my_team == "RED" else pl.get("blueCard")
                    opp_card = pl.get("blueCard") if w.my_team == "RED" else pl.get("redCard")
                    if my_card:
                        self.window_my_cards.setdefault(cid, []).append(str(my_card))
                    if opp_card:
                        self.window_opp_cards.setdefault(cid, []).append(str(opp_card))
                    if not pl.get("winner"):
                        self.window_draws[cid] = self.window_draws.get(cid, 0) + 1
                continue
            _pid = pl.get("playerId")
            if _pid is not None and str(_pid) != str(w.my_id):
                continue
            if etype == "PROCESS_COMPLETE":
                target = pl.get("targetNodeId") or pl.get("nodeId")
                if target == node:
                    self.processed_here = True
                    self.force_process = False
            elif etype in ("SCOUT_MARKER_EXPIRE", "SCOUT_MARKER_CONSUME"):
                tgt = pl.get("targetNodeId") or pl.get("nodeId")
                if tgt:
                    self.scouted_by_us.discard(tgt)
            elif etype == "WINDOW_CONTEST_REPEAT_SUPPRESSED":
                tgt = pl.get("targetNodeId") or node
                until = int(pl.get("suppressUntilRound", 0) or 0)
                if tgt and until:
                    self.process_blocked_until[tgt] = max(self.process_blocked_until.get(tgt, 0), until)
            elif etype in ("ACTION_REJECTED", "INVALID_ACTION"):
                if pl.get("errorCode") == "PROCESS_REQUIRED":
                    self.processed_here = False
                    self.force_process = True
                elif pl.get("errorCode") == "WINDOW_DRAW_RETRY_LIMIT":
                    self.processed_here = False
