import argparse
import json
import socket
import sys
from dataclasses import dataclass
from typing import Any

from protocol import action_message, read_frame, ready_message, registration_message, write_frame
from strategy import Strategy


@dataclass(frozen=True)
class Config:
    player_id: int
    host: str
    port: int
    player_name: str
    version: str


def parse_args() -> Config:
    parser = argparse.ArgumentParser(description="Lychee arena strategy client")
    parser.add_argument("--player-id", type=int, required=True)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--player-name", default="my-python-client")
    parser.add_argument("--version", default="0.1")
    args = parser.parse_args()
    return Config(
        player_id=args.player_id,
        host=args.host,
        port=args.port,
        player_name=args.player_name,
        version=args.version,
    )


class Client:
    def __init__(self, sock: socket.socket, config: Config) -> None:
        self.sock = sock
        self.config = config
        self.strategy = Strategy(config.player_id)
        self.match_id = ""

    def run(self) -> int:
        write_frame(
            self.sock,
            registration_message(
                self.config.player_id,
                self.config.player_name,
                self.config.version,
            ),
        )

        while True:
            try:
                message = read_frame(self.sock)
            except EOFError:
                print("connection closed")
                return 0

            result = self.handle_message(message)
            if result is not None:
                return result

    def handle_message(self, message: dict[str, Any]) -> int | None:
        msg_name = message.get("msg_name")
        data = message.get("msg_data") or {}

        if msg_name == "start":
            self.handle_start(data)
        elif msg_name == "inquire":
            self.handle_inquire(data)
        elif msg_name == "over":
            print("over received")
            return 0
        elif msg_name == "error":
            print(f"error received: {json.dumps(message, ensure_ascii=False)}", file=sys.stderr)
            return 1
        else:
            print(f"ignored msg_name={msg_name}")

        return None

    def handle_start(self, data: dict[str, Any]) -> None:
        self.match_id = data["matchId"]
        self.strategy.on_start(data)
        round_no = data.get("round", 1)
        print(f"start match={self.match_id} team={self.strategy.team_id} round={round_no}")
        write_frame(self.sock, ready_message(self.match_id, round_no, self.config.player_id))

    def handle_inquire(self, data: dict[str, Any]) -> None:
        round_no = data["round"]
        actions = self.strategy.decide(data)
        print(f"inquire round={round_no} actions={actions}")
        write_frame(self.sock, action_message(self.match_id, round_no, self.config.player_id, actions))


def main() -> int:
    config = parse_args()
    with socket.create_connection((config.host, config.port)) as sock:
        print(f"connected to {config.host}:{config.port} as player {config.player_id}")
        return Client(sock, config).run()


if __name__ == "__main__":
    raise SystemExit(main())
