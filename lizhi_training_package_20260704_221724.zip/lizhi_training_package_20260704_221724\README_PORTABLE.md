# 荔枝争运训练包使用说明

这个包用于在另一台 Windows 机器上继续训练策略、验证比赛、生成最终 `client` 提交文件夹。

## 1. 环境

- 安装 Python 3.10 或更新版本。
- 解压后在命令行进入本目录：

```bat
cd /d 你的解压目录\lizhi_training_package
```

先跑一次测试：

```bat
python -m unittest discover -s tests
```

## 2. 快速验证

```bat
.\train_model.bat smoke 2
```

`smoke` 只用于检查环境和流程是否正常。

## 3. 正式训练

推荐先用：

```bat
.\train_model.bat fast 4 20
```

更大规模：

```bat
.\train_model.bat big 8 50 resume
```

强对抗训练：

```bat
.\train_model.bat hard 8 50 resume
```

参数含义：

- 第 1 个参数：`smoke`、`fast`、`mid`、`big`、`hard`
- 第 2 个参数：并行数，例如 `8`
- 第 3 个参数：目标总代数，例如 `50`
- 第 4 个参数：写 `resume` 时从对应 `runs\train_MODE\history.json` 续跑到目标总代数；如果没有 history，会从已有 `best_params.json` 种子重新起一轮。

`big` 默认每个候选会打：

```text
4 个对手 × 8 个种子 × 4 种障碍 × 红蓝双方 = 256 场
12 个候选 = 3072 场 / 代
```

`hard` 会做更强的对抗训练：

- 自动继承已有的 `runs\train_fast`、`runs\train_mid`、`runs\train_big`、`runs\train_hard` 以及对应 `_nn` 预测参数，把它们放进新一轮候选种群继续繁殖。
- 自动把 `big/hard` 的 best 参数加入对手池，不只是拿弱基准练。
- 每代前几名精英会晋升为 `selfplay:Gx-Cy` 快照对手，下一代候选会和历史优胜者对抗。
- 使用更大的 seed 池，但每几代才轮换一部分 seed，避免每代地图局面乱跳。

训练日志里：

- `last=0:0` 只表示最近打印点的最后一场，不代表全部没分。
- `last=W 590:424 vs=direct_runner seed=1 obs=0 side=BLUE` 表示最近一场赢了，对手、seed、障碍数和红蓝方都列在后面。
- `scored=64/96` 表示当前候选已完成 96 场里有 64 场拿到非零分。
- `delivered=60/96` 表示当前候选已完成 96 场里有 60 场真正完成交付。
- `score700=12/96` 表示当前候选有 12 场达到 700 分以上。
- `task90=40/96` 表示当前候选有 40 场普通任务基础分达到 90，达到 90 后送达基础分和用时分不再被任务系数折减。
- `fresh` / `recentFresh` 表示平均终局鲜度；`switch` 表示路线切换/疑似回头；`iceUsed` 表示平均冰鉴使用次数；`guardBlock` 表示自己被移动中守卫卡住的轮数。
- `nodeWait` 表示已经能决策时仍停在节点等待的轮数；`reject` 表示动作被裁判拒绝的次数；`illegal` / `missing` 表示非法动作和缺失动作；`hardErr` / `invalid` 表示客户端崩溃、协议硬错误或异常判负场次；`winDraw` / `winSuppress` 表示窗口对拼连续平局和重复平局被裁判压制的次数。这几个值越高，越说明策略可能又陷入了“平局后等、移动后不续走、重复发无效动作”的老问题。
- `oppGuardBlock` / `oppSquadWeak` 表示我方设卡是否真的拖住对手，或只是逼对方花小分队拆掉。
- `ranking summary` 会列出每代候选排名、对各对手的 W/L/D、谁 `[survive]` 进入下一代、谁是 `globalBest`。
- `recentScore` 是最近一段比赛均分，更适合判断模型是否还在演进。

如果想逐场打印日志，可以先执行：

```bat
set LIZHI_MATCH_LOG_EVERY=1
```

关闭逐场日志：

```bat
set LIZHI_MATCH_LOG_EVERY=
```

训练会跨不同随机种子评估，种子会改变天气日程。客户端路径估计会读取当前天气和 30 帧内预报，计算暴雨水路、山雾山路、炎热鲜度损耗以及水路处理加时；优化器会搜索 `fresh_weight`、偏好水路/陆路/山路任务、冰鉴储备、终局冰鉴释放阈值和使用间隔。

保鲜相关规则：

- `ICE_BOX` 是唯一直接提高鲜度的随车资源，使用后鲜度 +10，上限 100。
- `RUSH_PROTECT` 是终局急策，不加鲜度，但 30 帧内鲜度损耗变为 20%。
- 客户端在 S15 交付前会检查剩余 `ICE_BOX`，只要有效增鲜足够，就先使用再交付，避免把保鲜分浪费掉。

小分队也会进入训练：`squad_mode` 会在侦察、战斗、禁用之间搜索；侦察会优先处理高分任务点、重处理点和宫门前关键点；战斗模式会学习是否用小分队削弱守卫、清理障碍，以及派遣间隔和最大可接受 ETA。窗口策略会记忆对手已亮出的牌，低价值重复平局会倾向弃权，高价值窗口会尝试反制对手重复牌，避免被对方一直拖成平局损失时间和新鲜度。

## 4. 生成提交 client

训练完成后执行：

```bat
.\build_submit_client.bat
```

默认会按 `train_hard`、`train_big`、`train_mid`、`train_fast`、`train_smoke` 的优先级选择已有 `best_params.json`，不会因为 smoke 文件较新就误拿检查参数。

默认输出：

```text
submission\client
```

指定参数文件和目标目录：

```bat
.\build_submit_client.bat .\runs\train_big\best_params.json D:\my_submit\client
```

生成的提交目录会冻结 `best_params.json`，不依赖训练目录。

## 5. 手动验证一局

```bat
python .\run_match.py --red .\client --blue .\players\direct_runner --red-params "@.\runs\train_big\best_params.json" --out .\runs\validate_best --port 0 --timeout-ms 80 --rounds 600 --quiet-clients
```

验证可视化页面会在对应 `runs\...\viewer.html` 里生成。

## 6. 包内容说明

本迁移包包含：

- `arena` 比赛引擎、可视化、优化器、神经网络代理训练
- `client` 当前选手策略
- `players` 对抗基准策略
- `configs` 手工策略种子
- `tests` 单元测试
- 协议书和任务书
- `train_model.bat`、`build_submit_client.bat`
- `submission\client.zip`：已修复并可直接上交的提交包
- `MAINTENANCE_NOTES.md`：后续维护说明，解释关键规则、训练日志字段和改动检查顺序

本迁移包只保留少量训练继承种子：

- `runs\train_*\best_params.json`
- `runs\train_*_nn\best_predicted_params.json`

这些文件不是日志，用于让 `train_model.bat ... resume` 或新训练自动继承历史较优参数。

本迁移包不包含：

- `runs` 训练日志、回放、`history.json`、`viewer.html`、逐局结果
- `submission` 展开的提交目录和旧提交备份，只保留最新 `submission\client.zip`
- `错误日志`、旧的 `portable_package`
- `__pycache__`、`.pyc` 缓存
