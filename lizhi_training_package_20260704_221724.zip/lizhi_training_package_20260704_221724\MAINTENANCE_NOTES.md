# Maintenance Notes

This project has several rule details that are easy to regress. Read this file
before changing `client/core.py`, `arena/engine.py`, or `arena/optimizer.py`.

## Critical Rule Invariants

- `ICE_BOX` is the only normal resource that directly increases freshness. It
  adds `+10` freshness, capped at 100.
- `RUSH_PROTECT` does not increase freshness. It only reduces future freshness
  loss to 20% for 30 rounds.
- Before `DELIVER`, the client must check for useful remaining `ICE_BOX`
  resources. Delivery locks the freshness score.
- If a guard appears on the next node while a player is already moving on an
  edge, progress freezes and freshness still drops. This is represented by
  `MOVE_BLOCKED_BY_GUARD` and `guardBlockedRounds`.
- Mid-edge rerouting is intentionally conservative. Returning to the origin can
  waste edge progress, time score, and freshness.
- Task and ice detours should stay forward unless explicitly configured
  otherwise. Small task gains can be worse than backtracking loss.
- Guard placement has cost: processing time plus possible good-fruit cost.
  Because opponents can often answer with cheap `SQUAD_WEAKEN`, training should
  reward guards only when they actually stall or consume opponent resources.
- Do not add local client-side cooldown after contest-window errors. The
  official platform is stable enough to reject/accept each frame; the strategy
  should keep producing useful actions and let the referee decide.

## Training Log Fields

- `avgScore` / `recentScore`: score level and short-window trend.
- `task90`: matches with at least 90 base task score. This matters because the
  delivery and time score coefficients stop being task-limited at 90.
- `fresh` / `recentFresh`: delivery freshness trend.
- `switch`: route-switch count, used as a backtracking proxy.
- `iceUsed`: average `ICE_BOX` uses. If this is low while freshness is low,
  inspect ice routing and pre-delivery use.
- `guardBlock`: rounds where our player was stalled by an enemy mid-edge guard.
- `nodeWait`: rounds where the candidate was able to act at a node but waited.
- `reject`: referee action rejects. Spikes usually mean stale PROCESS, move, or
  contest logic.
- `illegal` / `missing`: illegal action count and missing-action rounds. These
  are hard training signals, not cosmetic warnings.
- `hardErr` / `invalid`: local training exceptions, client crashes, abnormal
  exits, or invalid match results. Optimizer fitness strongly penalizes them
  and should not promote those candidates.
- `winDraw` / `winSuppress`: repeated contest-window draws and platform
  suppression. These are penalized so training stops selecting policies that
  feed low-value repeated draws.
- `oppGuardBlock`: rounds where our guards stalled the opponent.
- `oppSquadWeak`: opponent `SQUAD_WEAKEN` uses, a proxy for whether our guards
  forced resource pressure even if they did not stall long.

## Files To Inspect First

- `client/core.py`: live strategy and rule reactions.
- `arena/engine.py`: local referee simulation used by training.
- `arena/optimizer.py`: evolutionary fitness and training logs.
- `train_model.bat`: mode sizes, inherited parameter seeds, and log cadence.
- `README_PORTABLE.md`: user-facing training and packaging guide.

## Safe Change Pattern

1. Keep the log field names stable unless you update README/docs too.
2. Run `python -m py_compile arena\engine.py arena\optimizer.py arena\neural_surrogate.py client\core.py client\strategy.py`.
3. Run a smoke optimizer check before packaging.
4. Rebuild `submission\client.zip` after any `client` change.
5. When building a portable training package, include only best parameter seeds
   under `runs`, not `history.json`, replays, viewers, or error logs.
