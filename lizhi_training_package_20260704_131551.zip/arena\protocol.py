from __future__ import annotations

import json
import socket
from typing import Any, List

MAX_BODY = 99999


class ProtocolError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def encode_frame(message: dict[str, Any]) -> bytes:
    body = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_BODY:
        raise ProtocolError("INVALID_LENGTH_PREFIX", f"message too large: {len(body)}")
    return f"{len(body):05d}".encode("ascii") + body


def write_frame(sock: socket.socket, message: dict[str, Any]) -> None:
    sock.sendall(encode_frame(message))


def read_exact(sock: socket.socket, length: int) -> bytes:
    chunks: list[bytes] = []
    remaining = length
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise EOFError("connection closed")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def read_frame(sock: socket.socket) -> dict[str, Any]:
    prefix = read_exact(sock, 5)
    try:
        length = int(prefix.decode("ascii"))
    except ValueError as exc:
        raise ProtocolError("INVALID_LENGTH_PREFIX", f"invalid prefix {prefix!r}") from exc
    if length < 0 or length > MAX_BODY:
        raise ProtocolError("INVALID_LENGTH_PREFIX", f"invalid length {length}")
    body = read_exact(sock, length)
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception as exc:
        raise ProtocolError("INVALID_JSON", str(exc)) from exc
    if not isinstance(data, dict):
        raise ProtocolError("INVALID_JSON", "message body must be a JSON object")
    return data


class FrameBuffer:
    """Incremental 5-byte length-prefixed frame decoder."""

    def __init__(self) -> None:
        self._buf = bytearray()

    def feed(self, data: bytes) -> List[dict[str, Any]]:
        self._buf.extend(data)
        frames: list[dict[str, Any]] = []
        while True:
            if len(self._buf) < 5:
                break
            prefix = bytes(self._buf[:5])
            try:
                length = int(prefix.decode("ascii"))
            except ValueError as exc:
                self._buf.clear()
                raise ProtocolError("INVALID_LENGTH_PREFIX", f"invalid prefix {prefix!r}") from exc
            if length < 0 or length > MAX_BODY:
                self._buf.clear()
                raise ProtocolError("INVALID_LENGTH_PREFIX", f"invalid length {length}")
            if len(self._buf) < 5 + length:
                break
            body = bytes(self._buf[5:5 + length])
            del self._buf[:5 + length]
            try:
                msg = json.loads(body.decode("utf-8"))
            except Exception as exc:
                raise ProtocolError("INVALID_JSON", str(exc)) from exc
            if not isinstance(msg, dict):
                raise ProtocolError("INVALID_JSON", "message body must be a JSON object")
            frames.append(msg)
        return frames


def error_message(round_no: int, player_id: Any, code: str, message: str) -> dict[str, Any]:
    return {
        "msg_name": "error",
        "msg_data": {
            "round": round_no,
            "playerId": player_id,
            "errorCode": code,
            "message": message,
        },
    }
