from __future__ import annotations

import argparse
import heapq
import json
import math
import os
import socket
from typing import Any, Optional


ROUTE_COEFF = {"ROAD": 1380, "WATER": 1250, "MOUNTAIN": 1780, "BRANCH": 1550}
MANDATORY_PROCESS = {"TRANSFER", "BOARD", "WATER_TRANSFER", "PASS_TRANSFER", "PALACE_TRANSFER"}


def read_exact(sock: socket.socket, length: int) -> bytes:
    chunks = []
    remaining = length
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise EOFError("connection closed")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def read_frame(sock: socket.socket) -> dict[str, Any]:
    prefix = read_exact(sock, 5)
    length = int(prefix.decode("ascii"))
    return json.loads(read_exact(sock, length).decode("utf-8"))


def write_frame(sock: socket.socket, message: dict[str, Any]) -> None:
    body = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    sock.sendall(f"{len(body):05d}".encode("ascii") + body)


class DirectRunner:
    def __init__(self, player_id: Any) -> None:
        self.player_id = player_id
        self.match_id = ""
        self.nodes: dict[str, dict[str, Any]] = {}
        self.adj: dict[str, list[dict[str, Any]]] = {}
        self.gate = "S14"
        self.finish = "S15"
        self.processed_nodes: set[str] = set()
        self.last_node: Optional[str] = None
        self.horse_showcase = os.environ.get("HORSE_SHOWCASE", "") == "1"
        self.rules_showcase = os.environ.get("RULES_SHOWCASE", "") == "1"
        self.guard_trapper = os.environ.get("GUARD_TRAPPER", "") == "1"
        self.window_baiter = os.environ.get("WINDOW_BAITER", "") == "1"
        self.horse_used: set[str] = set()
        self.resource_used: set[str] = set()
        self.showcase_nodes_seen: set[str] = set()
        self.tried_tasks: set[str] = set()
        self.guards_set: set[str] = set()
        self.reinforced_guards: set[str] = set()

    def on_start(self, data: dict[str, Any]) -> None:
        self.match_id = data["matchId"]
        roles = ((data.get("map") or {}).get("gameplay") or {}).get("roles") or {}
        self.gate = roles.get("gateNodeId", "S14")
        self.finish = (roles.get("terminalNodeIds") or ["S15"])[0]
        self.nodes = {n["nodeId"]: n for n in data.get("nodes", [])}
        self.adj = {nid: [] for nid in self.nodes}
        for edge in data.get("edges", []):
            self._add_edge(edge)
            if edge.get("bidirectional", True):
                rev = dict(edge)
                rev["fromNodeId"], rev["toNodeId"] = edge["toNodeId"], edge["fromNodeId"]
                self._add_edge(rev)

    def _add_edge(self, edge: dict[str, Any]) -> None:
        self.adj.setdefault(edge["fromNodeId"], []).append(edge)

    def decide(self, data: dict[str, Any]) -> list[dict[str, Any]]:
        me = self._me(data)
        if not me:
            return []
        current = me.get("currentNodeId")
        if current and current != self.last_node:
            self.last_node = current
            self.processed_nodes.discard(current)
        if current:
            self.showcase_nodes_seen.add(current)
        self._absorb_events(data.get("events", []), current)

        actions: list[dict[str, Any]] = []
        card = self._contest_card(data, me)
        if card:
            actions.append(card)

        state = me.get("state")
        if me.get("delivered") or state in {"PROCESSING", "VERIFYING", "FORCED_PASSING", "RESTING", "CONTESTING"}:
            return actions
        if me.get("currentProcess"):
            return actions
        if state == "MOVING":
            return actions
        if state == "WAITING" and me.get("nextNodeId"):
            actions.append({"action": "MOVE", "targetNodeId": me["nextNodeId"]})
            return actions

        node = self._node(data, current)
        if not current or not node:
            return actions
        if self.rules_showcase:
            showcase_action = self._rules_showcase_action(data, me, node)
            if showcase_action:
                actions.append(showcase_action)
                return actions
        if self.horse_showcase:
            horse_action = self._horse_showcase_action(me, node)
            if horse_action:
                actions.append(horse_action)
                return actions
        if self.guard_trapper:
            guard_action = self._guard_trapper_action(data, me, node)
            if guard_action:
                actions.append(guard_action)
                return actions
        if self.window_baiter:
            bait_action = self._window_baiter_action(data, me, node)
            if bait_action:
                actions.append(bait_action)
                return actions
        if current == self.finish:
            if me.get("verified") and me.get("goodFruit", 0) > 0 and me.get("freshness", 0) > 0:
                actions.append({"action": "DELIVER"})
            else:
                actions.append({"action": "MOVE", "targetNodeId": self.gate})
            return actions
        if current == self.gate:
            if not me.get("verified"):
                if data.get("phase") == "RUSH":
                    actions.append({"action": "VERIFY_GATE"})
                return actions
            actions.append({"action": "MOVE", "targetNodeId": self.finish})
            return actions

        process_type = node.get("processType")
        if process_type in MANDATORY_PROCESS and current not in self.processed_nodes:
            actions.append({"action": "PROCESS", "targetNodeId": current})
            return actions

        target = self._target_for(data, me, current)
        path = self.shortest_path(current, target)
        if len(path) >= 2:
            actions.append({"action": "MOVE", "targetNodeId": path[1]})
        return actions

    def _contest_card(self, data: dict[str, Any], me: dict[str, Any]) -> Optional[dict[str, Any]]:
        my_team = me.get("teamId")
        for contest in data.get("contests", []) or []:
            if my_team not in (contest.get("attackerTeamId"), contest.get("defenderTeamId"), "RED", "BLUE"):
                continue
            card = "BING_ZHENG" if me.get("guardActionPoint", 0) > 0 else "XIAN_GONG"
            if card == "XIAN_GONG" and (me.get("freshness", 0) < 80 or me.get("goodFruit", 0) <= 0):
                card = "ABSTAIN"
            return {"action": "WINDOW_CARD", "contestId": contest.get("contestId"), "card": card}
        return None

    def _absorb_events(self, events: list[dict[str, Any]], current_node: Optional[str]) -> None:
        for event in events or []:
            payload = event.get("payload") or {}
            if str(payload.get("playerId")) != str(self.player_id):
                continue
            if event.get("type") == "PROCESS_COMPLETE":
                node = payload.get("nodeId") or current_node
                if node:
                    self.processed_nodes.add(node)
            elif event.get("type") == "NODE_ENTER":
                self.last_node = payload.get("nodeId")
                if payload.get("nodeId"):
                    self.showcase_nodes_seen.add(payload["nodeId"])
            elif event.get("type") == "RESOURCE_USE" and payload.get("resourceType") in {"FAST_HORSE", "SHORT_HORSE"}:
                self.horse_used.add(payload["resourceType"])
                self.resource_used.add(payload["resourceType"])
            elif event.get("type") == "RESOURCE_USE" and payload.get("resourceType"):
                self.resource_used.add(payload["resourceType"])
            elif event.get("type") == "TASK_COMPLETE" and payload.get("taskId"):
                self.tried_tasks.add(payload["taskId"])
            elif event.get("type") == "GUARD_SET" and payload.get("targetNodeId"):
                self.guards_set.add(payload["targetNodeId"])
            elif event.get("type") == "SQUAD_REINFORCE" and payload.get("targetNodeId"):
                self.reinforced_guards.add(payload["targetNodeId"])

    def _target_for(self, data: dict[str, Any], me: dict[str, Any], current: str) -> str:
        if self.rules_showcase:
            if "S03" not in self.showcase_nodes_seen:
                return "S03"
            if "S04" not in self.showcase_nodes_seen:
                return "S04"
            if "S05" not in self.showcase_nodes_seen:
                return "S05"
            if "S09" not in self.showcase_nodes_seen:
                return "S09"
            if "FAST_HORSE" not in self.resource_used:
                return "S09"
            return self.finish if me.get("verified") else self.gate
        if self.window_baiter:
            bait = self._window_bait_target(data, me, current)
            if bait:
                return bait
        if not self.horse_showcase:
            return self.finish if me.get("verified") else self.gate
        if "SHORT_HORSE" not in self.horse_used:
            return "S07"
        if "FAST_HORSE" not in self.horse_used:
            return "S09"
        return self.finish if me.get("verified") else self.gate

    def _horse_showcase_action(self, me: dict[str, Any], node: dict[str, Any]) -> Optional[dict[str, Any]]:
        resources = me.get("resources") or {}
        buffs = me.get("buffs") or []
        active = {b.get("type") for b in buffs if int(b.get("remainingRound", 0) or 0) > 0}
        current = me.get("currentNodeId")
        if resources.get("FAST_HORSE", 0) > 0 and "FAST_HORSE" not in self.horse_used:
            self.horse_used.add("FAST_HORSE")
            return {"action": "USE_RESOURCE", "resourceType": "FAST_HORSE"}
        if resources.get("SHORT_HORSE", 0) > 0 and "SHORT_HORSE" not in self.horse_used and "FAST_HORSE" not in active:
            self.horse_used.add("SHORT_HORSE")
            return {"action": "USE_RESOURCE", "resourceType": "SHORT_HORSE"}
        stock = node.get("resourceStock") or {}
        if current == "S07" and "SHORT_HORSE" not in self.horse_used and stock.get("SHORT_HORSE", 0) > 0:
            return {"action": "CLAIM_RESOURCE", "targetNodeId": "S07", "resourceType": "SHORT_HORSE"}
        if current == "S09" and "FAST_HORSE" not in self.horse_used and stock.get("FAST_HORSE", 0) > 0:
            return {"action": "CLAIM_RESOURCE", "targetNodeId": "S09", "resourceType": "FAST_HORSE"}
        return None

    def _rules_showcase_action(self, data: dict[str, Any], me: dict[str, Any],
                               node: dict[str, Any]) -> Optional[dict[str, Any]]:
        current = me.get("currentNodeId")
        resources = me.get("resources") or {}
        buffs = me.get("buffs") or []
        active = {b.get("type") for b in buffs if int(b.get("remainingRound", 0) or 0) > 0}
        stock = node.get("resourceStock") or {}

        if resources.get("ICE_BOX", 0) > 0 and "ICE_BOX" not in self.resource_used:
            self.resource_used.add("ICE_BOX")
            return {"action": "USE_RESOURCE", "resourceType": "ICE_BOX"}
        if resources.get("FAST_HORSE", 0) > 0 and "FAST_HORSE" not in self.resource_used and not active.intersection({"FAST_HORSE", "SHORT_HORSE"}):
            self.resource_used.add("FAST_HORSE")
            self.horse_used.add("FAST_HORSE")
            return {"action": "USE_RESOURCE", "resourceType": "FAST_HORSE"}
        if resources.get("SHORT_HORSE", 0) > 0 and "SHORT_HORSE" not in self.resource_used and not active.intersection({"FAST_HORSE", "SHORT_HORSE"}):
            self.resource_used.add("SHORT_HORSE")
            self.horse_used.add("SHORT_HORSE")
            return {"action": "USE_RESOURCE", "resourceType": "SHORT_HORSE"}

        if current == "S03" and "ICE_BOX" not in self.resource_used and stock.get("ICE_BOX", 0) > 0:
            return {"action": "CLAIM_RESOURCE", "targetNodeId": "S03", "resourceType": "ICE_BOX"}
        if current == "S04" and "SHORT_HORSE" not in self.resource_used and stock.get("SHORT_HORSE", 0) > 0:
            return {"action": "CLAIM_RESOURCE", "targetNodeId": "S04", "resourceType": "SHORT_HORSE"}
        if current == "S09" and "FAST_HORSE" not in self.resource_used and stock.get("FAST_HORSE", 0) > 0:
            return {"action": "CLAIM_RESOURCE", "targetNodeId": "S09", "resourceType": "FAST_HORSE"}

        task = self._showcase_task_here(data, me, current)
        if task:
            self.tried_tasks.add(task.get("taskId"))
            return {"action": "CLAIM_TASK", "taskId": task.get("taskId")}
        return None

    def _window_baiter_action(self, data: dict[str, Any], me: dict[str, Any],
                              node: dict[str, Any]) -> Optional[dict[str, Any]]:
        current = me.get("currentNodeId")
        if not current:
            return None
        task = self._showcase_task_here(data, me, current)
        if task:
            self.tried_tasks.add(task.get("taskId"))
            return {"action": "CLAIM_TASK", "taskId": task.get("taskId")}
        stock = node.get("resourceStock") or {}
        priority = ["PASS_TOKEN", "OFFICIAL_PERMIT", "ICE_BOX", "FAST_HORSE", "SHORT_HORSE", "INTEL"]
        for rtype in priority:
            if int(stock.get(rtype, 0) or 0) > 0:
                return {"action": "CLAIM_RESOURCE", "targetNodeId": current, "resourceType": rtype}
        return None

    def _window_bait_target(self, data: dict[str, Any], me: dict[str, Any], current: str) -> Optional[str]:
        opponent = None
        for player in data.get("players", []) or []:
            if str(player.get("playerId")) != str(self.player_id):
                opponent = player
                break
        opp_nodes = {opponent.get("currentNodeId"), opponent.get("nextNodeId")} if opponent else set()
        resource_value = {
            "PASS_TOKEN": 18,
            "OFFICIAL_PERMIT": 18,
            "ICE_BOX": 18,
            "FAST_HORSE": 16,
            "SHORT_HORSE": 12,
            "INTEL": 8,
        }
        candidates: list[tuple[float, str]] = []
        for task in data.get("tasks", []) or []:
            nid = task.get("targetNodeId") or task.get("nodeId")
            if not nid or nid == current:
                continue
            if task.get("status") not in ("ACTIVE", "PROTECTED"):
                continue
            if task.get("ownerPlayerId") not in (None, 0, self.player_id):
                continue
            score = float(task.get("score", 0) or 0)
            pressure = 22.0 if nid in opp_nodes else 0.0
            candidates.append((score + pressure - self._path_hops(current, nid), nid))
        for n in data.get("nodes", []) or []:
            nid = n.get("nodeId")
            if not nid or nid == current:
                continue
            stock = n.get("resourceStock") or {}
            value = max((resource_value.get(rtype, 4) for rtype, cnt in stock.items()
                         if int(cnt or 0) > 0), default=0)
            if value <= 0:
                continue
            pressure = 22.0 if nid in opp_nodes else 0.0
            candidates.append((float(value) + pressure - self._path_hops(current, nid), nid))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][1]

    def _path_hops(self, source: str, target: str) -> float:
        path = self.shortest_path(source, target)
        if not path or path == [source]:
            return 99.0
        return float(len(path) - 1)

    def _showcase_task_here(self, data: dict[str, Any], me: dict[str, Any],
                            current: Optional[str]) -> Optional[dict[str, Any]]:
        if not current:
            return None
        best = None
        best_score = -1
        resources = me.get("resources") or {}
        for task in data.get("tasks", []) or []:
            tid = task.get("taskId")
            if tid in self.tried_tasks:
                continue
            if task.get("targetNodeId") != current and task.get("nodeId") != current:
                continue
            if task.get("status") not in ("ACTIVE", "PROTECTED"):
                continue
            if task.get("taskTemplateId") == "T06" and not (resources.get("FAST_HORSE") or resources.get("SHORT_HORSE")):
                continue
            score = int(task.get("score", 0) or 0)
            if score > best_score:
                best = task
                best_score = score
        return best

    def _guard_trapper_action(self, data: dict[str, Any], me: dict[str, Any],
                              node: dict[str, Any]) -> Optional[dict[str, Any]]:
        current = me.get("currentNodeId")
        if data.get("phase") == "RUSH":
            return None
        guard = node.get("guard") or {}
        if current in {"S10", "S11", "S13"} and current not in self.guards_set:
            if not guard and int(me.get("goodFruit", 0) or 0) >= 8:
                self.guards_set.add(current)
                return {"action": "SET_GUARD", "targetNodeId": current, "extraGoodFruit": 2}
        if guard and guard.get("ownerTeamId") == me.get("teamId") and current not in self.reinforced_guards:
            if int(me.get("squadAvailable", 0) or 0) >= 2 and int(guard.get("defense", 0) or 0) < int(guard.get("maxDefense", 6) or 6):
                self.reinforced_guards.add(current)
                return {"action": "SQUAD_REINFORCE", "targetNodeId": current}
        return None

    def shortest_path(self, source: str, target: str) -> list[str]:
        heap = [(0.0, source, [source])]
        best = {source: 0.0}
        while heap:
            cost, node, path = heapq.heappop(heap)
            if node == target:
                return path
            if cost > best.get(node, float("inf")):
                continue
            for edge in self.adj.get(node, []):
                rt = edge.get("routeType", "ROAD")
                move_cost = math.ceil(int(edge.get("distance", 1)) * ROUTE_COEFF.get(rt, 1380) / 1000)
                next_node = edge["toNodeId"]
                process_cost = 0
                proc = self.nodes.get(next_node, {}).get("processType")
                if proc in MANDATORY_PROCESS:
                    process_cost = int(self.nodes[next_node].get("processRound", 0) or 0)
                next_cost = cost + move_cost + process_cost
                if next_cost < best.get(next_node, float("inf")):
                    best[next_node] = next_cost
                    heapq.heappush(heap, (next_cost, next_node, path + [next_node]))
        return [source]

    def _me(self, data: dict[str, Any]) -> Optional[dict[str, Any]]:
        for player in data.get("players", []) or []:
            if str(player.get("playerId")) == str(self.player_id):
                return player
        return None

    @staticmethod
    def _node(data: dict[str, Any], node_id: Optional[str]) -> Optional[dict[str, Any]]:
        for node in data.get("nodes", []) or []:
            if node.get("nodeId") == node_id:
                return node
        return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--playerId", required=True)
    parser.add_argument("--playerName", default="direct_runner")
    parser.add_argument("--version", default="direct-runner-1.0")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    player_id: Any = int(args.playerId) if str(args.playerId).isdigit() else args.playerId
    agent = DirectRunner(player_id)
    with socket.create_connection((args.host, args.port), timeout=30) as sock:
        write_frame(sock, {
            "msg_name": "registration",
            "msg_data": {"playerId": player_id, "playerName": args.playerName, "version": args.version},
        })
        while True:
            msg = read_frame(sock)
            name = msg.get("msg_name")
            data = msg.get("msg_data") or {}
            if name == "start":
                agent.on_start(data)
                write_frame(sock, {"msg_name": "ready", "msg_data": {
                    "matchId": data["matchId"], "round": data.get("round", 1), "playerId": player_id,
                }})
            elif name == "inquire":
                actions = agent.decide(data)
                write_frame(sock, {"msg_name": "action", "msg_data": {
                    "matchId": agent.match_id, "round": data["round"], "playerId": player_id, "actions": actions,
                }})
            elif name == "over":
                print(json.dumps(data, ensure_ascii=False))
                return 0
            elif name == "error":
                print(json.dumps(msg, ensure_ascii=False))


if __name__ == "__main__":
    raise SystemExit(main())
