"""Trainable strategy configuration for the Lychee arena client.

The reusable decision engine lives in ``core.py``.  This file intentionally
keeps only the policy name, tunable parameters, and a small factory function.
``train.py`` can inject candidate parameters through ``LYCHEE_PARAMS_JSON``
without rewriting source files.
"""

from __future__ import annotations

import json
import os
from typing import Any

from core import Agent, World

STRATEGY_NAME = "trainable-freshness-max"

BASE_PARAMS: dict[str, Any] = {
    # Routing.
    "fresh_weight": 0.6,
    "obstacle_penalty": 35.0,
    "guard_penalty": 12.0,
    "guard_reroute_margin": 24.0,
    "reroute_slack": 2.1,
    # Tasks.
    "do_tasks": True,
    "task_min_score": 15,
    "task_base_target": 130,
    "task_base_cap": 999,
    "task_detour_dist": 220,
    "preferred_task_route": "ANY",
    "spend_horse_on_t06": True,
    # Resources.
    "ice_target": 2,
    "ice_detour_dist": 90,
    "ice_end_save": False,
    "ice_use_threshold": 94.0,
    "ice_use_min_gap": 2,
    "ice_emergency": 70.0,
    "grab_horses": True,
    "fast_horse_target": 1,
    "short_horse_target": 1,
    "permit_target": 1,
    "claim_intel": True,
    # Movement and end-game.
    "use_horses": True,
    "horse_min_frames": 8,
    "use_protect": False,
    "protect_freshness_below": 82.0,
    "use_rush_speed": True,
    "rush_tactic_mode": "auto",
    "gate_break_order": True,
    # Opponent interaction.
    "window_mode": "aggressive",
    "window_clinch_abstain": True,
    "window_repeat_counter": True,
    "window_repeat_counter_min_value": 15,
    "window_repeat_draw_abstain_after": 1,
    "window_optional_min_value": 14,
    "window_task_critical_score": 30,
    "window_good_reserve": 1,
    "window_token_reserve": 1,
    "window_horse_reserve": 1,
    "window_guard_point_reserve": 1,
    "combat_mode": "aggressive",
    "guard_fruit_budget": 6,
    "guard_extra_fruit": 1,
    "squad_mode": "combat",
    "squad_min_gap": 16,
    "squad_scout_reserve": 0,
    "squad_scout_max_eta": 45,
    "squad_scout_min_process": 4,
    "squad_scout_tasks": True,
    "squad_scout_task_min_score": 30,
    "squad_clear_obstacles": True,
    "squad_weaken_guards": True,
}


def load_params() -> dict[str, Any]:
    params = dict(BASE_PARAMS)
    raw = os.environ.get("LYCHEE_PARAMS_JSON", "").strip()
    if not raw:
        return params
    try:
        overrides = json.loads(raw)
    except json.JSONDecodeError:
        return params
    if isinstance(overrides, dict):
        params.update(overrides)
    return params


PARAMS = load_params()


def make_agent(world: World) -> Agent:
    return Agent(world, PARAMS)

