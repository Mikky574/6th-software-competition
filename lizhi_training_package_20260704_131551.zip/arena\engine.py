from __future__ import annotations

import hashlib
import math
import random
import time
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Optional

from .default_map import RESOURCE_TYPES, TASK_TEMPLATES, build_default_map


ROUTE_COEFF = {"ROAD": 1380, "WATER": 1250, "MOUNTAIN": 1780, "BRANCH": 1550}
FRESH_RATE = {"ROAD": 0.055, "WATER": 0.045, "MOUNTAIN": 0.07, "BRANCH": 0.065}
BASE_MOVE = 1000
MOVE_BUFF = {"FAST_HORSE": 1200, "SHORT_HORSE": 1150, "RUSH_SPEED": 1300}
SCORING_MAX_ROUND = 600
MOVE_STATES = {"MOVING", "WAITING"}
BUSY_STATES = {"PROCESSING", "VERIFYING", "FORCED_PASSING", "CONTESTING", "RESTING"}
MAIN_ACTIONS = {
    "WAIT", "MOVE", "DELIVER", "VERIFY_GATE", "SET_GUARD", "BREAK_GUARD",
    "FORCED_PASS", "CLAIM_RESOURCE", "USE_RESOURCE", "CLAIM_TASK", "CLEAR",
    "PROCESS", "DOCK", "RUSH_SPEED", "RUSH_PROTECT",
}
SQUAD_ACTIONS = {"SQUAD_SCOUT", "SQUAD_CLEAR", "SQUAD_REINFORCE", "SQUAD_WEAKEN"}
WINDOW_ACTIONS = {"WINDOW_CARD"}
CARDS = {"YAN_DIE", "QIANG_XING", "XIAN_GONG", "BING_ZHENG", "ABSTAIN"}
CARD_RESULT = {
    ("YAN_DIE", "QIANG_XING"): 1,
    ("YAN_DIE", "XIAN_GONG"): -1,
    ("YAN_DIE", "BING_ZHENG"): -1,
    ("QIANG_XING", "YAN_DIE"): -1,
    ("QIANG_XING", "XIAN_GONG"): 1,
    ("QIANG_XING", "BING_ZHENG"): -1,
    ("XIAN_GONG", "YAN_DIE"): 1,
    ("XIAN_GONG", "QIANG_XING"): -1,
    ("XIAN_GONG", "BING_ZHENG"): 1,
    ("BING_ZHENG", "YAN_DIE"): 1,
    ("BING_ZHENG", "QIANG_XING"): 1,
    ("BING_ZHENG", "XIAN_GONG"): -1,
}
PROCESS_TYPES_NEED_VISIT = {"TRANSFER", "BOARD", "WATER_TRANSFER", "PASS_TRANSFER", "PALACE_TRANSFER"}
WATER_PROCESS_TYPES = {"BOARD", "WATER_TRANSFER"}
OBSTACLE_TYPES = ["ROCKFALL", "FLOOD", "MUD", "DOCK_BLOCK", "PASS_CROWD", "BROKEN_BRIDGE", "LANDSLIDE"]


@dataclass
class Process:
    action: str
    object_key: str
    target_node_id: str
    started_round: int
    total_round: int
    remain_round: int
    task_id: Optional[str] = None
    resource_type: Optional[str] = None
    process_type: Optional[str] = None
    frozen_good_cost: int = 0
    extra: dict[str, Any] = field(default_factory=dict)

    def public(self, round_no: int) -> dict[str, Any]:
        total = max(1, self.total_round)
        done = max(0, total - self.remain_round)
        return {
            "action": self.action,
            "objectKey": self.object_key,
            "targetNodeId": self.target_node_id,
            "taskId": self.task_id,
            "resourceType": self.resource_type,
            "type": self.process_type or self.action,
            "startedRound": self.started_round,
            "totalRound": self.total_round,
            "remainRound": self.remain_round,
            "remainingRound": self.remain_round,
            "progress": round(done / total, 4),
        }


@dataclass
class Guard:
    owner_player_id: Any
    owner_team_id: str
    defense: int
    initial_defense: int
    max_defense: int
    complete_round: int
    node_kind: str
    first_weather_after: int
    next_weather_round: int
    order: int
    attack_fail_count: int = 0
    key_combat_count: int = 0
    active_from_round: int = 0

    def active(self, round_no: int) -> bool:
        return self.defense > 0 and round_no >= self.active_from_round

    def public(self, round_no: int) -> dict[str, Any]:
        return {
            "ownerPlayerId": self.owner_player_id,
            "ownerTeamId": self.owner_team_id,
            "defense": max(0, self.defense),
            "initialDefense": self.initial_defense,
            "maxDefense": self.max_defense,
            "completeRound": self.complete_round,
            "ageRound": max(0, round_no - self.complete_round),
            "active": self.active(round_no),
        }


@dataclass
class ScoutMarker:
    team_id: str
    add_round: int
    expire_round: int
    process_reduce_round: int = 3
    remaining_triggers: int = 1

    def public(self, round_no: int) -> dict[str, Any]:
        return {
            "teamId": self.team_id,
            "remainRound": max(0, self.expire_round - round_no + 1),
            "processReduceRound": self.process_reduce_round,
            "remainingTriggers": self.remaining_triggers,
        }


@dataclass
class ObstacleResidue:
    cleared_by_player_id: Any
    cleared_by_team_id: str
    clear_round: int
    until_round: int
    tax_round: int = 6

    def public(self, round_no: int) -> dict[str, Any]:
        return {
            "clearedByPlayerId": self.cleared_by_player_id,
            "clearedByTeamId": self.cleared_by_team_id,
            "clearRound": self.clear_round,
            "untilRound": self.until_round,
            "remainRound": max(0, self.until_round - round_no + 1),
            "taxRound": self.tax_round,
        }


@dataclass
class NodeState:
    node_id: str
    config: dict[str, Any]
    process_type: Optional[str] = None
    process_round: int = 0
    can_window: bool = False
    resource_stock: dict[str, int] = field(default_factory=dict)
    guard: Optional[Guard] = None
    obstacle_type: Optional[str] = None
    obstacle_residue: Optional[ObstacleResidue] = None
    scouts: list[ScoutMarker] = field(default_factory=list)
    effective_combat_count: int = 0
    guard_block_count: int = 0
    key_pass_combat_count: int = 0
    bounty_cooldown_until_round: int = 0

    def has_obstacle(self) -> bool:
        return self.obstacle_type is not None


@dataclass
class Task:
    task_id: str
    template_id: str
    target_node_id: str
    score: int
    process_round: int
    process_type: str
    refresh_round: int
    expire_round: int
    status: str = "ACTIVE"
    owner_player_id: Any = None
    protect_player_id: Any = None
    score_tier: str = "STANDARD"
    route_bucket: str = "ANY"
    route_buckets: list[str] = field(default_factory=list)

    def public(self) -> dict[str, Any]:
        return {
            "taskId": self.task_id,
            "taskTemplateId": self.template_id,
            "targetNodeId": self.target_node_id,
            "nodeId": self.target_node_id,
            "score": self.score,
            "scoreTier": self.score_tier,
            "routeBucket": self.route_bucket,
            "routeBuckets": list(self.route_buckets),
            "processRound": self.process_round,
            "processType": self.process_type,
            "refreshRound": self.refresh_round,
            "expireRound": self.expire_round,
            "status": self.status,
            "active": self.status in ("ACTIVE", "PROTECTED"),
            "completed": self.status == "COMPLETED",
            "failed": self.status in ("FAILED", "EXPIRED"),
            "protected": self.status == "PROTECTED",
            "ownerPlayerId": self.owner_player_id,
            "protectPlayerId": self.protect_player_id,
            "protectionPlayerId": self.protect_player_id,
        }


@dataclass
class Bounty:
    bounty_id: str
    bounty_type: str
    node_id: str
    owner_team_id: str
    score: int
    trigger_round: int
    status: str = "ACTIVE"

    def public(self, cooldown_until: int = 0) -> dict[str, Any]:
        return {
            "bountyId": self.bounty_id,
            "bountyType": self.bounty_type,
            "nodeId": self.node_id,
            "ownerTeamId": self.owner_team_id,
            "score": self.score,
            "triggerRound": self.trigger_round,
            "status": self.status,
            "cooldownUntilRound": cooldown_until,
            "rewardResourceType": None,
        }


@dataclass
class SquadOrder:
    order_id: str
    player_id: Any
    team_id: str
    action: str
    target_node_id: str
    cost: int
    arrival_round: int


@dataclass
class PlayerState:
    player_id: Any
    player_name: str
    camp: int
    team_id: str
    online: bool = False
    state: str = "IDLE"
    current_node_id: str = "S01"
    next_node_id: Optional[str] = None
    route_edge_id: Optional[str] = None
    route_type: Optional[str] = None
    move_direction: str = "NONE"
    move_progress_round: int = 0
    edge_progress_ms: int = 0
    edge_total_ms: int = 0
    move_tax_rounds: int = 0
    freshness: float = 100.0
    good_fruit: int = 100
    frozen_good_fruit: int = 0
    bad_fruit: int = 0
    resources: dict[str, int] = field(default_factory=dict)
    squad_available: int = 8
    squad_in_flight: int = 0
    guard_action_point: int = 4
    verified: bool = False
    delivered: bool = False
    retired: bool = False
    retired_round: int = 0
    missing_action_rounds: int = 0
    illegal_action_count: int = 0
    post_deliver_violation_count: int = 0
    penalty_score: int = 0
    rush_tactic_used_count: int = 0
    buffs: dict[str, int] = field(default_factory=dict)
    current_process: Optional[Process] = None
    processed_current_node: bool = False
    last_forced_pass_node: Optional[str] = None
    deliver_round: int = 0
    deliver_good_fruit: int = 0
    deliver_freshness: float = 0.0
    task_score_base: int = 0
    bounty_score_raw: int = 0
    completed_task_ids: set[str] = field(default_factory=set)
    freshness_thresholds: set[int] = field(default_factory=set)
    road_rounds: int = 0
    water_rounds: int = 0
    mountain_rounds: int = 0
    branch_rounds: int = 0
    route_switch_count: int = 0
    last_route_type: Optional[str] = None
    registered: bool = False
    abnormal: bool = False

    def active_horse(self) -> bool:
        return any(self.buffs.get(t, 0) > 0 for t in ("FAST_HORSE", "SHORT_HORSE"))

    def has_buff(self, buff: str) -> bool:
        return self.buffs.get(buff, 0) > 0

    def move_per_frame(self) -> int:
        if self.buffs.get("RUSH_SPEED", 0) > 0:
            return MOVE_BUFF["RUSH_SPEED"]
        if self.buffs.get("FAST_HORSE", 0) > 0:
            return MOVE_BUFF["FAST_HORSE"]
        if self.buffs.get("SHORT_HORSE", 0) > 0:
            return MOVE_BUFF["SHORT_HORSE"]
        return BASE_MOVE


@dataclass
class Intent:
    player_id: Any
    team_id: str
    action: str
    object_key: str
    contest_type: str
    target_node_id: str
    process_round: int = 0
    task_id: Optional[str] = None
    resource_type: Optional[str] = None
    process_type: Optional[str] = None
    frozen_good_cost: int = 0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class Contest:
    contest_id: str
    contest_type: str
    object_key: str
    target_node_id: str
    created_round: int
    red_player_id: Any
    blue_player_id: Any
    intents: dict[str, Intent] = field(default_factory=dict)
    attacker_team_id: Optional[str] = None
    defender_team_id: Optional[str] = None
    resource_type: Optional[str] = None
    task_id: Optional[str] = None
    process_type: Optional[str] = None
    initial_time_tax_round: int = 0
    initial_block_type: Optional[str] = None
    initial_guard_tax_round: int = 0
    initial_obstacle_tax_round: int = 0
    points: dict[str, int] = field(default_factory=lambda: {"RED": 0, "BLUE": 0})
    cards: dict[int, dict[str, str]] = field(default_factory=dict)
    status: str = "ACTIVE"
    suppress_until_round: int = 0

    def round_index(self, round_no: int) -> int:
        return max(0, round_no - self.created_round)


class GameEngine:
    def __init__(self, red_id: Any = 1001, blue_id: Any = 1002, red_name: str = "RED",
                 blue_name: str = "BLUE", seed: int = 1, duration_round: int = 600,
                 obstacle_count: int = 0, task_refresh_interval: int = 24) -> None:
        self.seed = int(seed)
        self.random = random.Random(self.seed)
        self.duration_round = duration_round
        self.rules_version = "local-4.1"
        self.match_id = f"match_{int(time.time())}_{self.seed}"
        self.seed_hash = hashlib.sha256(str(seed).encode("ascii")).hexdigest()[:16]
        self.map_config = build_default_map()
        self.nodes_config = {n["nodeId"]: deepcopy(n) for n in self.map_config["nodes"]}
        self.edges = deepcopy(self.map_config["edges"])
        self.adj = self._build_adjacency(self.edges)
        self.players: dict[Any, PlayerState] = {
            red_id: PlayerState(red_id, red_name, 0, "RED"),
            blue_id: PlayerState(blue_id, blue_name, 1, "BLUE"),
        }
        self.team_to_player_id = {"RED": red_id, "BLUE": blue_id}
        self.node_states = self._build_nodes(obstacle_count)
        self.tasks: dict[str, Task] = {}
        self.bounties: dict[str, Bounty] = {}
        self.contests: dict[str, Contest] = {}
        self.squad_orders: list[SquadOrder] = []
        self.round = 1
        self.phase = "NORMAL"
        self.events: list[dict[str, Any]] = []
        self.action_results: list[dict[str, Any]] = []
        self.event_seq = 0
        self.task_seq = 0
        self.contest_seq = 0
        self.order_seq = 0
        self.bounty_seq = 0
        self.guard_order_seq = 0
        self.task_refresh_interval = task_refresh_interval
        self.next_task_refresh_round = 1
        self.draw_counts: dict[str, int] = {}
        self.suppressed_until: dict[str, int] = {}
        self.weather_events = self._generate_weather()
        self.replay: list[dict[str, Any]] = []
        self._refresh_tasks_for_next_inquire(1)

    # ------------------------------------------------------------------ setup
    def _build_adjacency(self, edges: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
        adj: dict[str, list[dict[str, Any]]] = {}
        for edge in edges:
            a = edge["fromNodeId"]
            b = edge["toNodeId"]
            adj.setdefault(a, []).append(edge)
            if edge.get("bidirectional", True):
                rev = dict(edge)
                rev["fromNodeId"] = b
                rev["toNodeId"] = a
                adj.setdefault(b, []).append(rev)
        return adj

    def _build_nodes(self, obstacle_count: int) -> dict[str, NodeState]:
        process_by_node = {p["nodeId"]: p for p in self.map_config["processNodes"]}
        stocks: dict[str, dict[str, int]] = {nid: {rtype: 0 for rtype in RESOURCE_TYPES} for nid in self.nodes_config}
        for item in self.map_config["resources"]:
            stocks[item["nodeId"]][item["resourceType"]] = stocks[item["nodeId"]].get(item["resourceType"], 0) + int(item["count"])
        states: dict[str, NodeState] = {}
        for nid, cfg in self.nodes_config.items():
            proc = process_by_node.get(nid)
            states[nid] = NodeState(
                node_id=nid,
                config=cfg,
                process_type=proc.get("processType") if proc else None,
                process_round=int(proc.get("processRound", 0)) if proc else 0,
                can_window=bool(proc.get("canWindow", False)) if proc else False,
                resource_stock=stocks.get(nid, {}),
            )
        candidates = list(self.map_config["gameplay"]["obstacleCandidateNodeIds"])
        self.random.shuffle(candidates)
        for idx, nid in enumerate(candidates[:max(0, obstacle_count)]):
            states[nid].obstacle_type = OBSTACLE_TYPES[idx % len(OBSTACLE_TYPES)]
        return states

    def _generate_weather(self) -> list[dict[str, Any]]:
        ranges = [(80, 120), (200, 240), (320, 360), (440, 480)]
        choices = [("HOT", "ALL"), ("HEAVY_RAIN", "WATER"), ("MOUNTAIN_FOG", "MOUNTAIN")]
        weather = []
        for i, (lo, hi) in enumerate(ranges, start=1):
            wtype, region = choices[(self.seed + i) % len(choices)]
            weather.append({
                "weatherId": f"W_{i:02d}",
                "type": wtype,
                "region": region,
                "startRound": self.random.randint(lo, hi),
                "durationRound": 60,
            })
        weather.sort(key=lambda w: w["startRound"])
        return weather

    def register_player(self, player_id: Any, player_name: str) -> bool:
        player = self.players.get(player_id)
        if player is None:
            for known_id, p in self.players.items():
                if str(known_id) == str(player_id):
                    player = p
                    break
        if player is None:
            return False
        player.player_name = player_name or player.player_name
        player.online = True
        player.registered = True
        return True

    def set_online(self, player_id: Any, online: bool) -> None:
        p = self.players.get(player_id)
        if p:
            p.online = online

    # --------------------------------------------------------------- messages
    def start_message(self) -> dict[str, Any]:
        nodes = [self._start_node_public(nid) for nid in sorted(self.nodes_config)]
        payload = {
            "matchId": self.match_id,
            "rulesVersion": self.rules_version,
            "seedHash": self.seed_hash,
            "round": 1,
            "tick": 0,
            "durationRound": self.duration_round,
            "map": {
                "schemaVersion": self.map_config["schemaVersion"],
                "mapId": self.map_config["mapId"],
                "mapName": self.map_config["mapName"],
                "designVersion": self.map_config["designVersion"],
                "maxX": self.map_config["maxX"],
                "maxY": self.map_config["maxY"],
                "nodes": nodes,
                "edges": deepcopy(self.edges),
                "gameplay": deepcopy(self.map_config["gameplay"]),
                "weatherRegionRule": {
                    "HOT": "ALL",
                    "HEAVY_RAIN": "WATER",
                    "MOUNTAIN_FOG": "MOUNTAIN",
                },
            },
            "players": [self._start_player_public(p) for p in self.players.values()],
            "nodes": nodes,
            "edges": deepcopy(self.edges),
            "routePaths": [],
            "resources": deepcopy(self.map_config["resources"]),
            "taskTemplates": deepcopy(self.map_config["taskTemplates"]),
        }
        return {"msg_name": "start", "msg_data": payload}

    def inquire_message(self) -> dict[str, Any]:
        data = {
            "matchId": self.match_id,
            "round": self.round,
            "phase": self.phase,
            "durationRound": self.duration_round,
            "players": [self._player_public(p) for p in self.players.values()],
            "nodes": [self._node_public(nid) for nid in sorted(self.node_states)],
            "edges": deepcopy(self.edges),
            "tasks": [t.public() for t in self.tasks.values() if t.status in ("ACTIVE", "PROCESSING", "PROTECTED")],
            "contests": [self._contest_public(c) for c in self.contests.values() if c.status == "ACTIVE"],
            "bounties": [b.public(self.node_states[b.node_id].bounty_cooldown_until_round)
                         for b in self.bounties.values() if b.status == "ACTIVE"],
            "weather": self._weather_public(),
            "events": deepcopy(self.events),
            "actionResults": deepcopy(self.action_results),
            "scorePreview": {str(p.player_id): self.score_detail(p) for p in self.players.values()},
        }
        return {"msg_name": "inquire", "msg_data": data}

    def over_message(self, reason: str) -> dict[str, Any]:
        players = [self._over_player_public(p) for p in self.players.values()]
        red, blue = self.players_list()
        if red.abnormal or blue.abnormal:
            result_type = "INVALID"
            winner = None
            if red.abnormal and not blue.abnormal:
                winner = blue.player_id
            elif blue.abnormal and not red.abnormal:
                winner = red.player_id
        else:
            red_score = self.score_detail(red)["total"]
            blue_score = self.score_detail(blue)["total"]
            if red_score > blue_score:
                result_type = "NORMAL"
                winner = red.player_id
            elif blue_score > red_score:
                result_type = "NORMAL"
                winner = blue.player_id
            else:
                result_type = "DRAW"
                winner = None
        data = {
            "matchId": self.match_id,
            "overRound": self.round,
            "resultType": result_type,
            "overReason": reason,
            "winnerPlayerId": winner,
            "players": players,
            "leaguePoints": self.league_points(),
        }
        return {"msg_name": "over", "msg_data": data}

    def _start_node_public(self, nid: str) -> dict[str, Any]:
        cfg = deepcopy(self.nodes_config[nid])
        ns = self.node_states[nid]
        cfg["processType"] = ns.process_type
        cfg["processRound"] = ns.process_round
        cfg["canWindow"] = ns.can_window
        return cfg

    def _start_player_public(self, p: PlayerState) -> dict[str, Any]:
        return {
            "playerId": p.player_id,
            "camp": p.camp,
            "teamId": p.team_id,
            "name": p.player_name,
            "playerName": p.player_name,
        }

    # --------------------------------------------------------------- round run
    def run_round(self, action_packets: dict[Any, Optional[list[dict[str, Any]]]]) -> None:
        self.events = []
        self.action_results = []
        self._cleanup_expired_markers()
        self._expire_tasks()
        self._update_rush_phase()

        category_actions: dict[Any, dict[str, Optional[dict[str, Any]]]] = {}
        for pid, player in self.players.items():
            raw = action_packets.get(pid)
            category_actions[pid] = self._split_actions(player, raw)

        self._resolve_window_cards(category_actions)
        self._resolve_squad_actions(category_actions)
        intents: list[Intent] = []
        for pid, player in self.players.items():
            main = category_actions[pid].get("main")
            intent = self._resolve_main_action(player, main)
            if intent is not None:
                intents.append(intent)
        self._resolve_intents(intents)

        self._advance_processes()
        self._advance_movement()
        self._resolve_squad_arrivals()
        self._apply_guard_weathering_and_bounties()
        self._apply_freshness()
        self._tick_buffs()
        self._expire_tasks()
        self._refresh_tasks_for_next_inquire(self.round + 1)
        self._update_scores()
        self._record_replay()
        self.round += 1

    def is_over(self) -> tuple[bool, str]:
        active = [p for p in self.players.values() if not p.retired]
        if all(p.delivered or p.retired for p in self.players.values()):
            return True, "ALL_FINISHED"
        retired = [p for p in self.players.values() if p.retired]
        if retired and any(not p.delivered for p in retired):
            return True, "PLAYER_RETIRED"
        if self.round > self.duration_round:
            return True, "MAX_ROUND"
        if not active:
            return True, "ALL_RETIRED"
        return False, ""

    # --------------------------------------------------------- action parsing
    def _split_actions(self, player: PlayerState, actions: Optional[list[dict[str, Any]]]) -> dict[str, Optional[dict[str, Any]]]:
        result: dict[str, Optional[dict[str, Any]]] = {"main": None, "squad": None, "window": None}
        if player.delivered or player.retired:
            if actions is None:
                return result
        if actions is None:
            if not player.delivered and not player.retired:
                player.missing_action_rounds += 1
                self.event("WAIT", playerId=player.player_id, teamId=player.team_id, reason="SYSTEM_WAIT")
                if player.missing_action_rounds == 10:
                    self.event("DISCONNECT_WARNING", playerId=player.player_id, teamId=player.team_id)
                if player.missing_action_rounds >= 60:
                    self._retire_player(player, "MISSING_ACTION")
            return result
        player.missing_action_rounds = 0
        if not isinstance(actions, list):
            self._illegal(player, "INVALID_ACTION_FORMAT", None)
            return result
        buckets = {"main": [], "squad": [], "window": []}
        unknown = []
        for item in actions:
            if not isinstance(item, dict) or "action" not in item:
                unknown.append(item)
                continue
            name = item.get("action")
            if name in MAIN_ACTIONS:
                buckets["main"].append(item)
            elif name in SQUAD_ACTIONS:
                buckets["squad"].append(item)
            elif name in WINDOW_ACTIONS:
                buckets["window"].append(item)
            elif name == "BREAK_ORDER":
                unknown.append(item)
            else:
                unknown.append(item)
        if unknown:
            self._illegal(player, "INVALID_ACTION_TYPE", unknown[0] if isinstance(unknown[0], dict) else None)
        for kind, items in buckets.items():
            if len(items) > 1:
                if kind == "window":
                    self._illegal(player, "INVALID_ACTION_CONFLICT", items[0], action_name="WINDOW_CARD")
                else:
                    self._illegal(player, "INVALID_ACTION_CONFLICT", items[0])
                continue
            if items:
                result[kind] = items[0]
        return result

    def _resolve_main_action(self, player: PlayerState, action: Optional[dict[str, Any]]) -> Optional[Intent]:
        if player.retired:
            return None
        if player.delivered:
            if action and action.get("action") not in ("WAIT", "DELIVER"):
                self._post_deliver_penalty(player, action)
            return None
        if action is None:
            return None
        name = str(action.get("action"))
        if player.state == "CONTESTING":
            if name != "WAIT":
                self._reject(player, name, "STATE_CONTESTING")
            return None
        if player.state == "RESTING":
            if name != "WAIT":
                self._reject(player, name, "STATE_RESTING")
            return None
        if player.state in ("PROCESSING", "VERIFYING", "FORCED_PASSING"):
            if name != "WAIT":
                self._reject(player, name, "STATE_BUSY")
            return None
        if name == "WAIT":
            if player.state in MOVE_STATES:
                player.state = "WAITING"
                player.move_direction = "PAUSED"
            self._accepted(player, name)
            self.event("WAIT", playerId=player.player_id, teamId=player.team_id)
            return None
        if name == "MOVE":
            self._handle_move_action(player, action)
            return None
        if name == "USE_RESOURCE":
            self._handle_use_resource(player, action)
            return None
        if player.state in MOVE_STATES:
            self._reject(player, name, "STATE_MOVING")
            return None
        if name == "DELIVER":
            self._handle_deliver(player, action)
            return None
        if name == "BREAK_GUARD":
            self._handle_break_guard(player, action)
            return None
        if name == "RUSH_SPEED":
            self._handle_rush_speed(player, action)
            return None
        if name == "RUSH_PROTECT":
            self._handle_rush_protect(player, action)
            return None
        if name == "FORCED_PASS":
            return self._build_forced_pass_intent(player, action)
        if name == "CLAIM_RESOURCE":
            return self._build_resource_intent(player, action)
        if name == "CLAIM_TASK":
            return self._build_task_intent(player, action)
        if name in ("PROCESS", "DOCK"):
            return self._build_process_intent(player, action, name)
        if name == "VERIFY_GATE":
            return self._build_verify_intent(player, action)
        if name == "CLEAR":
            return self._build_clear_intent(player, action)
        if name == "SET_GUARD":
            return self._build_set_guard_intent(player, action)
        self._illegal(player, "INVALID_ACTION_TYPE", action)
        return None

    # -------------------------------------------------------------- main acts
    def _handle_move_action(self, player: PlayerState, action: dict[str, Any]) -> None:
        target = action.get("targetNodeId")
        if not target:
            self._illegal(player, "MISSING_TARGET", action)
            return
        if target not in self.node_states:
            self._reject(player, "MOVE", "TARGET_NOT_FOUND")
            return
        if player.state in MOVE_STATES:
            if target == player.next_node_id:
                player.state = "MOVING"
                player.move_direction = "FORWARD"
                self._accepted(player, "MOVE")
                return
            if target == player.current_node_id:
                self._reject(player, "MOVE", "MOVE_CANNOT_RETURN_ORIGIN")
                return
            edge = self.edge_between(player.current_node_id, target)
            if not edge:
                self._illegal(player, "MOVE_NOT_ADJACENT", action)
                return
            self._start_move(player, target, edge)
            self._accepted(player, "MOVE")
            return
        if player.state not in ("IDLE", "COST_BANKRUPT"):
            self._reject(player, "MOVE", "STATE_BUSY")
            return
        if self._must_process_before_leave(player, target):
            self._reject(player, "MOVE", "PROCESS_REQUIRED")
            return
        edge = self.edge_between(player.current_node_id, target)
        if not edge:
            self._illegal(player, "MOVE_NOT_ADJACENT", action)
            return
        if not self._can_enter_node(player, target, ordinary_move=True):
            return
        self._start_move(player, target, edge)
        self._accepted(player, "MOVE")

    def _start_move(self, player: PlayerState, target: str, edge: dict[str, Any]) -> None:
        if player.route_type and player.route_type != edge["routeType"]:
            player.route_switch_count += 1
        player.last_route_type = edge["routeType"]
        player.state = "MOVING"
        player.next_node_id = target
        player.route_edge_id = edge["edgeId"]
        player.route_type = edge["routeType"]
        player.move_direction = "FORWARD"
        player.move_progress_round = 0
        player.edge_progress_ms = 0
        total = math.ceil(int(edge["distance"]) * ROUTE_COEFF.get(edge["routeType"], 1380))
        residue = self.node_states[target].obstacle_residue
        if residue and residue.cleared_by_team_id != player.team_id and self.round <= residue.until_round:
            total += residue.tax_round * player.move_per_frame()
            self.event("OBSTACLE_RESIDUAL_TAX", playerId=player.player_id, teamId=player.team_id,
                       targetNodeId=target, taxRound=residue.tax_round)
        player.edge_total_ms = total
        player.processed_current_node = False

    def _can_enter_node(self, player: PlayerState, target: str, ordinary_move: bool) -> bool:
        if player.current_node_id == "S15" and target == "S14":
            return True
        if target == "S15" and not player.verified:
            self._reject(player, "MOVE", "GATE_NOT_VERIFIED")
            return False
        node = self.node_states[target]
        guard = node.guard
        if guard and guard.active(self.round) and guard.owner_team_id != player.team_id:
            self._reject(player, "MOVE", "TARGET_BLOCKED_BY_GUARD")
            return False
        if ordinary_move and node.has_obstacle():
            self._reject(player, "MOVE", "TARGET_BLOCKED_BY_OBSTACLE")
            return False
        return True

    def _handle_use_resource(self, player: PlayerState, action: dict[str, Any]) -> None:
        rtype = action.get("resourceType")
        if not rtype:
            self._reject(player, "USE_RESOURCE", "RESOURCE_TYPE_MISSING")
            return
        if player.resources.get(rtype, 0) <= 0:
            self._reject(player, "USE_RESOURCE", "RESOURCE_NOT_ENOUGH")
            return
        if player.state in MOVE_STATES and rtype not in ("FAST_HORSE", "SHORT_HORSE"):
            self._reject(player, "USE_RESOURCE", "RESOURCE_NOT_ALLOWED_MOVING")
            return
        if rtype == "ICE_BOX":
            if player.freshness <= 0:
                self._reject(player, "USE_RESOURCE", "FRESHNESS_ZERO")
                return
            player.resources[rtype] -= 1
            player.freshness = min(100.0, player.freshness + 10.0)
            self._accepted(player, "USE_RESOURCE")
            self.event("RESOURCE_USE", playerId=player.player_id, teamId=player.team_id,
                       resourceType=rtype, freshness=player.freshness)
            return
        if rtype in ("FAST_HORSE", "SHORT_HORSE"):
            if player.has_buff("RUSH_SPEED"):
                self._reject(player, "USE_RESOURCE", "RUSH_SPEED_CONFLICT")
                return
            player.resources[rtype] -= 1
            for old in ("FAST_HORSE", "SHORT_HORSE"):
                player.buffs.pop(old, None)
            player.buffs[rtype] = 20 if rtype == "FAST_HORSE" else 14
            self._accepted(player, "USE_RESOURCE")
            self.event("RESOURCE_USE", playerId=player.player_id, teamId=player.team_id,
                       resourceType=rtype, buffType=rtype)
            return
        if rtype == "INTEL":
            target = action.get("targetNodeId")
            if not target:
                self._reject(player, "USE_RESOURCE", "TARGET_REQUIRED")
                return
            if player.state in MOVE_STATES:
                self._reject(player, "USE_RESOURCE", "INTEL_REQUIRES_NODE")
                return
            dist = self.shortest_distance(player.current_node_id, target)
            if dist > 15:
                self._reject(player, "USE_RESOURCE", "INTEL_TARGET_TOO_FAR")
                return
            player.resources[rtype] -= 1
            self._add_scout_marker(player.team_id, target)
            self._accepted(player, "USE_RESOURCE")
            self.event("RESOURCE_USE", playerId=player.player_id, teamId=player.team_id,
                       resourceType=rtype, targetNodeId=target)
            return
        player.resources[rtype] -= 1
        self._accepted(player, "USE_RESOURCE")
        self.event("RESOURCE_USE", playerId=player.player_id, teamId=player.team_id,
                   resourceType=rtype, effect="NONE")

    def _handle_deliver(self, player: PlayerState, action: dict[str, Any]) -> None:
        if player.current_node_id != "S15":
            self._reject(player, "DELIVER", "DELIVER_NOT_AT_FINISH")
            return
        if not player.verified:
            self._reject(player, "DELIVER", "DELIVER_NOT_VERIFIED")
            return
        if player.good_fruit <= 0 or player.freshness <= 0:
            self._reject(player, "DELIVER", "DELIVER_NO_VALID_FRUIT")
            return
        player.delivered = True
        player.state = "DELIVERED"
        player.deliver_round = self.round
        player.deliver_good_fruit = player.good_fruit
        player.deliver_freshness = player.freshness
        self._accepted(player, "DELIVER")
        self.event("DELIVER_SUCCESS", playerId=player.player_id, teamId=player.team_id,
                   goodFruit=player.good_fruit, freshness=round(player.freshness, 3),
                   totalScore=self.score_detail(player)["total"])

    def _handle_break_guard(self, player: PlayerState, action: dict[str, Any]) -> None:
        target = action.get("targetNodeId")
        if not target:
            self._illegal(player, "MISSING_TARGET", action)
            return
        gf = int(action.get("goodFruit", 0) or 0)
        bf = int(action.get("badFruit", 0) or 0)
        if gf < 0 or gf > 2 or bf < 0 or bf > 2:
            self._reject(player, "BREAK_GUARD", "INVALID_FRUIT_COMMIT")
            return
        if player.good_fruit < gf or player.bad_fruit < bf:
            self._reject(player, "BREAK_GUARD", "RESOURCE_NOT_ENOUGH")
            return
        if not self.edge_between(player.current_node_id, target) or target == player.current_node_id:
            self._reject(player, "BREAK_GUARD", "TARGET_NOT_ADJACENT")
            return
        guard = self.enemy_guard(player, target)
        if not guard:
            self._reject(player, "BREAK_GUARD", "NO_ENEMY_GUARD")
            return
        break_bonus = self._try_bind_break_order(player, action, for_action="BREAK_GUARD")
        player.good_fruit -= gf
        player.bad_fruit -= bf
        attack = gf * 2 + bf * 3 + break_bonus
        node = self.node_states[target]
        score_before_attacker = self.score_detail(player)["total"]
        defender = self.player_by_team(guard.owner_team_id)
        score_before_defender = self.score_detail(defender)["total"] if defender else 0
        if self.nodes_config[target]["nodeType"] == "KEY_PASS":
            guard.key_combat_count += 1
            node.key_pass_combat_count += 1
        if attack >= guard.defense:
            before = guard.defense
            guard.defense = 0
            self._accepted(player, "BREAK_GUARD")
            self.event("GUARD_BREAK", playerId=player.player_id, teamId=player.team_id,
                       targetNodeId=target, before=before, after=0, success=True)
            self._claim_bounty_if_eligible(player, target, score_before_attacker, score_before_defender)
            self._expire_bounty_for_node(target, "GUARD_BROKEN")
        elif attack > 0:
            before = guard.defense
            guard.defense = max(0, guard.defense - attack)
            player.state = "RESTING"
            player.current_process = Process("REST", "REST", player.current_node_id, self.round, 5, 5)
            guard.attack_fail_count += 1
            node.guard_block_count += 1
            self._accepted(player, "BREAK_GUARD", accepted=True)
            self.event("GUARD_BREAK", playerId=player.player_id, teamId=player.team_id,
                       targetNodeId=target, before=before, after=guard.defense, success=False)
            self._maybe_create_bounty(target, key=False, reason="ATTACK_FAIL")
        else:
            self._accepted(player, "BREAK_GUARD")
            self.event("GUARD_BREAK", playerId=player.player_id, teamId=player.team_id,
                       targetNodeId=target, defense=guard.defense, success=False)

    def _handle_rush_speed(self, player: PlayerState, action: dict[str, Any]) -> None:
        if self.phase != "RUSH" or player.rush_tactic_used_count >= 1:
            self._illegal(player, "RUSH_TACTIC_NOT_AVAILABLE", action)
            return
        if player.active_horse():
            self._reject(player, "RUSH_SPEED", "HORSE_BUFF_CONFLICT")
            return
        if player.good_fruit < 2:
            self._reject(player, "RUSH_SPEED", "RESOURCE_NOT_ENOUGH")
            return
        player.good_fruit -= 2
        player.rush_tactic_used_count += 1
        player.buffs["RUSH_SPEED"] = 15
        self._accepted(player, "RUSH_SPEED")
        self.event("RUSH_TACTIC_USE", playerId=player.player_id, teamId=player.team_id, buffType="RUSH_SPEED")

    def _handle_rush_protect(self, player: PlayerState, action: dict[str, Any]) -> None:
        if self.phase != "RUSH" or player.rush_tactic_used_count >= 1:
            self._illegal(player, "RUSH_TACTIC_NOT_AVAILABLE", action)
            return
        if player.state not in ("IDLE", "COST_BANKRUPT"):
            self._reject(player, "RUSH_PROTECT", "STATE_BUSY")
            return
        player.rush_tactic_used_count += 1
        player.buffs["RUSH_PROTECT"] = 30
        self._accepted(player, "RUSH_PROTECT")
        self.event("RUSH_TACTIC_USE", playerId=player.player_id, teamId=player.team_id, buffType="RUSH_PROTECT")

    def _build_resource_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        target = action.get("targetNodeId")
        rtype = action.get("resourceType")
        if not target or not rtype:
            self._reject(player, "CLAIM_RESOURCE", "RESOURCE_TARGET_REQUIRED")
            return None
        if target != player.current_node_id:
            self._reject(player, "CLAIM_RESOURCE", "TARGET_NOT_CURRENT_NODE")
            return None
        node = self.node_states.get(target)
        if not node or node.resource_stock.get(rtype, 0) <= 0:
            self._reject(player, "CLAIM_RESOURCE", "RESOURCE_NOT_ENOUGH")
            return None
        rounds = self._claim_round(target, rtype)
        rounds = self._apply_scout_preview(player, target, rounds)
        return Intent(player.player_id, player.team_id, "CLAIM_RESOURCE",
                      f"RESOURCE:{target}:{rtype}", "RESOURCE", target, rounds,
                      resource_type=rtype, process_type="CLAIM_RESOURCE")

    def _build_task_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        tid = action.get("taskId")
        if not tid:
            self._illegal(player, "MISSING_TASK_ID", action)
            return None
        task = self.tasks.get(tid)
        if not task or task.status not in ("ACTIVE", "PROTECTED"):
            self._reject(player, "CLAIM_TASK", "TASK_NOT_AVAILABLE")
            return None
        if self.round >= task.expire_round and task.status != "PROTECTED":
            self._reject(player, "CLAIM_TASK", "TASK_EXPIRED")
            return None
        if task.template_id == "T04":
            if player.current_node_id != task.target_node_id and not self.edge_between(player.current_node_id, task.target_node_id):
                self._reject(player, "CLAIM_TASK", "TASK_POSITION_INVALID")
                return None
            if not self.node_states[task.target_node_id].has_obstacle():
                task.status = "FAILED"
                self._reject(player, "CLAIM_TASK", "TASK_TARGET_LOST")
                self.event("TASK_TARGET_LOST", playerId=player.player_id, taskId=tid, targetNodeId=task.target_node_id)
                return None
        elif player.current_node_id != task.target_node_id:
            self._reject(player, "CLAIM_TASK", "TASK_POSITION_INVALID")
            return None
        if task.template_id == "T06" and not (player.resources.get("FAST_HORSE", 0) or player.resources.get("SHORT_HORSE", 0)):
            self._reject(player, "CLAIM_TASK", "RESOURCE_NOT_ENOUGH")
            return None
        rounds = self._apply_scout_preview(player, task.target_node_id, task.process_round)
        return Intent(player.player_id, player.team_id, "CLAIM_TASK", f"TASK:{tid}", "TASK",
                      task.target_node_id, rounds, task_id=tid, process_type=task.process_type,
                      extra={"templateId": task.template_id})

    def _build_process_intent(self, player: PlayerState, action: dict[str, Any], action_name: str) -> Optional[Intent]:
        target = action.get("targetNodeId") or player.current_node_id
        if target != player.current_node_id:
            self._reject(player, action_name, "TARGET_NOT_CURRENT_NODE")
            return None
        node = self.node_states.get(target)
        if not node or not node.process_type or node.process_type == "VERIFY":
            self._reject(player, action_name, "NO_PROCESS_HERE")
            return None
        if action_name == "DOCK" and node.process_type != "BOARD":
            self._reject(player, action_name, "NO_DOCK_HERE")
            return None
        rounds = self._process_round_with_weather(node.process_type, node.process_round)
        rounds = self._apply_scout_preview(player, target, rounds)
        return Intent(player.player_id, player.team_id, action_name, f"PROCESS:{target}:{node.process_type}",
                      "DOCK", target, rounds, process_type=node.process_type)

    def _build_verify_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        target = action.get("targetNodeId") or "S14"
        if self.phase != "RUSH":
            self._reject(player, "VERIFY_GATE", "RUSH_NOT_STARTED")
            return None
        if player.current_node_id != "S14" or target != "S14":
            self._reject(player, "VERIFY_GATE", "VERIFY_NOT_AT_GATE")
            return None
        if player.verified:
            self._reject(player, "VERIFY_GATE", "VERIFY_GATE_ALREADY_DONE")
            self.event("VERIFY_GATE_ALREADY_DONE", playerId=player.player_id, teamId=player.team_id)
            return None
        node = self.node_states["S14"]
        rounds = self._process_round_with_weather("VERIFY", node.process_round)
        break_bonus = self._try_bind_break_order(player, action, for_action="VERIFY_GATE", dry_run=True)
        extra = {}
        if break_bonus:
            extra["breakOrder"] = True
            rounds = max(3, rounds - 3)
        rounds = self._apply_scout_preview(player, "S14", rounds)
        return Intent(player.player_id, player.team_id, "VERIFY_GATE", "GATE:S14", "GATE",
                      "S14", rounds, process_type="VERIFY", extra=extra)

    def _build_clear_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        target = action.get("targetNodeId")
        if not target:
            self._illegal(player, "MISSING_TARGET", action)
            return None
        if target not in self.node_states:
            self._reject(player, "CLEAR", "TARGET_NOT_FOUND")
            return None
        if player.current_node_id != target and not self.edge_between(player.current_node_id, target):
            self._reject(player, "CLEAR", "TARGET_NOT_ADJACENT")
            return None
        if not self.node_states[target].has_obstacle():
            self._reject(player, "CLEAR", "NO_OBSTACLE")
            return None
        if player.good_fruit < 1:
            self._reject(player, "CLEAR", "RESOURCE_NOT_ENOUGH")
            return None
        rounds = self._apply_scout_preview(player, target, 6)
        return Intent(player.player_id, player.team_id, "CLEAR", f"OBSTACLE:{target}", "OBSTACLE",
                      target, rounds, process_type="CLEAR_OBSTACLE", frozen_good_cost=1)

    def _build_set_guard_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        target = action.get("targetNodeId")
        if not target:
            self._illegal(player, "MISSING_TARGET", action)
            return None
        if target != player.current_node_id:
            self._reject(player, "SET_GUARD", "TARGET_NOT_CURRENT_NODE")
            return None
        if target == "S15":
            self._reject(player, "SET_GUARD", "TARGET_FORBIDDEN")
            return None
        extra = int(action.get("extraGoodFruit", 0) or 0)
        if extra < 0 or extra > 2:
            self._reject(player, "SET_GUARD", "INVALID_EXTRA_FRUIT")
            return None
        base = self._guard_base_cost(target)
        if player.good_fruit < base + extra:
            self._reject(player, "SET_GUARD", "RESOURCE_NOT_ENOUGH")
            return None
        return Intent(player.player_id, player.team_id, "SET_GUARD", f"GUARD:{target}:{player.team_id}",
                      "NONE", target, 4, process_type="SET_GUARD",
                      frozen_good_cost=base + extra, extra={"extraGoodFruit": extra})

    def _build_forced_pass_intent(self, player: PlayerState, action: dict[str, Any]) -> Optional[Intent]:
        target = action.get("targetNodeId")
        if not target:
            self._illegal(player, "MISSING_TARGET", action)
            return None
        if player.current_node_id == player.last_forced_pass_node:
            self._reject(player, "FORCED_PASS", "FORCED_PASS_REPEAT_FORBIDDEN")
            return None
        edge = self.edge_between(player.current_node_id, target)
        if not edge:
            self._reject(player, "FORCED_PASS", "TARGET_NOT_ADJACENT")
            return None
        node = self.node_states[target]
        guard = self.enemy_guard(player, target)
        if not guard and not node.has_obstacle():
            self._reject(player, "FORCED_PASS", "NO_BLOCK")
            return None
        guard_tax = self._guard_time_tax(target, guard.defense) if guard else 0
        obstacle_tax = 8 if node.has_obstacle() else 0
        time_tax = max(guard_tax, obstacle_tax)
        route_frames = self._edge_frames(edge, player.move_per_frame(), self.round)
        extra = {
            "routeFrames": route_frames,
            "timeTax": time_tax,
            "edgeId": edge["edgeId"],
            "routeType": edge["routeType"],
            "guardTax": guard_tax,
            "obstacleTax": obstacle_tax,
            "blockType": "GUARD" if guard else "OBSTACLE",
        }
        contest_type = "PASS" if guard else "NONE"
        object_key = f"PASS:{target}:{player.team_id}"
        return Intent(player.player_id, player.team_id, "FORCED_PASS", object_key, contest_type,
                      target, route_frames + time_tax, process_type="FORCED_PASS", extra=extra)

    # ------------------------------------------------------------ intent/window
    def _resolve_intents(self, intents: list[Intent]) -> None:
        # Resource interruption: another player can challenge an active resource read-bar once.
        extra_contests: list[tuple[Intent, Intent]] = []
        for intent in list(intents):
            if intent.contest_type != "RESOURCE":
                continue
            owner = self._process_owner(intent.object_key)
            if owner and owner.team_id != intent.team_id:
                old = Intent(owner.player_id, owner.team_id, "CLAIM_RESOURCE", intent.object_key,
                             "RESOURCE", intent.target_node_id, intent.process_round,
                             resource_type=intent.resource_type, process_type="CLAIM_RESOURCE")
                owner.current_process = None
                owner.state = "CONTESTING"
                extra_contests.append((old, intent))
                intents.remove(intent)
        grouped: dict[str, list[Intent]] = {}
        for intent in intents:
            if intent.contest_type in ("NONE", ""):
                self._start_intent(intent)
                continue
            grouped.setdefault(intent.object_key, []).append(intent)
        for old, new in extra_contests:
            grouped.setdefault(new.object_key, []).extend([old, new])
        for key, items in grouped.items():
            if items[0].contest_type == "PASS":
                self._create_contest([items[0]])
            elif len(items) >= 2 and len({i.team_id for i in items}) >= 2:
                self._create_contest(items[:2])
            else:
                self._start_intent(items[0])

    def _create_contest(self, intents: list[Intent]) -> None:
        first = intents[0]
        if self.round < self.suppressed_until.get(first.object_key, 0):
            for intent in intents:
                self._reject(self.players[intent.player_id], intent.action, "WINDOW_CONTEST_REPEAT_SUPPRESSED")
            self.event("WINDOW_CONTEST_REPEAT_SUPPRESSED", objectKey=first.object_key,
                       suppressUntilRound=self.suppressed_until[first.object_key])
            return
        self.contest_seq += 1
        cid = f"C_{self.round:03d}_{self.contest_seq:03d}"
        c = Contest(cid, first.contest_type, first.object_key, first.target_node_id, self.round,
                    self.team_to_player_id["RED"], self.team_to_player_id["BLUE"])
        c.resource_type = first.resource_type
        c.task_id = first.task_id
        c.process_type = first.process_type
        for intent in intents:
            c.intents[intent.team_id] = intent
            p = self.players[intent.player_id]
            if first.contest_type != "PASS" or intent.team_id == c.attacker_team_id:
                p.state = "CONTESTING"
        if first.contest_type == "PASS":
            attacker = first
            defender_team = self.enemy_team(attacker.team_id)
            c.attacker_team_id = attacker.team_id
            c.defender_team_id = defender_team
            c.initial_time_tax_round = int(attacker.extra.get("timeTax", 0))
            c.initial_block_type = attacker.extra.get("blockType")
            c.initial_guard_tax_round = int(attacker.extra.get("guardTax", 0))
            c.initial_obstacle_tax_round = int(attacker.extra.get("obstacleTax", 0))
            c.intents[attacker.team_id] = attacker
            c.intents.setdefault(defender_team, Intent(self.team_to_player_id[defender_team], defender_team,
                                                       "PASS_DEFEND", first.object_key, "PASS", first.target_node_id))
            self.players[attacker.player_id].state = "CONTESTING"
        self.contests[cid] = c
        self.event("WINDOW_CONTEST_START", contestId=cid, contestType=c.contest_type,
                   targetNodeId=c.target_node_id, objectKey=c.object_key, taskId=c.task_id,
                   resourceType=c.resource_type)
        for intent in intents:
            self._accepted(self.players[intent.player_id], intent.action)

    def _resolve_window_cards(self, category_actions: dict[Any, dict[str, Optional[dict[str, Any]]]]) -> None:
        for c in list(self.contests.values()):
            if c.status != "ACTIVE":
                continue
            idx = c.round_index(self.round)
            if idx < 1 or idx > 3:
                continue
            round_cards: dict[str, str] = {}
            for team in ("RED", "BLUE"):
                pid = self.team_to_player_id[team]
                player = self.players[pid]
                raw = category_actions[pid].get("window")
                card = "ABSTAIN"
                if c.contest_type == "PASS" and team == c.defender_team_id and player.state in ("PROCESSING", "VERIFYING", "FORCED_PASSING", "RESTING", "DELIVERED", "RETIRED"):
                    card = "ABSTAIN"
                elif raw and raw.get("contestId") == c.contest_id:
                    if "card" not in raw:
                        self._illegal(player, "WINDOW_CARD_MISSING", raw, action_name="WINDOW_CARD")
                    elif raw.get("card") not in CARDS:
                        self._illegal(player, "WINDOW_CARD_UNKNOWN", raw, action_name="WINDOW_CARD")
                    else:
                        card = self._pay_card(player, str(raw.get("card")))
                        if raw.get("rushTactic") == "BREAK_ORDER":
                            self._illegal(player, "BREAK_ORDER_INVALID_BIND", raw, action_name="WINDOW_CARD")
                        self._accepted(player, "WINDOW_CARD")
                round_cards[team] = card
            c.cards[idx] = round_cards
            winner = self._card_winner(round_cards["RED"], round_cards["BLUE"])
            if winner:
                c.points[winner] += 1
            self.event("WINDOW_CARD_REVEAL", contestId=c.contest_id, roundIndex=idx, totalRounds=3,
                       redCard=round_cards["RED"], blueCard=round_cards["BLUE"], winner=winner)
            if idx == 3:
                self._settle_contest(c)

    def _settle_contest(self, c: Contest) -> None:
        red_pt, blue_pt = c.points["RED"], c.points["BLUE"]
        if red_pt == blue_pt:
            self._settle_contest_draw(c)
            return
        winner_team = "RED" if red_pt > blue_pt else "BLUE"
        loser_team = self.enemy_team(winner_team)
        self.draw_counts[c.object_key] = 0
        self.event("WINDOW_CONTEST_END", contestId=c.contest_id, contestType=c.contest_type,
                   winnerTeamId=winner_team, redPoint=red_pt, bluePoint=blue_pt, objectKey=c.object_key)
        if c.contest_type == "PASS":
            if winner_team == c.attacker_team_id:
                self.event("PASS_CONTEST_WIN", contestId=c.contest_id, winnerTeamId=winner_team)
                self._start_intent(c.intents[winner_team], forced_pass_deferred=True)
            else:
                attacker = self.players[c.intents[c.attacker_team_id].player_id]
                rest = min(8, max(3, math.ceil(c.initial_time_tax_round * 0.25)))
                self._start_rest(attacker, rest)
                self._record_guard_defense_success(c.target_node_id)
                self.event("PASS_CONTEST_DEFENDED", contestId=c.contest_id, winnerTeamId=winner_team,
                           targetNodeId=c.target_node_id)
            self.contests.pop(c.contest_id, None)
            return
        if winner_team in c.intents:
            self._start_intent(c.intents[winner_team])
        loser = self.player_by_team(loser_team)
        if loser and loser.state == "CONTESTING":
            loser.state = "IDLE"
        event_type = {
            "RESOURCE": "RESOURCE_CONTEST_WIN",
            "TASK": "TASK_CONTEST_WIN",
            "GATE": "GATE_CONTEST_WIN",
            "OBSTACLE": "OBSTACLE_CONTEST_WIN",
            "DOCK": "DOCK_CONTEST_WIN",
        }.get(c.contest_type, "WINDOW_CONTEST_END")
        self.event(event_type, contestId=c.contest_id, winnerTeamId=winner_team, targetNodeId=c.target_node_id)
        self.contests.pop(c.contest_id, None)

    def _settle_contest_draw(self, c: Contest) -> None:
        count = self.draw_counts.get(c.object_key, 0) + 1
        self.draw_counts[c.object_key] = count
        cooldown = 6 if c.contest_type == "GATE" else 18
        if count >= 2:
            self.suppressed_until[c.object_key] = self.round + cooldown
        self.event("WINDOW_CONTEST_DRAW", contestId=c.contest_id, contestType=c.contest_type,
                   redPoint=c.points["RED"], bluePoint=c.points["BLUE"],
                   suppressUntilRound=self.suppressed_until.get(c.object_key, 0))
        if c.contest_type == "PASS":
            attacker = self.players[c.intents[c.attacker_team_id].player_id]
            self._start_rest(attacker, 3)
            self._record_guard_defense_success(c.target_node_id)
        else:
            for intent in c.intents.values():
                self._start_rest(self.players[intent.player_id], 3)
        self.contests.pop(c.contest_id, None)

    def _start_intent(self, intent: Intent, forced_pass_deferred: bool = False) -> None:
        player = self.players[intent.player_id]
        if intent.action == "CLAIM_RESOURCE":
            node = self.node_states[intent.target_node_id]
            if node.resource_stock.get(intent.resource_type or "", 0) <= 0:
                self._reject(player, intent.action, "RESOURCE_NOT_ENOUGH")
                return
        if intent.action == "CLAIM_TASK":
            task = self.tasks.get(intent.task_id or "")
            if not task or task.status not in ("ACTIVE", "PROTECTED"):
                self._reject(player, intent.action, "TASK_NOT_AVAILABLE")
                return
            task.owner_player_id = player.player_id
            task.status = "PROCESSING"
            if task.template_id == "T06":
                if player.resources.get("FAST_HORSE", 0) > 0:
                    player.resources["FAST_HORSE"] -= 1
                elif player.resources.get("SHORT_HORSE", 0) > 0:
                    player.resources["SHORT_HORSE"] -= 1
        if intent.action == "VERIFY_GATE" and intent.extra.get("breakOrder"):
            self._try_bind_break_order(player, {"rushTactic": "BREAK_ORDER"}, for_action="VERIFY_GATE")
        if intent.frozen_good_cost:
            player.good_fruit -= intent.frozen_good_cost
            player.frozen_good_fruit += intent.frozen_good_cost
        start_round = self.round + 1 if forced_pass_deferred else self.round
        process = Process(intent.action, intent.object_key, intent.target_node_id, start_round,
                          intent.process_round, intent.process_round, task_id=intent.task_id,
                          resource_type=intent.resource_type, process_type=intent.process_type,
                          frozen_good_cost=intent.frozen_good_cost, extra=dict(intent.extra))
        player.current_process = process
        if intent.action == "VERIFY_GATE":
            player.state = "VERIFYING"
        elif intent.action == "FORCED_PASS":
            player.state = "FORCED_PASSING"
            player.next_node_id = intent.target_node_id
            player.route_edge_id = intent.extra.get("edgeId")
            player.route_type = intent.extra.get("routeType")
        else:
            player.state = "PROCESSING"
        self._consume_scout_marker(player, intent.target_node_id, process.total_round)
        self._accepted(player, intent.action)

    # --------------------------------------------------------------- progress
    def _advance_movement(self) -> None:
        for p in self.players.values():
            if p.state != "MOVING":
                continue
            route_type = p.route_type or "ROAD"
            multiplier = self.weather_travel_multiplier(route_type)
            step = math.floor(p.move_per_frame() * 1000 / multiplier)
            p.edge_progress_ms += max(1, step)
            p.move_progress_round += 1
            if route_type == "ROAD":
                p.road_rounds += 1
            elif route_type == "WATER":
                p.water_rounds += 1
            elif route_type == "MOUNTAIN":
                p.mountain_rounds += 1
            else:
                p.branch_rounds += 1
            if p.edge_progress_ms >= p.edge_total_ms:
                target = p.next_node_id
                p.current_node_id = target or p.current_node_id
                p.next_node_id = None
                p.route_edge_id = None
                p.route_type = None
                p.move_direction = "NONE"
                p.edge_progress_ms = 0
                p.edge_total_ms = 0
                p.move_progress_round = 0
                p.state = "IDLE"
                p.processed_current_node = False
                self.event("NODE_ENTER", playerId=p.player_id, teamId=p.team_id, nodeId=p.current_node_id)
            else:
                self.event("MOVE_PROGRESS", playerId=p.player_id, teamId=p.team_id,
                           fromNodeId=p.current_node_id, toNodeId=p.next_node_id,
                           routeEdgeId=p.route_edge_id, edgeProgressMs=p.edge_progress_ms,
                           edgeTotalMs=p.edge_total_ms,
                           progress=round(p.edge_progress_ms / max(1, p.edge_total_ms), 4))

    def _advance_processes(self) -> None:
        for p in self.players.values():
            proc = p.current_process
            if not proc:
                continue
            if proc.action == "REST":
                proc.remain_round -= 1
                if proc.remain_round <= 0:
                    p.current_process = None
                    if not p.retired and not p.delivered:
                        p.state = "IDLE"
                continue
            if self.round < proc.started_round:
                continue
            proc.remain_round -= 1
            if proc.remain_round > 0:
                self.event("PROCESS_PROGRESS", playerId=p.player_id, teamId=p.team_id,
                           action=proc.action, objectKey=proc.object_key, remainRound=proc.remain_round)
                continue
            self._complete_process(p, proc)

    def _complete_process(self, p: PlayerState, proc: Process) -> None:
        p.current_process = None
        if proc.frozen_good_cost:
            p.frozen_good_fruit = max(0, p.frozen_good_fruit - proc.frozen_good_cost)
        if proc.action == "CLAIM_RESOURCE":
            node = self.node_states[proc.target_node_id]
            rtype = proc.resource_type or ""
            if node.resource_stock.get(rtype, 0) > 0:
                node.resource_stock[rtype] -= 1
                p.resources[rtype] = p.resources.get(rtype, 0) + 1
                self.event("RESOURCE_CLAIM", playerId=p.player_id, teamId=p.team_id,
                           nodeId=proc.target_node_id, resourceType=rtype, resourceDelta=1)
            else:
                self.event("ACTION_REJECTED", playerId=p.player_id, action=proc.action,
                           errorCode="RESOURCE_NOT_ENOUGH")
        elif proc.action == "CLAIM_TASK":
            task = self.tasks.get(proc.task_id or "")
            if task and task.status == "PROCESSING":
                if task.template_id == "T04":
                    if self.node_states[task.target_node_id].has_obstacle():
                        self._clear_obstacle(task.target_node_id, p, residue=False)
                    else:
                        task.status = "FAILED"
                        self.event("TASK_TARGET_LOST", playerId=p.player_id, taskId=task.task_id,
                                   targetNodeId=task.target_node_id)
                        p.state = "IDLE"
                        return
                task.status = "COMPLETED"
                p.completed_task_ids.add(task.task_id)
                p.task_score_base += task.score
                self.event("TASK_COMPLETE", playerId=p.player_id, teamId=p.team_id, taskId=task.task_id,
                           targetNodeId=task.target_node_id, score=task.score, taskScore=p.task_score_base)
        elif proc.action in ("PROCESS", "DOCK"):
            p.processed_current_node = True
            self.event("PROCESS_COMPLETE", playerId=p.player_id, teamId=p.team_id,
                       nodeId=proc.target_node_id, processType=proc.process_type)
        elif proc.action == "VERIFY_GATE":
            p.verified = True
            p.processed_current_node = True
            self.event("VERIFY_GATE_COMPLETE", playerId=p.player_id, teamId=p.team_id, nodeId=proc.target_node_id)
        elif proc.action == "CLEAR":
            if self.node_states[proc.target_node_id].has_obstacle():
                self._clear_obstacle(proc.target_node_id, p, residue=True)
            else:
                self.event("ACTION_REJECTED", playerId=p.player_id, action=proc.action,
                           errorCode="NO_OBSTACLE")
        elif proc.action == "SET_GUARD":
            self._complete_set_guard(p, proc)
        elif proc.action == "FORCED_PASS":
            p.current_node_id = proc.target_node_id
            p.next_node_id = None
            p.route_edge_id = None
            p.route_type = None
            p.last_forced_pass_node = proc.target_node_id
            p.processed_current_node = False
            self.event("FORCED_PASS_END", playerId=p.player_id, teamId=p.team_id, targetNodeId=proc.target_node_id)
        if not p.delivered and not p.retired:
            p.state = "IDLE"

    def _complete_set_guard(self, p: PlayerState, proc: Process) -> None:
        node = self.node_states[proc.target_node_id]
        if node.guard and node.guard.defense > 0:
            self.event("ACTION_REJECTED", playerId=p.player_id, action="SET_GUARD", errorCode="OBJECT_BUSY")
            return
        max_def = self._guard_max_defense(proc.target_node_id)
        extra = int(proc.extra.get("extraGoodFruit", 0) or 0)
        defense = min(max_def, 2 + extra * 2)
        first = 45 if self.nodes_config[proc.target_node_id]["nodeType"] == "KEY_PASS" and defense >= 4 else 30
        self.guard_order_seq += 1
        node.guard = Guard(p.player_id, p.team_id, defense, defense, max_def, self.round,
                           self._guard_kind(proc.target_node_id), first, self.round + first,
                           self.guard_order_seq, active_from_round=self.round + 1)
        self._enforce_guard_limit(p.team_id)
        self.event("GUARD_SET", playerId=p.player_id, teamId=p.team_id, targetNodeId=proc.target_node_id,
                   defense=defense, maxDefense=max_def)

    # -------------------------------------------------------------- squad acts
    def _resolve_squad_actions(self, category_actions: dict[Any, dict[str, Optional[dict[str, Any]]]]) -> None:
        for pid, data in category_actions.items():
            action = data.get("squad")
            if not action:
                continue
            player = self.players[pid]
            name = action.get("action")
            target = action.get("targetNodeId")
            if self.phase == "RUSH":
                self._reject(player, name, "RUSH_FORBIDS_NEW_SQUAD")
                continue
            if not target or target not in self.node_states:
                self._illegal(player, "MISSING_TARGET", action)
                continue
            costs = {"SQUAD_SCOUT": 1, "SQUAD_CLEAR": 2, "SQUAD_REINFORCE": 2, "SQUAD_WEAKEN": 2}
            cost = costs[name]
            if player.squad_available < cost:
                self._reject(player, name, "SQUAD_NOT_ENOUGH")
                continue
            if name == "SQUAD_CLEAR" and not self.node_states[target].has_obstacle():
                self._reject(player, name, "NO_OBSTACLE")
                continue
            if name == "SQUAD_REINFORCE" and not self.my_guard(player, target):
                self._reject(player, name, "NO_OWN_GUARD")
                continue
            if name == "SQUAD_WEAKEN" and not self.enemy_guard(player, target):
                self._reject(player, name, "NO_ENEMY_GUARD")
                continue
            player.squad_available -= cost
            player.squad_in_flight += cost
            delay = self._squad_delay(player, target, name)
            self.order_seq += 1
            order = SquadOrder(f"SQ_{self.round:03d}_{self.order_seq:03d}", player.player_id,
                               player.team_id, name, target, cost, self.round + delay)
            self.squad_orders.append(order)
            self._accepted(player, name)
            self.event("SQUAD_DISPATCH", playerId=player.player_id, teamId=player.team_id,
                       orderId=order.order_id, action=name, targetNodeId=target,
                       arrivalRound=order.arrival_round)

    def _resolve_squad_arrivals(self) -> None:
        order_rank = {"SQUAD_REINFORCE": 1, "SQUAD_WEAKEN": 2, "SQUAD_CLEAR": 3, "SQUAD_SCOUT": 4}
        arrivals = [o for o in self.squad_orders if o.arrival_round <= self.round]
        self.squad_orders = [o for o in self.squad_orders if o.arrival_round > self.round]
        arrivals.sort(key=lambda o: (order_rank.get(o.action, 99), o.order_id))
        for o in arrivals:
            player = self.players[o.player_id]
            player.squad_in_flight = max(0, player.squad_in_flight - o.cost)
            node = self.node_states[o.target_node_id]
            if o.action == "SQUAD_SCOUT":
                self._add_scout_marker(o.team_id, o.target_node_id)
                self.event("SQUAD_SCOUT", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                           targetNodeId=o.target_node_id)
            elif o.action == "SQUAD_CLEAR":
                if node.has_obstacle():
                    self._clear_obstacle(o.target_node_id, player, residue=True)
                    self.event("SQUAD_CLEAR", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               targetNodeId=o.target_node_id)
                else:
                    self.event("SQUAD_FAILED", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               action=o.action, targetNodeId=o.target_node_id)
            elif o.action == "SQUAD_REINFORCE":
                guard = self.my_guard(player, o.target_node_id)
                if guard:
                    before = guard.defense
                    guard.defense = min(guard.max_defense, guard.defense + 2)
                    self.event("SQUAD_REINFORCE", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               targetNodeId=o.target_node_id, before=before, after=guard.defense)
                else:
                    self.event("SQUAD_FAILED", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               action=o.action, targetNodeId=o.target_node_id)
            elif o.action == "SQUAD_WEAKEN":
                guard = self.enemy_guard(player, o.target_node_id)
                if guard:
                    before = guard.defense
                    guard.defense = max(0, guard.defense - 2)
                    self.event("SQUAD_WEAKEN", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               targetNodeId=o.target_node_id, before=before, after=guard.defense)
                    if guard.defense <= 0:
                        self._expire_bounty_for_node(o.target_node_id, "GUARD_WEAKENED")
                else:
                    self.event("SQUAD_FAILED", playerId=o.player_id, teamId=o.team_id, orderId=o.order_id,
                               action=o.action, targetNodeId=o.target_node_id)

    # ---------------------------------------------------------- scoring/rules
    def score_detail(self, p: PlayerState) -> dict[str, int]:
        penalty = min(20, max(0, p.illegal_action_count - 5)) + min(30, p.post_deliver_violation_count * 5)
        p.penalty_score = penalty
        task_base = p.task_score_base
        if p.delivered:
            delivery = min(240, 120 + math.floor(task_base * 4 / 3))
            good = math.floor(p.deliver_good_fruit / 100 * 180)
            fresh = math.floor(p.deliver_freshness / 100 * 180)
            raw_time = max(0, math.floor((SCORING_MAX_ROUND - p.deliver_round) / SCORING_MAX_ROUND * 70))
            time_score = math.floor(raw_time * min(task_base, 90) / 90)
            milestone = 0 if task_base < 60 else 15 if task_base < 90 else 35 if task_base < 110 else 50
            tasks = min(180, task_base + milestone)
            bounty = min(p.bounty_score_raw, 80) + 20 if p.bounty_score_raw > 0 else 0
        else:
            delivery = good = fresh = time_score = 0
            tasks = min(task_base, 80)
            bounty = min(p.bounty_score_raw, 25)
        total = max(0, delivery + good + fresh + time_score + tasks + bounty - penalty)
        return {
            "delivery": int(delivery),
            "goodFruit": int(good),
            "freshness": int(fresh),
            "time": int(time_score),
            "tasks": int(tasks),
            "bounty": int(bounty),
            "penalty": int(penalty),
            "total": int(total),
        }

    def league_points(self) -> dict[str, int]:
        red, blue = self.players_list()
        if red.abnormal and blue.abnormal:
            return {str(red.player_id): 0, str(blue.player_id): 0}
        if red.abnormal:
            return {str(red.player_id): 0, str(blue.player_id): 1}
        if blue.abnormal:
            return {str(red.player_id): 1, str(blue.player_id): 0}
        rs, bs = self.score_detail(red)["total"], self.score_detail(blue)["total"]
        if rs > bs:
            return {str(red.player_id): 3, str(blue.player_id): 0}
        if bs > rs:
            return {str(red.player_id): 0, str(blue.player_id): 3}
        if rs == 0:
            return {str(red.player_id): 0, str(blue.player_id): 0}
        if red.deliver_freshness != blue.deliver_freshness:
            return self._tie_points(red, blue, red.deliver_freshness > blue.deliver_freshness)
        if red.deliver_good_fruit != blue.deliver_good_fruit:
            return self._tie_points(red, blue, red.deliver_good_fruit > blue.deliver_good_fruit)
        if red.penalty_score != blue.penalty_score:
            return self._tie_points(red, blue, red.penalty_score < blue.penalty_score)
        return {str(red.player_id): 1, str(blue.player_id): 1}

    def _tie_points(self, red: PlayerState, blue: PlayerState, red_wins: bool) -> dict[str, int]:
        return {str(red.player_id): 3 if red_wins else 1, str(blue.player_id): 1 if red_wins else 3}

    def _apply_freshness(self) -> None:
        for p in self.players.values():
            if p.delivered or p.retired:
                continue
            base, context = self._freshness_context(p)
            multiplier = self.weather_fresh_multiplier(context)
            if p.has_buff("RUSH_SPEED"):
                multiplier *= 1.25
            if p.has_buff("RUSH_PROTECT"):
                multiplier *= 0.2
            before = p.freshness
            p.freshness = max(0.0, min(100.0, p.freshness - base * multiplier))
            if p.freshness != before:
                self.event("FRESHNESS_DROP", playerId=p.player_id, teamId=p.team_id,
                           freshness=round(p.freshness, 3))
            self._convert_good_to_bad(p)

    def _freshness_context(self, p: PlayerState) -> tuple[float, str]:
        if p.state == "MOVING" and p.route_type:
            return FRESH_RATE.get(p.route_type, 0.05), p.route_type
        proc = p.current_process
        if p.state == "FORCED_PASSING" and proc:
            if proc.extra.get("timeTax", 0) and proc.remain_round > int(proc.extra.get("routeFrames", 0)):
                return 0.05, "IDLE"
            return FRESH_RATE.get(proc.extra.get("routeType", "ROAD"), 0.05), proc.extra.get("routeType", "ROAD")
        if proc and proc.process_type in WATER_PROCESS_TYPES:
            return 0.05, "WATER"
        return 0.05, "IDLE"

    def _convert_good_to_bad(self, p: PlayerState) -> None:
        cost_bankrupt = False
        for threshold in [90, 80, 70, 60, 50, 40, 30, 20, 10]:
            if threshold not in p.freshness_thresholds and p.freshness < threshold:
                p.freshness_thresholds.add(threshold)
                if p.good_fruit > 0:
                    p.good_fruit -= 1
                elif p.frozen_good_fruit > 0:
                    p.frozen_good_fruit -= 1
                    cost_bankrupt = True
                p.bad_fruit += 1
                self.event("GOOD_TO_BAD", playerId=p.player_id, teamId=p.team_id,
                           threshold=threshold, goodFruit=p.good_fruit, badFruit=p.bad_fruit)
        if p.good_fruit + p.frozen_good_fruit <= 0:
            p.freshness = 0.0
        if p.freshness <= 0 and (p.good_fruit > 0 or p.frozen_good_fruit > 0):
            if p.frozen_good_fruit > 0:
                cost_bankrupt = True
            p.good_fruit = 0
            p.frozen_good_fruit = 0
            self.event("GOOD_FRUIT_SCRAP", playerId=p.player_id, teamId=p.team_id)
        if cost_bankrupt:
            p.current_process = None
            p.state = "COST_BANKRUPT"
            self.event("COST_BANKRUPT", playerId=p.player_id, teamId=p.team_id)

    def _tick_buffs(self) -> None:
        for p in self.players.values():
            expired = []
            for buff in list(p.buffs):
                p.buffs[buff] -= 1
                if p.buffs[buff] <= 0:
                    expired.append(buff)
            for buff in expired:
                p.buffs.pop(buff, None)

    def _update_scores(self) -> None:
        for p in self.players.values():
            p.penalty_score = self.score_detail(p)["penalty"]

    # --------------------------------------------------------------- helpers
    def event(self, event_type: str, **payload: Any) -> None:
        self.event_seq += 1
        self.events.append({
            "eventId": f"EV_{self.round:03d}_{self.event_seq:04d}",
            "type": event_type,
            "round": self.round,
            "payload": payload,
        })

    def _accepted(self, p: PlayerState, action_name: str, accepted: bool = True,
                  error_code: Optional[str] = None) -> None:
        self.action_results.append({
            "round": self.round,
            "playerId": p.player_id,
            "action": action_name,
            "accepted": accepted,
            "result": "ACCEPTED" if accepted else "REJECTED",
            "errorCode": error_code,
            "message": error_code or "",
        })

    def _reject(self, p: PlayerState, action_name: str, code: str) -> None:
        self._accepted(p, action_name, accepted=False, error_code=code)
        self.event("ACTION_REJECTED", playerId=p.player_id, teamId=p.team_id,
                   action=action_name, errorCode=code)

    def _illegal(self, p: PlayerState, code: str, action: Optional[dict[str, Any]],
                 action_name: Optional[str] = None) -> None:
        p.illegal_action_count += 1
        name = action_name or (action or {}).get("action") or "UNKNOWN"
        self._accepted(p, name, accepted=False, error_code=code)
        self.event("INVALID_ACTION", playerId=p.player_id, teamId=p.team_id,
                   action=name, errorCode=code, illegalActionCount=p.illegal_action_count)

    def _post_deliver_penalty(self, p: PlayerState, action: dict[str, Any]) -> None:
        p.post_deliver_violation_count += 1
        self.event("POST_DELIVER_PENALTY", playerId=p.player_id, teamId=p.team_id,
                   action=action.get("action"), penaltyScore=min(30, p.post_deliver_violation_count * 5))

    def _retire_player(self, p: PlayerState, reason: str) -> None:
        if p.retired or p.delivered:
            return
        p.retired = True
        p.retired_round = self.round
        p.state = "RETIRED"
        p.current_process = None
        self.event("PLAYER_RETIRED", playerId=p.player_id, teamId=p.team_id, reason=reason)
        self.event("RETIREMENT_CLEANUP", playerId=p.player_id, teamId=p.team_id)

    def players_list(self) -> list[PlayerState]:
        return [self.players[self.team_to_player_id["RED"]], self.players[self.team_to_player_id["BLUE"]]]

    def player_by_team(self, team: str) -> Optional[PlayerState]:
        pid = self.team_to_player_id.get(team)
        return self.players.get(pid)

    @staticmethod
    def enemy_team(team: str) -> str:
        return "BLUE" if team == "RED" else "RED"

    def edge_between(self, a: Optional[str], b: Optional[str]) -> Optional[dict[str, Any]]:
        if not a or not b:
            return None
        for edge in self.adj.get(a, []):
            if edge["toNodeId"] == b:
                return edge
        return None

    def enemy_guard(self, player: PlayerState, nid: str) -> Optional[Guard]:
        guard = self.node_states[nid].guard
        if guard and guard.active(self.round) and guard.owner_team_id != player.team_id:
            return guard
        return None

    def my_guard(self, player: PlayerState, nid: str) -> Optional[Guard]:
        guard = self.node_states[nid].guard
        if guard and guard.active(self.round) and guard.owner_team_id == player.team_id:
            return guard
        return None

    def _must_process_before_leave(self, p: PlayerState, target: str) -> bool:
        if p.current_node_id == "S15" and target == "S14":
            return False
        node = self.node_states[p.current_node_id]
        return bool(node.process_type in PROCESS_TYPES_NEED_VISIT and not p.processed_current_node)

    def _claim_round(self, node_id: str, resource_type: str) -> int:
        for item in self.map_config["resources"]:
            if item["nodeId"] == node_id and item["resourceType"] == resource_type:
                return int(item.get("claimRound", 2))
        return 2

    def _process_round_with_weather(self, process_type: str, base: int) -> int:
        if process_type in WATER_PROCESS_TYPES and self._rain_active("WATER"):
            return base + 4
        return base

    def _apply_scout_preview(self, p: PlayerState, target: str, base_rounds: int) -> int:
        marker = self._first_scout_marker(p.team_id, target)
        if marker and base_rounds > 0:
            return max(2, base_rounds - marker.process_reduce_round)
        return base_rounds

    def _consume_scout_marker(self, p: PlayerState, target: str, total_rounds: int) -> None:
        marker = self._first_scout_marker(p.team_id, target)
        if not marker:
            return
        marker.remaining_triggers -= 1
        self.event("SCOUT_MARKER_APPLY", playerId=p.player_id, teamId=p.team_id, targetNodeId=target,
                   processReduceRound=marker.process_reduce_round)
        if marker.remaining_triggers <= 0:
            self.node_states[target].scouts.remove(marker)
            self.event("SCOUT_MARKER_CONSUME", playerId=p.player_id, teamId=p.team_id, targetNodeId=target)

    def _first_scout_marker(self, team: str, target: str) -> Optional[ScoutMarker]:
        node = self.node_states[target]
        for marker in node.scouts:
            if marker.team_id == team and marker.remaining_triggers > 0 and self.round <= marker.expire_round:
                return marker
        return None

    def _add_scout_marker(self, team: str, target: str) -> None:
        marker = ScoutMarker(team, self.round, self.round + 45)
        self.node_states[target].scouts.append(marker)
        self.event("SCOUT_MARKER_ADD", teamId=team, targetNodeId=target, expireRound=marker.expire_round)

    def _cleanup_expired_markers(self) -> None:
        for nid, node in self.node_states.items():
            kept = []
            for marker in node.scouts:
                if marker.remaining_triggers <= 0 or self.round > marker.expire_round:
                    self.event("SCOUT_MARKER_EXPIRE", teamId=marker.team_id, targetNodeId=nid)
                else:
                    kept.append(marker)
            node.scouts = kept

    def _clear_obstacle(self, target: str, p: PlayerState, residue: bool) -> None:
        node = self.node_states[target]
        node.obstacle_type = None
        if residue:
            node.obstacle_residue = ObstacleResidue(p.player_id, p.team_id, self.round, self.round + 30)
        self.event("OBSTACLE_CLEAR", playerId=p.player_id, teamId=p.team_id, targetNodeId=target,
                   residue=residue)

    def _guard_kind(self, target: str) -> str:
        if self.nodes_config[target]["nodeType"] == "KEY_PASS":
            return "KEY_PASS"
        if target == "S14":
            return "GATE"
        if self.node_states[target].has_obstacle():
            return "OBSTACLE"
        return "NORMAL"

    def _guard_base_cost(self, target: str) -> int:
        return 1 if self.nodes_config[target]["nodeType"] == "KEY_PASS" or target == "S14" else 0

    def _guard_max_defense(self, target: str) -> int:
        if self.node_states[target].has_obstacle():
            return 5
        if self.nodes_config[target]["nodeType"] == "KEY_PASS":
            return 7
        if target == "S14":
            return 4
        return 6

    def _guard_time_tax(self, target: str, defense: int) -> int:
        kind = self._guard_kind(target)
        if kind == "KEY_PASS":
            return min(50, 15 + defense * 5)
        if kind == "GATE":
            return min(32, 12 + defense * 5)
        if kind == "OBSTACLE":
            return min(28, 8 + defense * 5)
        return min(40, 10 + defense * 5)

    def _enforce_guard_limit(self, team: str) -> None:
        guards = []
        for nid, node in self.node_states.items():
            if node.guard and node.guard.owner_team_id == team and node.guard.defense > 0:
                guards.append((node.guard.order, nid))
        guards.sort()
        while len(guards) > 2:
            _, nid = guards.pop(0)
            self.node_states[nid].guard = None
            self._expire_bounty_for_node(nid, "GUARD_LIMIT")

    def _apply_guard_weathering_and_bounties(self) -> None:
        for nid, node in self.node_states.items():
            guard = node.guard
            if not guard or guard.defense <= 0:
                continue
            age = self.round - guard.complete_round
            if age in (30, 60):
                self._maybe_create_bounty(nid, key=False, reason=f"AGE_{age}")
            if self.nodes_config[nid]["nodeType"] == "KEY_PASS" and guard.key_combat_count >= 3:
                self._maybe_create_bounty(nid, key=True, reason="KEY_COMBAT")
            if self.round >= guard.next_weather_round:
                before = guard.defense
                guard.defense = max(0, guard.defense - 1)
                guard.next_weather_round += 30
                self.event("GUARD_WEATHERING", targetNodeId=nid, ownerTeamId=guard.owner_team_id,
                           before=before, after=guard.defense)
                if guard.defense <= 0:
                    self._expire_bounty_for_node(nid, "GUARD_WEATHERING")

    def _record_guard_defense_success(self, target: str) -> None:
        node = self.node_states[target]
        guard = node.guard
        if guard:
            guard.attack_fail_count += 1
            node.guard_block_count += 1
            self._maybe_create_bounty(target, key=False, reason="PASS_DEFENDED")

    def _maybe_create_bounty(self, target: str, key: bool, reason: str) -> None:
        node = self.node_states[target]
        guard = node.guard
        if not guard or guard.defense <= 0:
            return
        if self.round < node.bounty_cooldown_until_round:
            return
        if any(b.status == "ACTIVE" and b.node_id == target for b in self.bounties.values()):
            return
        if not key and guard.attack_fail_count < 2 and not reason.startswith("AGE_"):
            return
        if key and self.nodes_config[target]["nodeType"] != "KEY_PASS":
            return
        self.bounty_seq += 1
        btype = "KEY_BOUNTY" if key else "NORMAL_BOUNTY"
        score = 18 if key else 10
        bounty = Bounty(f"B_{target}_{self.bounty_seq:03d}", btype, target, guard.owner_team_id, score, self.round)
        self.bounties[bounty.bounty_id] = bounty
        self.event("BOUNTY_CREATE", bountyId=bounty.bounty_id, bountyType=btype, targetNodeId=target,
                   score=score, reason=reason)

    def _claim_bounty_if_eligible(self, p: PlayerState, target: str, attacker_score: int, defender_score: int) -> None:
        active = [b for b in self.bounties.values() if b.node_id == target and b.status == "ACTIVE"]
        if not active:
            return
        bounty = active[0]
        if attacker_score < defender_score:
            p.bounty_score_raw += bounty.score
            bounty.status = "CLAIMED"
            self.node_states[target].bounty_cooldown_until_round = self.round + 120
            self.event("BOUNTY_CLAIM", playerId=p.player_id, teamId=p.team_id, bountyId=bounty.bounty_id,
                       targetNodeId=target, score=bounty.score, bountyScore=p.bounty_score_raw)

    def _expire_bounty_for_node(self, target: str, reason: str) -> None:
        for bounty in self.bounties.values():
            if bounty.node_id == target and bounty.status == "ACTIVE":
                bounty.status = "EXPIRED"
                self.node_states[target].bounty_cooldown_until_round = self.round + 120
                self.event("BOUNTY_EXPIRE", bountyId=bounty.bounty_id, targetNodeId=target, reason=reason)

    def _try_bind_break_order(self, p: PlayerState, action: dict[str, Any], for_action: str,
                              dry_run: bool = False) -> int:
        if action.get("rushTactic") != "BREAK_ORDER":
            return 0
        if self.phase != "RUSH" or p.rush_tactic_used_count >= 1:
            if not dry_run:
                self._illegal(p, "RUSH_TACTIC_NOT_AVAILABLE", action)
            return 0
        cost_bad = p.bad_fruit >= 2
        if not cost_bad and p.good_fruit < 1:
            if not dry_run:
                self._reject(p, for_action, "BREAK_ORDER_COST_NOT_ENOUGH")
            return 0
        if dry_run:
            return 3
        if cost_bad:
            p.bad_fruit -= 2
            cost_type = "BAD_FRUIT"
        else:
            p.good_fruit -= 1
            cost_type = "GOOD_FRUIT"
        p.rush_tactic_used_count += 1
        self.event("BREAK_ORDER_BIND", playerId=p.player_id, teamId=p.team_id,
                   action=for_action, costType=cost_type)
        return 3

    def _pay_card(self, p: PlayerState, card: str) -> str:
        if card == "ABSTAIN":
            return card
        if card == "YAN_DIE":
            if p.resources.get("PASS_TOKEN", 0) > 0:
                p.resources["PASS_TOKEN"] -= 1
                return card
            if p.resources.get("OFFICIAL_PERMIT", 0) > 0:
                p.resources["OFFICIAL_PERMIT"] -= 1
                return card
            return "ABSTAIN"
        if card == "QIANG_XING":
            if p.active_horse() or p.has_buff("RUSH_SPEED"):
                return card
            if p.resources.get("FAST_HORSE", 0) > 0:
                p.resources["FAST_HORSE"] -= 1
                return card
            if p.resources.get("SHORT_HORSE", 0) > 0:
                p.resources["SHORT_HORSE"] -= 1
                return card
            return "ABSTAIN"
        if card == "XIAN_GONG":
            if p.freshness >= 80 and p.good_fruit >= 1:
                p.good_fruit -= 1
                return card
            return "ABSTAIN"
        if card == "BING_ZHENG":
            if p.guard_action_point >= 1:
                p.guard_action_point -= 1
                return card
            return "ABSTAIN"
        return "ABSTAIN"

    def _card_winner(self, red: str, blue: str) -> Optional[str]:
        if red == "ABSTAIN" and blue == "ABSTAIN":
            return None
        if red != "ABSTAIN" and blue == "ABSTAIN":
            return "RED"
        if blue != "ABSTAIN" and red == "ABSTAIN":
            return "BLUE"
        if red == blue:
            return None
        result = CARD_RESULT.get((red, blue), 0)
        if result > 0:
            return "RED"
        if result < 0:
            return "BLUE"
        return None

    def _start_rest(self, p: PlayerState, rounds: int) -> None:
        p.state = "RESTING"
        p.current_process = Process("REST", "REST", p.current_node_id, self.round, rounds, rounds)

    def _process_owner(self, object_key: str) -> Optional[PlayerState]:
        for p in self.players.values():
            if p.current_process and p.current_process.object_key == object_key:
                return p
        return None

    def _squad_delay(self, p: PlayerState, target: str, action_name: str) -> int:
        source = p.current_node_id
        sx, sy = self.nodes_config[source]["x"], self.nodes_config[source]["y"]
        tx, ty = self.nodes_config[target]["x"], self.nodes_config[target]["y"]
        dist = max(abs(sx - tx), abs(sy - ty))
        base = min(15, max(3, math.ceil(dist / 3)))
        if action_name == "SQUAD_SCOUT" and self._fog_active_for_node(target):
            base = min(15, base + 2)
        return base

    def _edge_frames(self, edge: dict[str, Any], per_frame: int, start_round: int) -> int:
        remaining = math.ceil(int(edge["distance"]) * ROUTE_COEFF.get(edge["routeType"], 1380))
        frames = 0
        while remaining > 0:
            mult = self.weather_travel_multiplier(edge["routeType"], start_round + frames)
            remaining -= max(1, math.floor(per_frame * 1000 / mult))
            frames += 1
        return max(1, frames)

    def weather_travel_multiplier(self, route_type: str, round_no: Optional[int] = None) -> int:
        round_no = self.round if round_no is None else round_no
        for w in self.weather_events:
            if not (w["startRound"] <= round_no <= w["startRound"] + w["durationRound"] - 1):
                continue
            if w["type"] == "HEAVY_RAIN" and route_type == "WATER":
                return 1350
            if w["type"] == "MOUNTAIN_FOG" and route_type == "MOUNTAIN":
                return 1100
        return 1000

    def weather_fresh_multiplier(self, context: str, round_no: Optional[int] = None) -> float:
        round_no = self.round if round_no is None else round_no
        mult = 1.0
        for w in self.weather_events:
            if not (w["startRound"] <= round_no <= w["startRound"] + w["durationRound"] - 1):
                continue
            if w["type"] == "HOT":
                mult = max(mult, 1.5)
            elif w["type"] == "HEAVY_RAIN" and context == "WATER":
                mult = max(mult, 1.3)
        return mult

    def _rain_active(self, region: str) -> bool:
        return any(w["type"] == "HEAVY_RAIN" and w["startRound"] <= self.round <= w["startRound"] + w["durationRound"] - 1
                   and w["region"] in (region, "ALL") for w in self.weather_events)

    def _fog_active_for_node(self, target: str) -> bool:
        node_type = self.nodes_config[target]["nodeType"]
        mountain = node_type in ("MOUNTAIN_NODE", "MOUNTAIN_PASS", "KEY_PASS")
        return mountain and any(w["type"] == "MOUNTAIN_FOG" and w["startRound"] <= self.round <= w["startRound"] + w["durationRound"] - 1
                                for w in self.weather_events)

    def shortest_distance(self, source: str, target: str) -> float:
        if source == target:
            return 0.0
        frontier = [(0.0, source)]
        best = {source: 0.0}
        while frontier:
            frontier.sort(reverse=True)
            dist, node = frontier.pop()
            if node == target:
                return dist
            if dist > best.get(node, float("inf")):
                continue
            for edge in self.adj.get(node, []):
                nd = dist + int(edge["distance"])
                to = edge["toNodeId"]
                if nd < best.get(to, float("inf")):
                    best[to] = nd
                    frontier.append((nd, to))
        return float("inf")

    def _update_rush_phase(self) -> None:
        if self.phase == "RUSH":
            return
        if self.round < 390:
            return
        if self.round >= 450:
            self._start_rush()
            return
        excluded = set(self.map_config["gameplay"]["roles"].get("rushExcludedNodeIds", []))
        for p in self.players.values():
            if p.current_node_id == "S14":
                self._start_rush()
                return
            if p.current_node_id not in excluded and self.shortest_distance(p.current_node_id, "S14") <= 15:
                self._start_rush()
                return
            if p.current_node_id not in excluded and self._fastest_frames_to_finish(p.current_node_id) <= 60:
                self._start_rush()
                return

    def _fastest_frames_to_finish(self, source: str) -> float:
        path_dist = self.shortest_distance(source, "S15")
        if math.isinf(path_dist):
            return float("inf")
        return math.ceil(path_dist * 1250 / BASE_MOVE)

    def _start_rush(self) -> None:
        self.phase = "RUSH"
        self.event("RUSH_START")

    def _refresh_tasks_for_next_inquire(self, round_no: int) -> None:
        if round_no < self.next_task_refresh_round:
            return
        active = [t for t in self.tasks.values() if t.status in ("ACTIVE", "PROTECTED")]
        if len(active) >= 10 or len([t for t in self.tasks.values() if t.status in ("ACTIVE", "PROTECTED", "PROCESSING")]) >= 18:
            self.next_task_refresh_round = round_no + self.task_refresh_interval
            return
        templates = list(TASK_TEMPLATES)
        self.random.shuffle(templates)
        created = 0
        for tid in templates:
            if created >= 3 or len(active) + created >= 10:
                break
            candidates = list(self.map_config["taskCandidates"].get(tid, []))
            if not candidates:
                continue
            target = self.random.choice(candidates)
            if tid == "T04" and not self.node_states[target].has_obstacle():
                continue
            cfg = TASK_TEMPLATES[tid]
            self.task_seq += 1
            route_buckets = self._task_route_buckets(target)
            task = Task(f"{tid}_{self.task_seq:03d}", tid, target, cfg["score"], cfg["processRound"],
                        cfg["processType"], round_no, min(self.duration_round, round_no + 120),
                        score_tier=self._task_score_tier(cfg["score"]),
                        route_bucket=route_buckets[0] if route_buckets else "ANY",
                        route_buckets=route_buckets)
            self.tasks[task.task_id] = task
            self.event("TASK_REFRESH", taskId=task.task_id, taskTemplateId=tid, targetNodeId=target,
                       score=task.score, scoreTier=task.score_tier, routeBucket=task.route_bucket,
                       expireRound=task.expire_round)
            created += 1
        self.next_task_refresh_round = round_no + self.task_refresh_interval

    def _task_route_buckets(self, target_node_id: str) -> list[str]:
        order = ["ROAD", "WATER", "MOUNTAIN", "BRANCH"]
        buckets = []
        configured = self.map_config.get("routeTaskBuckets", {}) or {}
        for bucket in order:
            if target_node_id in set(configured.get(bucket, []) or []):
                buckets.append(bucket)
        return buckets

    @staticmethod
    def _task_score_tier(score: int) -> str:
        if score >= 30:
            return "HIGH"
        if score >= 15:
            return "STANDARD"
        return "LOW"

    def _expire_tasks(self) -> None:
        for task in self.tasks.values():
            if task.status in ("ACTIVE", "PROTECTED") and self.round >= task.expire_round:
                task.status = "EXPIRED"
                self.event("TASK_EXPIRE", taskId=task.task_id, targetNodeId=task.target_node_id,
                           reason="TIMEOUT")

    # --------------------------------------------------------------- publics
    def _player_public(self, p: PlayerState) -> dict[str, Any]:
        progress = 0.0
        if p.edge_total_ms > 0:
            progress = min(1.0, p.edge_progress_ms / p.edge_total_ms)
        detail = self.score_detail(p)
        return {
            "playerId": p.player_id,
            "camp": p.camp,
            "teamId": p.team_id,
            "playerName": p.player_name,
            "online": p.online,
            "state": p.state,
            "currentNodeId": p.current_node_id,
            "nextNodeId": p.next_node_id,
            "routeEdgeId": p.route_edge_id,
            "routeType": p.route_type,
            "moveDirection": p.move_direction,
            "moveProgress": round(progress, 4),
            "moveProgressRound": p.move_progress_round,
            "currentEdgeCost": p.edge_total_ms,
            "edgeProgressPermille": int(progress * 1000),
            "edgeProgressMs": p.edge_progress_ms,
            "edgeTotalMs": p.edge_total_ms,
            "freshness": round(p.freshness, 3),
            "goodFruit": p.good_fruit,
            "frozenGoodFruit": p.frozen_good_fruit,
            "badFruit": p.bad_fruit,
            "squadAvailable": p.squad_available,
            "squadInFlight": p.squad_in_flight,
            "guardActionPoint": p.guard_action_point,
            "verified": p.verified,
            "delivered": p.delivered,
            "retired": p.retired,
            "retiredRound": p.retired_round,
            "missingActionRounds": p.missing_action_rounds,
            "illegalActionCount": p.illegal_action_count,
            "penaltyScore": detail["penalty"],
            "breakOrderReady": False,
            "rushTacticUsedCount": p.rush_tactic_used_count,
            "buffs": self._buffs_public(p),
            "movePerFrame": p.move_per_frame(),
            "currentProcess": p.current_process.public(self.round) if p.current_process else None,
            "resources": {rtype: p.resources.get(rtype, 0) for rtype in RESOURCE_TYPES if p.resources.get(rtype, 0) > 0},
            "totalScore": detail["total"],
            "taskScore": p.task_score_base,
            "bountyScore": p.bounty_score_raw,
            "scoreDetail": detail,
            "roadRounds": p.road_rounds,
            "waterRounds": p.water_rounds,
            "mountainRounds": p.mountain_rounds,
            "branchRounds": p.branch_rounds,
            "routeSwitchCount": p.route_switch_count,
        }

    def _over_player_public(self, p: PlayerState) -> dict[str, Any]:
        data = self._player_public(p)
        data.update({
            "deliverRound": p.deliver_round,
            "roadRounds": p.road_rounds,
            "waterRounds": p.water_rounds,
            "mountainRounds": p.mountain_rounds,
            "branchRounds": p.branch_rounds,
            "routeSwitchCount": p.route_switch_count,
            "totalGold": data["totalScore"],
        })
        return data

    def _buffs_public(self, p: PlayerState) -> list[dict[str, Any]]:
        rows = []
        for buff, remain in p.buffs.items():
            rows.append({
                "type": buff,
                "remainingRound": remain,
                "moveMultiplier": 1.0,
                "freshnessMultiplier": 1.25 if buff == "RUSH_SPEED" else 0.2 if buff == "RUSH_PROTECT" else 1.0,
            })
        return rows

    def _node_public(self, nid: str) -> dict[str, Any]:
        ns = self.node_states[nid]
        cfg = deepcopy(ns.config)
        cfg.update({
            "processType": ns.process_type,
            "processRound": ns.process_round,
            "visible": True,
            "guard": ns.guard.public(self.round) if ns.guard and ns.guard.defense > 0 else None,
            "resourceVisible": True,
            "resourceStock": {rtype: ns.resource_stock.get(rtype, 0) for rtype in RESOURCE_TYPES},
            "scouted": [m.public(self.round) for m in ns.scouts
                        if m.remaining_triggers > 0 and self.round <= m.expire_round],
            "effectiveCombatCount": ns.effective_combat_count,
            "guardBlockCount": ns.guard_block_count,
            "keyPassCombatCount": ns.key_pass_combat_count,
            "hasObstacle": ns.has_obstacle(),
            "obstacleType": ns.obstacle_type,
            "obstacleResidue": ns.obstacle_residue.public(self.round) if ns.obstacle_residue and self.round <= ns.obstacle_residue.until_round else None,
            "canWindow": ns.can_window,
        })
        return cfg

    def _contest_public(self, c: Contest) -> dict[str, Any]:
        idx = c.round_index(self.round)
        return {
            "contestId": c.contest_id,
            "contestType": c.contest_type,
            "objectKey": c.object_key,
            "targetNodeId": c.target_node_id,
            "taskId": c.task_id,
            "resourceType": c.resource_type,
            "processType": c.process_type,
            "redPlayerId": c.red_player_id,
            "bluePlayerId": c.blue_player_id,
            "attackerTeamId": c.attacker_team_id,
            "defenderTeamId": c.defender_team_id,
            "initialTimeTaxRound": c.initial_time_tax_round,
            "initialBlockType": c.initial_block_type,
            "initialGuardTaxRound": c.initial_guard_tax_round,
            "initialObstacleTaxRound": c.initial_obstacle_tax_round,
            "roundIndex": idx,
            "totalRounds": 3,
            "deadlineRound": c.created_round + min(3, max(1, idx)),
            "redPoint": c.points["RED"],
            "bluePoint": c.points["BLUE"],
            "status": c.status,
            "suppressUntilRound": c.suppress_until_round,
            "remainRound": max(0, c.suppress_until_round - self.round),
            "breakOrderCostTypes": {},
        }

    def _weather_public(self) -> dict[str, Any]:
        active = []
        forecast = []
        for w in self.weather_events:
            start = w["startRound"]
            end = start + w["durationRound"] - 1
            if start <= self.round <= end:
                row = dict(w)
                row["remainRound"] = end - self.round + 1
                active.append(row)
            elif self.round < start <= self.round + 30:
                forecast.append(dict(w))
        return {"active": active, "forecast": forecast}

    def _record_replay(self) -> None:
        self.replay.append({
            "round": self.round,
            "phase": self.phase,
            "events": deepcopy(self.events),
            "actionResults": deepcopy(self.action_results),
            "players": [self._player_public(p) for p in self.players.values()],
            "tasks": [t.public() for t in self.tasks.values() if t.status in ("ACTIVE", "PROCESSING", "PROTECTED")],
            "weather": self._weather_public(),
        })
