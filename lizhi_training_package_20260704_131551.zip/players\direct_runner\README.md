# direct_runner

A simple two-player compatible Lychee strategy.

Policy:

- Plan shortest route to S14 before verification, then S15.
- Complete mandatory process nodes before leaving.
- Use `VERIFY_GATE` after rush starts, then deliver at S15.
- Play contest cards with guard points first, then fruit, then abstain.

Run through the platform:

```powershell
python .\run_match.py --red .\players\direct_runner --blue .\client --out .\runs\duel_demo
```
