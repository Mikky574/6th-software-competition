@echo off
setlocal

if "%~3"=="" (
  echo Usage: start.bat ^<playerId^> ^<host^> ^<port^> [playerName]
  exit /b 1
)

set PLAYER_ID=%~1
set HOST=%~2
set PORT=%~3
set PLAYER_NAME=%~4
if "%PLAYER_NAME%"=="" set PLAYER_NAME=direct_runner

python "%~dp0main.py" --playerId %PLAYER_ID% --host %HOST% --port %PORT% --playerName "%PLAYER_NAME%"
