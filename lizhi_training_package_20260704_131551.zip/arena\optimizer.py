from __future__ import annotations

import argparse
import concurrent.futures
import json
import random
import statistics
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .server import run_with_clients


PARAM_SPACE: dict[str, tuple[Any, Any, str]] = {
    "fresh_weight": (0.2, 6.0, "float"),
    "obstacle_penalty": (10.0, 60.0, "float"),
    "guard_penalty": (0.0, 60.0, "float"),
    "guard_reroute_margin": (0.0, 60.0, "float"),
    "reroute_slack": (1.0, 2.2, "float"),
    "task_min_score": (15, 30, "int"),
    "task_detour_dist": (0, 240, "int"),
    "task_base_target": (0, 150, "int"),
    "ice_target": (0, 2, "int"),
    "ice_detour_dist": (0, 120, "int"),
    "ice_end_frames": (30, 90, "int"),
    "ice_end_cap": (85.0, 100.0, "float"),
    "ice_use_threshold": (45.0, 100.0, "float"),
    "ice_use_min_gap": (1, 8, "int"),
    "ice_emergency": (35.0, 95.0, "float"),
    "horse_min_frames": (1, 45, "int"),
    "fast_horse_target": (0, 1, "int"),
    "short_horse_target": (0, 1, "int"),
    "permit_target": (0, 2, "int"),
    "protect_freshness_below": (55.0, 100.0, "float"),
    "guard_fruit_budget": (0, 10, "int"),
    "guard_extra_fruit": (0, 2, "int"),
    "window_optional_min_value": (0, 30, "int"),
    "window_task_critical_score": (15, 30, "int"),
    "window_repeat_counter_min_value": (0, 30, "int"),
    "window_repeat_draw_abstain_after": (0, 2, "int"),
    "window_good_reserve": (0, 4, "int"),
    "window_token_reserve": (0, 2, "int"),
    "window_horse_reserve": (0, 2, "int"),
    "window_guard_point_reserve": (0, 3, "int"),
    "squad_min_gap": (8, 36, "int"),
    "squad_scout_reserve": (0, 4, "int"),
    "squad_scout_max_eta": (20, 85, "int"),
    "squad_scout_min_process": (2, 6, "int"),
    "squad_scout_task_min_score": (15, 30, "int"),
}

BOOL_PARAMS = [
    "do_tasks",
    "grab_horses",
    "use_horses",
    "spend_horse_on_t06",
    "claim_intel",
    "ice_end_save",
    "use_protect",
    "use_rush_speed",
    "gate_break_order",
    "window_clinch_abstain",
    "window_repeat_counter",
    "squad_scout_tasks",
    "squad_clear_obstacles",
    "squad_weaken_guards",
]

CHOICE_PARAMS: dict[str, list[Any]] = {
    "preferred_task_route": ["ANY", "ROAD", "WATER", "MOUNTAIN"],
    "window_mode": ["aggressive", "conservative"],
    "combat_mode": ["aggressive", "none"],
    "squad_mode": ["combat", "scout", "none"],
    "rush_tactic_mode": ["auto", "speed", "protect", "break_gate", "save_for_guard"],
}

BASE_PARAMS: dict[str, Any] = {
    "do_tasks": True,
    "task_min_score": 15,
    "task_detour_dist": 220,
    "task_base_target": 130,
    "preferred_task_route": "ANY",
    "grab_horses": True,
    "use_horses": True,
    "fast_horse_target": 1,
    "short_horse_target": 1,
    "horse_min_frames": 8,
    "spend_horse_on_t06": True,
    "ice_target": 2,
    "ice_detour_dist": 90,
    "ice_end_save": False,
    "ice_end_frames": 55,
    "ice_end_cap": 97.0,
    "ice_use_min_gap": 2,
    "permit_target": 1,
    "claim_intel": True,
    "use_protect": False,
    "use_rush_speed": True,
    "rush_tactic_mode": "auto",
    "gate_break_order": True,
    "fresh_weight": 0.6,
    "obstacle_penalty": 35.0,
    "guard_penalty": 12.0,
    "guard_reroute_margin": 24.0,
    "reroute_slack": 2.1,
    "ice_use_threshold": 94.0,
    "ice_emergency": 70.0,
    "protect_freshness_below": 82.0,
    "window_mode": "aggressive",
    "window_clinch_abstain": True,
    "window_repeat_counter": True,
    "window_repeat_counter_min_value": 15,
    "window_repeat_draw_abstain_after": 1,
    "window_optional_min_value": 14,
    "window_task_critical_score": 30,
    "window_good_reserve": 1,
    "window_token_reserve": 1,
    "window_horse_reserve": 1,
    "window_guard_point_reserve": 1,
    "combat_mode": "aggressive",
    "guard_fruit_budget": 6,
    "guard_extra_fruit": 1,
    "squad_mode": "combat",
    "squad_min_gap": 16,
    "squad_scout_reserve": 0,
    "squad_scout_max_eta": 45,
    "squad_scout_min_process": 4,
    "squad_scout_tasks": True,
    "squad_scout_task_min_score": 30,
    "squad_clear_obstacles": True,
    "squad_weaken_guards": True,
}


@dataclass(frozen=True)
class OpponentSpec:
    path: Path
    params_path: Optional[Path] = None
    params: dict[str, Any] = field(default_factory=dict)

    @property
    def label(self) -> str:
        if self.params_path:
            return f"{self.path}@{self.params_path}"
        return str(self.path)

    def env(self) -> Optional[dict[str, str]]:
        if not self.params:
            return None
        return {"LYCHEE_PARAMS_JSON": json.dumps(self.params, ensure_ascii=False, separators=(",", ":"))}


@dataclass
class EvalResult:
    params: dict[str, Any]
    fitness: float
    wins: int
    losses: int
    draws: int
    league_points: int
    score_margins: list[int] = field(default_factory=list)
    details: list[dict[str, Any]] = field(default_factory=list)
    cached_summary: dict[str, Any] = field(default_factory=dict)
    generation: int = -1
    index: int = -1

    def summary(self) -> dict[str, Any]:
        if self.cached_summary and not self.score_margins and not self.details:
            summary = dict(self.cached_summary)
            summary["params"] = self.params
            summary.setdefault("matchCount", self.wins + self.losses + self.draws)
            summary.setdefault("scoredMatches", 0)
            summary.setdefault("deliveredMatches", 0)
            summary.setdefault("candidateId", self.candidate_id)
            summary.setdefault("opponentBreakdown", [])
            return summary
        candidate_scores = [int(d.get("candidateScore", 0) or 0) for d in self.details]
        opponent_scores = [int(d.get("opponentScore", 0) or 0) for d in self.details]
        task_scores = [int(d.get("candidateTaskScore", 0) or 0) for d in self.details]
        task_final_scores = [int((d.get("candidateScoreDetail") or {}).get("tasks", 0) or 0) for d in self.details]
        delivered_matches = sum(1 for d in self.details if d.get("candidateDelivered"))
        high_score_matches = sum(1 for score in candidate_scores if score >= 700)
        strong_score_matches = sum(1 for score in candidate_scores if score >= 650)
        task90_matches = sum(1 for score in task_scores if score >= 90)
        task110_matches = sum(1 for score in task_scores if score >= 110)
        return {
            "candidateId": self.candidate_id,
            "fitness": round(self.fitness, 3),
            "wins": self.wins,
            "losses": self.losses,
            "draws": self.draws,
            "leaguePoints": self.league_points,
            "avgMargin": round(statistics.mean(self.score_margins), 2) if self.score_margins else 0,
            "avgCandidateScore": round(statistics.mean(candidate_scores), 2) if candidate_scores else 0,
            "avgOpponentScore": round(statistics.mean(opponent_scores), 2) if opponent_scores else 0,
            "worstCandidateScore": min(candidate_scores) if candidate_scores else 0,
            "bestCandidateScore": max(candidate_scores) if candidate_scores else 0,
            "matchCount": len(self.details),
            "scoredMatches": sum(1 for score in candidate_scores if score > 0),
            "deliveredMatches": delivered_matches,
            "score650Matches": strong_score_matches,
            "score700Matches": high_score_matches,
            "avgTaskBase": round(statistics.mean(task_scores), 2) if task_scores else 0,
            "avgTaskFinal": round(statistics.mean(task_final_scores), 2) if task_final_scores else 0,
            "task90Matches": task90_matches,
            "task110Matches": task110_matches,
            "opponentBreakdown": self.opponent_breakdown(),
            "params": self.params,
        }

    @property
    def candidate_id(self) -> str:
        if self.generation >= 0 and self.index >= 0:
            return f"G{self.generation + 1}-C{self.index + 1}"
        return "checkpoint"

    def opponent_breakdown(self) -> list[dict[str, Any]]:
        groups: dict[str, list[dict[str, Any]]] = {}
        for detail in self.details:
            groups.setdefault(str(detail.get("opponent", "unknown")), []).append(detail)
        rows: list[dict[str, Any]] = []
        for label, items in sorted(groups.items()):
            scores = [int(item.get("candidateScore", 0) or 0) for item in items]
            opp_scores = [int(item.get("opponentScore", 0) or 0) for item in items]
            task_scores = [int(item.get("candidateTaskScore", 0) or 0) for item in items]
            margins = [score - opp for score, opp in zip(scores, opp_scores)]
            rows.append({
                "opponent": label,
                "matches": len(items),
                "wins": sum(1 for margin in margins if margin > 0),
                "losses": sum(1 for margin in margins if margin < 0),
                "draws": sum(1 for margin in margins if margin == 0),
                "avgCandidateScore": round(statistics.mean(scores), 2) if scores else 0,
                "avgOpponentScore": round(statistics.mean(opp_scores), 2) if opp_scores else 0,
                "score700Matches": sum(1 for score in scores if score >= 700),
                "avgTaskBase": round(statistics.mean(task_scores), 2) if task_scores else 0,
                "task90Matches": sum(1 for score in task_scores if score >= 90),
                "deliveredMatches": sum(1 for item in items if item.get("candidateDelivered")),
            })
        return rows

class BoundaryOptimizer:
    """Elite mutation search over strategy decision boundaries.

    The goal is not mathematical proof of optimal play. It repeatedly evaluates
    threshold sets across seeds and map conditions, keeps elites, then mutates
    their boundaries toward robust league-point performance.
    """

    def __init__(self, candidate_path: Path, opponents: list[OpponentSpec], out_dir: Path,
                 seeds: list[int], obstacles: list[int], population: int,
                 generations: int, timeout_ms: int, rounds: int, rng_seed: int,
                 jobs: int = 1, match_log_every: int = 0, resume: bool = False,
                 seed_block_size: int = 0, seed_window_size: int = 0,
                 anchor_seed_count: int = 0) -> None:
        self.candidate_path = candidate_path
        self.opponents = opponents
        self.out_dir = out_dir
        self.seeds = seeds
        self.obstacles = obstacles
        self.population = population
        self.generations = generations
        self.timeout_ms = timeout_ms
        self.rounds = rounds
        self.jobs = max(1, jobs)
        self.match_log_every = max(0, match_log_every)
        self.resume = resume
        self.seed_block_size = max(0, seed_block_size)
        self.seed_window_size = max(0, seed_window_size)
        self.anchor_seed_count = max(0, anchor_seed_count)
        self.rng = random.Random(rng_seed)
        self.history: list[dict[str, Any]] = []
        self._print_lock = threading.Lock()

    def run(self) -> EvalResult:
        self.out_dir.mkdir(parents=True, exist_ok=True)
        first_seeds = self.active_seeds_for_generation(0)
        matches_per_candidate = len(self.opponents) * len(first_seeds) * len(self.obstacles) * 2
        self._log(
            "[train] "
            f"population={self.population} generations={self.generations} "
            f"matches/candidate={matches_per_candidate} totalMatches={matches_per_candidate * self.population * self.generations} "
            f"jobs={self.jobs} matchLogEvery={self.match_log_every} resume={self.resume}"
        )
        if self.seed_window_size and self.seed_window_size < len(self.seeds):
            self._log(
                "[train] seedSchedule="
                f"anchors={self.seeds[:self.anchor_seed_count]} "
                f"windowSize={self.seed_window_size} blockSize={max(1, self.seed_block_size)} "
                f"seedPool={self.seeds}"
            )
        candidates, best, start_generation = self._initial_state()
        remaining_generations = max(0, self.generations - start_generation)
        start_seeds = self.active_seeds_for_generation(start_generation)
        start_matches_per_candidate = len(self.opponents) * len(start_seeds) * len(self.obstacles) * 2
        self._log(
            "[train] "
            f"startGeneration={start_generation} remainingGenerations={remaining_generations} "
            f"firstGenerationCandidates={len(candidates)} "
            f"remainingMatchesApprox={start_matches_per_candidate * len(candidates) * remaining_generations}"
        )
        if start_generation >= self.generations:
            assert best is not None
            self._log(
                f"[resume] existing history already has {start_generation} generations; "
                f"target generations={self.generations}."
            )
            self.write_progress(best)
            return best
        for gen in range(start_generation, self.generations):
            gen_started = time.time()
            active_seeds = self.active_seeds_for_generation(gen)
            self._log(
                f"[gen {gen + 1}/{self.generations}] evaluating {len(candidates)} candidates "
                f"seeds={','.join(str(seed) for seed in active_seeds)}"
            )
            if self.jobs <= 1:
                evaluated = []
                for idx, params in enumerate(candidates):
                    result = self.evaluate(params, gen, idx, len(candidates), active_seeds)
                    evaluated.append(result)
                    self.print_candidate_summary(gen, idx, len(candidates), len(evaluated), result, gen_started)
            else:
                evaluated = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=self.jobs) as executor:
                    futures = {
                        executor.submit(self.evaluate, params, gen, idx, len(candidates), active_seeds): idx
                        for idx, params in enumerate(candidates)
                    }
                    for future in concurrent.futures.as_completed(futures):
                        idx = futures[future]
                        result = future.result()
                        evaluated.append(result)
                        self.print_candidate_summary(gen, idx, len(candidates), len(evaluated), result, gen_started)
            evaluated.sort(key=lambda r: r.fitness, reverse=True)
            if best is None or evaluated[0].fitness > best.fitness:
                best = evaluated[0]
            self.history.append({
                "generation": gen,
                "activeSeeds": active_seeds,
                "best": evaluated[0].summary(),
                "population": [r.summary() for r in evaluated],
            })
            self.write_progress(best)
            self.print_generation_summary(gen, evaluated[0], best)
            elites = evaluated[:max(2, min(4, len(evaluated)))]
            next_candidates: list[dict[str, Any]] = []
            for elite in elites:
                self._append_unique(next_candidates, elite.params)
            hall_of_fame_added = False
            if best is not None:
                hall_of_fame_added = self._append_unique(next_candidates, best.params)
            parent_pool = list(elites)
            if best is not None and all(json.dumps(best.params, sort_keys=True, ensure_ascii=False) != json.dumps(elite.params, sort_keys=True, ensure_ascii=False) for elite in elites):
                parent_pool.append(best)
            self.print_survival_summary(gen, evaluated, elites, best, hall_of_fame_added)
            while len(next_candidates) < self.population:
                parent = self.rng.choice(parent_pool).params
                next_candidates.append(self.mutate(parent, strength=max(0.08, 0.35 * (0.82 ** gen))))
            candidates = next_candidates
        assert best is not None
        self.write_progress(best)
        return best

    def active_seeds_for_generation(self, generation: int) -> list[int]:
        if not self.seeds:
            return [1]
        if self.seed_window_size <= 0 or self.seed_window_size >= len(self.seeds):
            return list(self.seeds)

        window_size = max(1, self.seed_window_size)
        anchor_count = min(max(0, self.anchor_seed_count), window_size, len(self.seeds))
        anchors = list(self.seeds[:anchor_count])
        rotating = list(self.seeds[anchor_count:])
        fill = window_size - len(anchors)
        if fill <= 0 or not rotating:
            return anchors or list(self.seeds[:window_size])

        block_size = max(1, self.seed_block_size)
        block_index = max(0, generation) // block_size
        start = (block_index * fill) % len(rotating)
        selected = [rotating[(start + offset) % len(rotating)] for offset in range(fill)]
        return anchors + selected

    def _initial_state(self) -> tuple[list[dict[str, Any]], Optional[EvalResult], int]:
        if not self.resume:
            return self._fresh_population(), None, 0

        history_path = self.out_dir / "history.json"
        if history_path.exists():
            try:
                raw_history = json.loads(history_path.read_text(encoding="utf-8"))
                if isinstance(raw_history, list):
                    self.history = raw_history
            except (OSError, json.JSONDecodeError):
                self.history = []

        if not self.history:
            best_path = self.out_dir / "best_params.json"
            if best_path.exists():
                try:
                    params = json.loads(best_path.read_text(encoding="utf-8"))
                    if isinstance(params, dict):
                        self._log(f"[resume] seeding from {best_path}, no usable history.json found.")
                        candidates = self._seed_population_from_params(params)
                        return candidates, None, 0
                except (OSError, json.JSONDecodeError):
                    pass
            self._log("[resume] no usable checkpoint found; starting fresh.")
            return self._fresh_population(), None, 0

        start_generation = len(self.history)
        best_summary: Optional[dict[str, Any]] = None
        for item in self.history:
            summary = item.get("best") if isinstance(item, dict) else None
            if not isinstance(summary, dict):
                continue
            if best_summary is None or float(summary.get("fitness", float("-inf")) or float("-inf")) > float(best_summary.get("fitness", float("-inf")) or float("-inf")):
                best_summary = summary

        best = self._result_from_summary(best_summary) if best_summary else None
        last_population = []
        last = self.history[-1] if self.history else {}
        if isinstance(last, dict):
            for item in last.get("population", []) or []:
                if isinstance(item, dict) and isinstance(item.get("params"), dict):
                    last_population.append(dict(item["params"]))

        if not last_population and best is not None:
            last_population = [dict(best.params)]

        candidates: list[dict[str, Any]] = []
        for params in last_population:
            if self._append_unique(candidates, params) and len(candidates) >= self.population:
                break
        while len(candidates) < self.population:
            parent = self.rng.choice(candidates).copy() if candidates else dict(BASE_PARAMS)
            candidates.append(self.mutate(parent, strength=0.12))
        self._log(f"[resume] loaded {start_generation} completed generations from {history_path}.")
        return candidates, best, start_generation

    def _fresh_population(self) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        preset_count = 0
        for params in self._preset_params():
            if self._append_unique(candidates, params):
                preset_count += 1
            if len(candidates) >= self.population:
                break
        while len(candidates) < self.population:
            if candidates and self.rng.random() < 0.7:
                parent = self.rng.choice(candidates)
                self._append_unique(candidates, self.mutate(parent, strength=0.22))
            else:
                self._append_unique(candidates, self.random_params())
        self._log(
            f"[train] initialSeedPresets={min(preset_count, self.population)} "
            f"exploreCandidates={max(0, len(candidates) - preset_count)}"
        )
        return candidates[:self.population]

    def _preset_params(self) -> list[dict[str, Any]]:
        presets = [dict(BASE_PARAMS)]
        roots = [Path.cwd(), self.candidate_path.parent]
        for rel in (
            Path("configs") / "score_attack_params.json",
            Path("configs") / "full_rules_params.json",
            Path("configs") / "horse_params.json",
        ):
            for root in roots:
                path = root / rel
                if not path.exists():
                    continue
                try:
                    raw = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    raw = None
                if isinstance(raw, dict):
                    merged = dict(BASE_PARAMS)
                    merged.update(raw)
                    presets.append(merged)
                break
        gate_break = dict(BASE_PARAMS)
        gate_break.update({
            "rush_tactic_mode": "break_gate",
            "gate_break_order": True,
            "use_rush_speed": False,
            "use_protect": False,
        })
        presets.append(gate_break)
        save_for_guard = dict(BASE_PARAMS)
        save_for_guard.update({
            "rush_tactic_mode": "save_for_guard",
            "gate_break_order": False,
        })
        presets.append(save_for_guard)
        return presets

    def _append_unique(self, candidates: list[dict[str, Any]], params: dict[str, Any]) -> bool:
        merged = dict(BASE_PARAMS)
        merged.update(params)
        key = json.dumps(merged, sort_keys=True, ensure_ascii=False)
        for existing in candidates:
            if json.dumps(existing, sort_keys=True, ensure_ascii=False) == key:
                return False
        candidates.append(merged)
        return True

    def _seed_population_from_params(self, params: dict[str, Any]) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        self._append_unique(candidates, params)
        while len(candidates) < self.population:
            parent = self.rng.choice(candidates) if candidates else dict(BASE_PARAMS)
            self._append_unique(candidates, self.mutate(parent, strength=0.16))
        return candidates

    @staticmethod
    def _result_from_summary(summary: Optional[dict[str, Any]]) -> Optional[EvalResult]:
        if not summary:
            return None
        params = dict(BASE_PARAMS)
        params.update(summary.get("params") or {})
        return EvalResult(
            params=params,
            fitness=float(summary.get("fitness", 0.0) or 0.0),
            wins=int(summary.get("wins", 0) or 0),
            losses=int(summary.get("losses", 0) or 0),
            draws=int(summary.get("draws", 0) or 0),
            league_points=int(summary.get("leaguePoints", 0) or 0),
            cached_summary=dict(summary),
        )

    def print_generation_summary(self, generation: int, current_best: EvalResult, global_best: EvalResult) -> None:
        now = current_best.summary()
        best = global_best.summary()
        params = now["params"]
        self._log(
            "[gen "
            f"{generation + 1}/{self.generations}] "
            f"fitness={now['fitness']} globalBest={best['fitness']} "
            f"W/L/D={now['wins']}/{now['losses']}/{now['draws']} "
            f"league={now['leaguePoints']} "
            f"avgScore={now['avgCandidateScore']} oppAvg={now['avgOpponentScore']} "
            f"avgMargin={now['avgMargin']} worstScore={now['worstCandidateScore']} "
            f"scored={now.get('scoredMatches', 0)}/{now.get('matchCount', 0)} "
            f"delivered={now.get('deliveredMatches', 0)}/{now.get('matchCount', 0)} "
            f"score700={now.get('score700Matches', 0)}/{now.get('matchCount', 0)} "
            f"task90={now.get('task90Matches', 0)}/{now.get('matchCount', 0)} "
            f"avgTask={now.get('avgTaskBase', 0)}"
        )
        self._log(
            "  params "
            f"taskTarget={params.get('task_base_target')} "
            f"taskDetour={params.get('task_detour_dist')} "
            f"freshW={params.get('fresh_weight')} route={params.get('preferred_task_route')} "
            f"ice={params.get('ice_target')}/{params.get('ice_use_threshold')} "
            f"iceEnd={params.get('ice_end_save')}/{params.get('ice_end_frames')} "
            f"guardPenalty={params.get('guard_penalty')} "
            f"guardMargin={params.get('guard_reroute_margin')} "
            f"rush={params.get('rush_tactic_mode')}/gateBreak={params.get('gate_break_order')} "
            f"squad={params.get('squad_mode')}/{params.get('squad_min_gap')}/{params.get('squad_scout_max_eta')} "
            f"windowMin={params.get('window_optional_min_value')} "
            "reserve="
            f"G{params.get('window_good_reserve')}/"
            f"T{params.get('window_token_reserve')}/"
            f"H{params.get('window_horse_reserve')}/"
            f"B{params.get('window_guard_point_reserve')}"
        )

    def print_candidate_summary(self, generation: int, index: int, total: int,
                                completed: int, result: EvalResult, started: float) -> None:
        summary = result.summary()
        elapsed = time.time() - started
        rate = completed / elapsed if elapsed > 0 else 0.0
        remaining = (total - completed) / rate if rate > 0 else 0.0
        self._log(
            f"[gen {generation + 1}/{self.generations}] "
            f"candidate {completed}/{total} done (#{index + 1}) "
            f"fitness={summary['fitness']} W/L/D={summary['wins']}/{summary['losses']}/{summary['draws']} "
            f"avgScore={summary['avgCandidateScore']} avgMargin={summary['avgMargin']} "
            f"scored={summary.get('scoredMatches', 0)}/{summary.get('matchCount', 0)} "
            f"delivered={summary.get('deliveredMatches', 0)}/{summary.get('matchCount', 0)} "
            f"score700={summary.get('score700Matches', 0)}/{summary.get('matchCount', 0)} "
            f"task90={summary.get('task90Matches', 0)}/{summary.get('matchCount', 0)} "
            f"etaGen={remaining:.0f}s"
        )

    def print_survival_summary(self, generation: int, evaluated: list[EvalResult],
                               elites: list[EvalResult], global_best: Optional[EvalResult],
                               hall_of_fame_added: bool) -> None:
        elite_keys = {self._params_key(result.params) for result in elites}
        global_key = self._params_key(global_best.params) if global_best is not None else ""
        self._log(f"[gen {generation + 1}/{self.generations}] ranking summary:")
        for rank, result in enumerate(evaluated[:min(4, len(evaluated))], start=1):
            summary = result.summary()
            key = self._params_key(result.params)
            tags = []
            if key in elite_keys:
                tags.append("survive")
            if global_key and key == global_key:
                tags.append("globalBest")
            tag_text = f" [{' '.join(tags)}]" if tags else ""
            self._log(
                f"  #{rank} {summary.get('candidateId')}{tag_text} "
                f"fitness={summary['fitness']} W/L/D={summary['wins']}/{summary['losses']}/{summary['draws']} "
                f"league={summary['leaguePoints']} avg={summary['avgCandidateScore']} "
                f"best={summary['bestCandidateScore']} worst={summary['worstCandidateScore']} "
                f"700+={summary.get('score700Matches', 0)}/{summary.get('matchCount', 0)} "
                f"task90={summary.get('task90Matches', 0)}/{summary.get('matchCount', 0)} "
                f"avgTask={summary.get('avgTaskBase', 0)} "
                f"delivered={summary.get('deliveredMatches', 0)}/{summary.get('matchCount', 0)}"
            )
            if rank <= 2:
                self._log("     vs " + self._format_opponent_breakdown(summary.get("opponentBreakdown", [])))
        elite_text = ", ".join(result.summary().get("candidateId", "?") for result in elites)
        self._log(f"[gen {generation + 1}/{self.generations}] survivors copied to next gen: {elite_text}")
        if global_best is not None:
            hof_status = "copied as extra survivor" if hall_of_fame_added else "already among survivors"
            best_summary = global_best.summary()
            self._log(
                f"[gen {generation + 1}/{self.generations}] hallOfFame {best_summary.get('candidateId')} "
                f"{hof_status}; historical W/L/D={best_summary.get('wins')}/{best_summary.get('losses')}/{best_summary.get('draws')} "
                f"avg={best_summary.get('avgCandidateScore')} "
                f"700+={best_summary.get('score700Matches', 0)}/{best_summary.get('matchCount', 0)} "
                f"task90={best_summary.get('task90Matches', 0)}/{best_summary.get('matchCount', 0)}"
            )
        eliminated = [result.summary().get("candidateId", "?") for result in evaluated if self._params_key(result.params) not in elite_keys and (not global_key or self._params_key(result.params) != global_key)]
        if eliminated:
            self._log(f"[gen {generation + 1}/{self.generations}] eliminated: {', '.join(eliminated[:8])}")

    def _format_opponent_breakdown(self, rows: list[dict[str, Any]], limit: int = 4) -> str:
        if not rows:
            return "no opponent breakdown"
        parts = []
        for row in rows[:limit]:
            parts.append(
                f"{self._short_label(str(row.get('opponent', 'unknown')))} "
                f"{row.get('wins', 0)}/{row.get('losses', 0)}/{row.get('draws', 0)} "
                f"avg={row.get('avgCandidateScore', 0)} "
                f"task90={row.get('task90Matches', 0)}/{row.get('matches', 0)}"
            )
        if len(rows) > limit:
            parts.append(f"+{len(rows) - limit} more")
        return "; ".join(parts)

    @staticmethod
    def _short_label(label: str) -> str:
        if "@" in label:
            path, params = label.rsplit("@", 1)
            return f"{Path(path).name}@{Path(params).stem}"
        return Path(label).name or label

    @staticmethod
    def _params_key(params: dict[str, Any]) -> str:
        return json.dumps(params, sort_keys=True, ensure_ascii=False)

    def _log(self, message: str) -> None:
        with self._print_lock:
            print(message, flush=True)

    def random_params(self) -> dict[str, Any]:
        params = dict(BASE_PARAMS)
        for key, (lo, hi, kind) in PARAM_SPACE.items():
            if kind == "int":
                params[key] = self.rng.randint(int(lo), int(hi))
            else:
                params[key] = round(self.rng.uniform(float(lo), float(hi)), 3)
        for key in BOOL_PARAMS:
            params[key] = self.rng.random() < 0.65
        for key, choices in CHOICE_PARAMS.items():
            params[key] = self.rng.choice(choices)
        if not params.get("grab_horses"):
            params["fast_horse_target"] = 0
            params["short_horse_target"] = 0
        if not params.get("use_horses"):
            params["horse_min_frames"] = 999
        return params

    def mutate(self, parent: dict[str, Any], strength: float) -> dict[str, Any]:
        params = dict(parent)
        for key, (lo, hi, kind) in PARAM_SPACE.items():
            if self.rng.random() > 0.55:
                continue
            span = float(hi) - float(lo)
            value = float(params.get(key, lo))
            value += self.rng.gauss(0, span * strength)
            value = max(float(lo), min(float(hi), value))
            params[key] = int(round(value)) if kind == "int" else round(value, 3)
        for key in BOOL_PARAMS:
            if self.rng.random() < 0.12:
                params[key] = not bool(params.get(key, False))
        for key, choices in CHOICE_PARAMS.items():
            if self.rng.random() < 0.22:
                params[key] = self.rng.choice(choices)
        if not params.get("grab_horses"):
            params["fast_horse_target"] = 0
            params["short_horse_target"] = 0
        return params

    def evaluate(self, params: dict[str, Any], generation: int, index: int,
                 candidate_total: Optional[int] = None,
                 active_seeds: Optional[list[int]] = None) -> EvalResult:
        wins = losses = draws = league_points = 0
        margins: list[int] = []
        details: list[dict[str, Any]] = []
        env = {"LYCHEE_PARAMS_JSON": json.dumps(params, ensure_ascii=False, separators=(",", ":"))}
        seeds = active_seeds or self.seeds
        match_total = len(self.opponents) * len(seeds) * len(self.obstacles) * 2
        match_done = 0
        started = time.time()
        display_total = candidate_total or self.population
        for opponent_spec in self.opponents:
            for seed in seeds:
                for obstacle_count in self.obstacles:
                    for side in ("RED", "BLUE"):
                        result = self._run_one(env, opponent_spec, seed, obstacle_count, side, generation, index)
                        candidate, opponent_player = self._candidate_and_opponent(result, side)
                        c_score = int(candidate.get("totalScore", 0))
                        o_score = int(opponent_player.get("totalScore", 0))
                        margin = c_score - o_score
                        margins.append(margin)
                        points = int((result.get("leaguePoints") or {}).get(str(candidate.get("playerId")), 0) or 0)
                        league_points += points
                        if margin > 0:
                            wins += 1
                        elif margin < 0:
                            losses += 1
                            outcome = "L"
                        else:
                            draws += 1
                            outcome = "D"
                        if margin > 0:
                            outcome = "W"
                        details.append({
                            "opponent": opponent_spec.label,
                            "seed": seed,
                            "obstacleCount": obstacle_count,
                            "side": side,
                            "outcome": outcome,
                            "candidateScore": c_score,
                            "opponentScore": o_score,
                            "candidateTaskScore": int(candidate.get("taskScore", 0) or 0),
                            "opponentTaskScore": int(opponent_player.get("taskScore", 0) or 0),
                            "candidateScoreDetail": candidate.get("scoreDetail", {}) or {},
                            "opponentScoreDetail": opponent_player.get("scoreDetail", {}) or {},
                            "candidateDelivered": bool(candidate.get("delivered")),
                            "opponentDelivered": bool(opponent_player.get("delivered")),
                            "points": points,
                        })
                        match_done += 1
                        if self.match_log_every and (match_done % self.match_log_every == 0 or match_done == match_total):
                            avg_score = statistics.mean(int(d["candidateScore"]) for d in details)
                            avg_margin = statistics.mean(margins) if margins else 0.0
                            recent = details[-self.match_log_every:] if self.match_log_every else details
                            recent_scores = [int(d["candidateScore"]) for d in recent]
                            recent_avg = statistics.mean(recent_scores) if recent_scores else 0.0
                            scored = sum(1 for d in details if int(d["candidateScore"]) > 0)
                            score700 = sum(1 for d in details if int(d["candidateScore"]) >= 700)
                            task90 = sum(1 for d in details if int(d.get("candidateTaskScore", 0) or 0) >= 90)
                            recent_scored = sum(1 for score in recent_scores if score > 0)
                            recent_700 = sum(1 for score in recent_scores if score >= 700)
                            recent_task90 = sum(1 for d in recent if int(d.get("candidateTaskScore", 0) or 0) >= 90)
                            self._log(
                                f"[gen {generation + 1}/{self.generations} cand {index + 1}/{display_total}] "
                                f"match {match_done}/{match_total} W/L/D={wins}/{losses}/{draws} "
                                f"avgScore={avg_score:.1f} avgMargin={avg_margin:.1f} "
                                f"scored={scored}/{match_done} recentScore={recent_avg:.1f} "
                                f"recentScored={recent_scored}/{len(recent)} "
                                f"score700={score700}/{match_done} recent700={recent_700}/{len(recent)} "
                                f"task90={task90}/{match_done} recentTask90={recent_task90}/{len(recent)} "
                                f"last={outcome} {c_score}:{o_score} "
                                f"task={int(candidate.get('taskScore', 0) or 0)} "
                                f"vs={self._short_label(opponent_spec.label)} seed={seed} obs={obstacle_count} side={side} "
                                f"elapsed={time.time() - started:.0f}s"
                            )
        candidate_scores = [int(d["candidateScore"]) for d in details]
        task_scores = [int(d.get("candidateTaskScore", 0) or 0) for d in details]
        scored_count = sum(1 for score in candidate_scores if score > 0)
        delivered_count = sum(1 for d in details if d.get("candidateDelivered"))
        avg_candidate = statistics.mean(candidate_scores) if candidate_scores else 0.0
        worst_score = min(candidate_scores) if candidate_scores else 0
        score_sum = sum(candidate_scores)
        high_score_bonus = sum(max(0, score - 600) * 4 + max(0, score - 700) * 10 for score in candidate_scores)
        low_score_penalty = sum(max(0, 520 - score) * 2.5 + max(0, 650 - score) * 0.8 for score in candidate_scores)
        task_stability_bonus = (
            sum(min(score, 120) * 4 for score in task_scores)
            + sum(650 for score in task_scores if score >= 90)
            + sum(900 for score in task_scores if score >= 110)
        )
        low_task_penalty = 0.0
        for d in details:
            task_score = int(d.get("candidateTaskScore", 0) or 0)
            if d.get("candidateDelivered"):
                low_task_penalty += max(0, 90 - task_score) * 10
            else:
                low_task_penalty += max(0, 60 - task_score) * 4
        detail_bonus = 0.0
        for d in details:
            parts = d.get("candidateScoreDetail") or {}
            detail_bonus += float(parts.get("tasks", 0) or 0) * 0.8
            detail_bonus += float(parts.get("freshness", 0) or 0) * 0.5
            detail_bonus += float(parts.get("time", 0) or 0) * 0.7
        score_quality = score_sum * 2.0 + worst_score * 12.0 + high_score_bonus + detail_bonus + scored_count * 70 + delivered_count * 120
        zero_score_penalty = (match_total - scored_count) * 80 + (match_total - delivered_count) * 40
        delivered_bonus = sum(30 for d in details if d["candidateScore"] > 0)
        worst_margin = min(margins) if margins else 0
        fitness = (
            league_points * 1000
            + sum(margins)
            + worst_margin * 0.5
            + delivered_bonus
            + score_quality
            + task_stability_bonus
            - zero_score_penalty
            - low_score_penalty
            - low_task_penalty
            - losses * 500
            - draws * 80
        )
        return EvalResult(
            params=params,
            fitness=fitness,
            wins=wins,
            losses=losses,
            draws=draws,
            league_points=league_points,
            score_margins=margins,
            details=details,
            generation=generation,
            index=index,
        )

    def _run_one(self, env: dict[str, str], opponent: OpponentSpec, seed: int, obstacle_count: int,
                 side: str, generation: int, index: int) -> dict[str, Any]:
        try:
            if side == "RED":
                return run_with_clients(
                    self.candidate_path, opponent.path, port=0, seed=seed,
                    duration_round=self.rounds, action_timeout=self.timeout_ms / 1000.0,
                    obstacle_count=obstacle_count, red_env=env, blue_env=opponent.env(), quiet=True,
                )
            return run_with_clients(
                opponent.path, self.candidate_path, port=0, seed=seed,
                duration_round=self.rounds, action_timeout=self.timeout_ms / 1000.0,
                obstacle_count=obstacle_count, red_env=opponent.env(), blue_env=env, quiet=True,
            )
        except Exception as exc:
            return {
                "winnerPlayerId": None,
                "leaguePoints": {},
                "players": [
                    {"playerId": 1001, "teamId": "RED", "totalScore": 0, "error": f"{opponent.label}: {exc}"},
                    {"playerId": 1002, "teamId": "BLUE", "totalScore": 9999, "error": f"{opponent.label}: {exc}"},
                ],
            }

    @staticmethod
    def _candidate_and_opponent(result: dict[str, Any], side: str) -> tuple[dict[str, Any], dict[str, Any]]:
        players = result.get("players", []) or []
        candidate_team = side
        candidate = next((p for p in players if p.get("teamId") == candidate_team), players[0])
        opponent = next((p for p in players if p.get("teamId") != candidate_team), players[-1])
        return candidate, opponent

    def write_progress(self, best: EvalResult) -> None:
        (self.out_dir / "best_params.json").write_text(
            json.dumps(best.params, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (self.out_dir / "history.json").write_text(
            json.dumps(self.history, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def parse_int_list(raw: str) -> list[int]:
    return [int(part.strip()) for part in raw.split(",") if part.strip()]


def load_params_file(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"opponent params must be a JSON object: {path}")
    return data


def parse_opponent_spec(raw: str) -> OpponentSpec:
    raw = raw.strip()
    if not raw:
        raise ValueError("empty opponent spec")
    if "@" not in raw:
        return OpponentSpec(Path(raw))
    path_raw, params_raw = raw.rsplit("@", 1)
    path = Path(path_raw.strip())
    params_path = Path(params_raw.strip())
    return OpponentSpec(path=path, params_path=params_path, params=load_params_file(params_path))


def parse_opponent_list(raw: str) -> list[OpponentSpec]:
    return [parse_opponent_spec(part) for part in raw.split(",") if part.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Optimize Lychee strategy decision boundaries.")
    parser.add_argument("--candidate", type=Path, default=Path("client"))
    parser.add_argument("--opponent", type=Path, default=Path("players") / "direct_runner")
    parser.add_argument("--opponents", default="",
                        help="comma-separated opponents; each item may be PATH or PATH@params.json")
    parser.add_argument("--out", type=Path, default=Path("runs") / "optimizer")
    parser.add_argument("--seeds", default="1,2,3")
    parser.add_argument("--obstacles", default="0,1")
    parser.add_argument("--population", type=int, default=8)
    parser.add_argument("--generations", type=int, default=4)
    parser.add_argument("--timeout-ms", type=int, default=80)
    parser.add_argument("--rounds", type=int, default=600)
    parser.add_argument("--rng-seed", type=int, default=20260704)
    parser.add_argument("--jobs", type=int, default=1, help="parallel candidate evaluations")
    parser.add_argument("--match-log-every", type=int, default=0,
                        help="print per-candidate progress every N evaluated matches; 0 disables")
    parser.add_argument("--seed-window-size", type=int, default=0,
                        help="evaluate only this many seeds per generation; 0 means use all seeds")
    parser.add_argument("--seed-block-size", type=int, default=0,
                        help="keep the same rotating seed window for this many generations")
    parser.add_argument("--anchor-seed-count", type=int, default=0,
                        help="always include this many leading seeds in every seed window")
    parser.add_argument("--resume", action="store_true",
                        help="resume from out/history.json and continue until --generations total generations")
    args = parser.parse_args()
    started = time.time()
    opt = BoundaryOptimizer(
        candidate_path=args.candidate,
        opponents=parse_opponent_list(args.opponents) if args.opponents.strip() else [OpponentSpec(args.opponent)],
        out_dir=args.out,
        seeds=parse_int_list(args.seeds),
        obstacles=parse_int_list(args.obstacles),
        population=args.population,
        generations=args.generations,
        timeout_ms=args.timeout_ms,
        rounds=args.rounds,
        rng_seed=args.rng_seed,
        jobs=args.jobs,
        match_log_every=args.match_log_every,
        resume=args.resume,
        seed_block_size=args.seed_block_size,
        seed_window_size=args.seed_window_size,
        anchor_seed_count=args.anchor_seed_count,
    )
    best = opt.run()
    print(json.dumps({
        "elapsedSec": round(time.time() - started, 2),
        "opponents": [opponent.label for opponent in opt.opponents],
        "jobs": opt.jobs,
        "matchLogEvery": opt.match_log_every,
        "resume": opt.resume,
        "seedSchedule": {
            "seedPool": opt.seeds,
            "windowSize": opt.seed_window_size,
            "blockSize": opt.seed_block_size,
            "anchorSeedCount": opt.anchor_seed_count,
        },
        "best": best.summary(),
        "bestParamsFile": str(args.out / "best_params.json"),
        "historyFile": str(args.out / "history.json"),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
