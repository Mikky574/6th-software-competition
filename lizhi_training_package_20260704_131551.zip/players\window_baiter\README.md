Window baiter training opponent.

This wrapper runs direct_runner with WINDOW_BAITER=1. It chases active tasks
and valuable resources, especially when they are near the opponent, to create
more WINDOW_CARD contests for policy training.
