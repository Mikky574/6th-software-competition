#!/bin/bash
set -e

if [ "$#" -lt 3 ]; then
  echo "Usage: $0 <playerId> <host> <port>"
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$HERE/main.py" --playerId "$1" --host "$2" --port "$3" --playerName "direct_runner"
