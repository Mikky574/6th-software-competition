from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLIENT_DIR = ROOT / "client"
if str(CLIENT_DIR) not in sys.path:
    sys.path.insert(0, str(CLIENT_DIR))

from core import Agent, World  # noqa: E402


class ClientWindowStrategyTests(unittest.TestCase):
    def make_world(self, contest: dict, tasks: list[dict] | None = None) -> World:
        w = World()
        w.round = 10
        w.my_id = 1001
        w.my_team = "RED"
        w.opp_id = 1002
        w.opp_team = "BLUE"
        w.me = {
            "playerId": 1001,
            "teamId": "RED",
            "currentNodeId": "S01",
            "goodFruit": 1,
            "badFruit": 0,
            "freshness": 90,
            "guardActionPoint": 1,
            "resources": {"PASS_TOKEN": 1, "FAST_HORSE": 1},
            "buffs": [],
        }
        w.opp = {"playerId": 1002, "teamId": "BLUE", "guardActionPoint": 0}
        base = {
            "contestId": "C1",
            "status": "ACTIVE",
            "redPlayerId": 1001,
            "bluePlayerId": 1002,
            "redPoint": 0,
            "bluePoint": 0,
            "roundIndex": 1,
        }
        base.update(contest)
        w.contests = [base]
        w.tasks = tasks or []
        return w

    def test_third_card_abstains_after_window_is_won(self) -> None:
        w = self.make_world({
            "contestType": "TASK",
            "taskId": "T_HIGH",
            "redPoint": 2,
            "bluePoint": 0,
            "roundIndex": 3,
        }, [{"taskId": "T_HIGH", "taskTemplateId": "T01", "score": 30}])
        action = Agent(w, {"window_mode": "aggressive"}).decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "ABSTAIN"})

    def test_third_card_abstains_after_window_is_lost(self) -> None:
        w = self.make_world({
            "contestType": "TASK",
            "taskId": "T_HIGH",
            "redPoint": 0,
            "bluePoint": 2,
            "roundIndex": 3,
        }, [{"taskId": "T_HIGH", "taskTemplateId": "T01", "score": 30}])
        action = Agent(w, {"window_mode": "aggressive"}).decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "ABSTAIN"})

    def test_low_value_resource_window_abstains_even_when_aggressive(self) -> None:
        w = self.make_world({
            "contestType": "RESOURCE",
            "resourceType": "INTEL",
        })
        action = Agent(w, {
            "window_mode": "aggressive",
            "window_optional_min_value": 14,
        }).decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "ABSTAIN"})

    def test_high_value_task_can_spend_reserved_good_fruit(self) -> None:
        w = self.make_world({
            "contestType": "TASK",
            "taskId": "T_HIGH",
        }, [{"taskId": "T_HIGH", "taskTemplateId": "T01", "score": 30}])
        w.me["guardActionPoint"] = 0
        action = Agent(w, {
            "window_mode": "aggressive",
            "window_good_reserve": 1,
        }).decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "XIAN_GONG"})

    def test_repeated_opponent_card_is_countered_when_valuable(self) -> None:
        w = self.make_world({
            "contestType": "TASK",
            "taskId": "T_HIGH",
            "roundIndex": 2,
        }, [{"taskId": "T_HIGH", "taskTemplateId": "T01", "score": 30}])
        w.events = [{
            "type": "WINDOW_CARD_REVEAL",
            "payload": {
                "contestId": "C1",
                "roundIndex": 1,
                "redCard": "BING_ZHENG",
                "blueCard": "BING_ZHENG",
                "winner": None,
            },
        }]
        agent = Agent(w, {"window_mode": "aggressive"})
        agent._absorb_events()
        action = agent.decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "XIAN_GONG"})

    def test_low_value_repeat_draw_abstains_to_save_resources(self) -> None:
        w = self.make_world({
            "contestType": "RESOURCE",
            "resourceType": "INTEL",
            "roundIndex": 2,
        })
        w.me["freshness"] = 70
        w.events = [{
            "type": "WINDOW_CARD_REVEAL",
            "payload": {
                "contestId": "C1",
                "roundIndex": 1,
                "redCard": "BING_ZHENG",
                "blueCard": "BING_ZHENG",
                "winner": None,
            },
        }]
        agent = Agent(w, {
            "window_mode": "aggressive",
            "window_optional_min_value": 0,
            "window_repeat_draw_abstain_after": 1,
        })
        agent._absorb_events()
        action = agent.decide_window()
        self.assertEqual(action, {"action": "WINDOW_CARD", "contestId": "C1", "card": "ABSTAIN"})


if __name__ == "__main__":
    unittest.main()
