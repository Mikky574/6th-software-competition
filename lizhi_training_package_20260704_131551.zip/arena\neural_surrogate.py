from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .optimizer import BASE_PARAMS, BOOL_PARAMS, CHOICE_PARAMS, PARAM_SPACE


FEATURE_KEYS = (
    list(PARAM_SPACE)
    + BOOL_PARAMS
    + [f"{key}={choice}" for key, choices in CHOICE_PARAMS.items() for choice in choices]
)


@dataclass
class Sample:
    params: dict[str, Any]
    x: list[float]
    y: float


class TinyMLP:
    """Small standard-library MLP for ranking parameter boundaries.

    This is a surrogate model: it does not replace the referee. It learns from
    real adversarial evaluations, proposes likely-good parameter sets, and those
    candidates should be validated by `arena.optimizer` or `run_match.py`.
    """

    def __init__(self, inputs: int, hidden: int, rng: random.Random) -> None:
        scale = 1.0 / math.sqrt(max(1, inputs))
        self.w1 = [[rng.uniform(-scale, scale) for _ in range(inputs)] for _ in range(hidden)]
        self.b1 = [0.0 for _ in range(hidden)]
        self.w2 = [rng.uniform(-scale, scale) for _ in range(hidden)]
        self.b2 = 0.0

    def predict(self, x: list[float]) -> float:
        hidden = [math.tanh(dot(row, x) + bias) for row, bias in zip(self.w1, self.b1)]
        return dot(self.w2, hidden) + self.b2

    def train_epoch(self, samples: list[Sample], lr: float, rng: random.Random) -> float:
        shuffled = list(samples)
        rng.shuffle(shuffled)
        total = 0.0
        for sample in shuffled:
            x = sample.x
            h_pre = [dot(row, x) + bias for row, bias in zip(self.w1, self.b1)]
            h = [math.tanh(v) for v in h_pre]
            pred = dot(self.w2, h) + self.b2
            err = pred - sample.y
            total += err * err
            grad_out = 2.0 * err
            old_w2 = list(self.w2)
            for j in range(len(self.w2)):
                self.w2[j] -= lr * grad_out * h[j]
            self.b2 -= lr * grad_out
            for j, old_w in enumerate(old_w2):
                grad_hidden = grad_out * old_w * (1.0 - h[j] * h[j])
                for i in range(len(x)):
                    self.w1[j][i] -= lr * grad_hidden * x[i]
                self.b1[j] -= lr * grad_hidden
        return total / max(1, len(samples))

    def to_json(self) -> dict[str, Any]:
        return {
            "featureKeys": FEATURE_KEYS,
            "w1": self.w1,
            "b1": self.b1,
            "w2": self.w2,
            "b2": self.b2,
        }


def dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def feature_vector(params: dict[str, Any]) -> list[float]:
    merged = dict(BASE_PARAMS)
    merged.update(params)
    values: list[float] = []
    for key in PARAM_SPACE:
        lo, hi, _kind = PARAM_SPACE[key]
        raw = float(merged.get(key, lo) or 0.0)
        span = float(hi) - float(lo)
        values.append(0.0 if span <= 0 else (raw - float(lo)) / span)
    for key in BOOL_PARAMS:
        values.append(1.0 if bool(merged.get(key, False)) else 0.0)
    for key, choices in CHOICE_PARAMS.items():
        selected = str(merged.get(key, choices[0]))
        for choice in choices:
            values.append(1.0 if selected == str(choice) else 0.0)
    return [max(0.0, min(1.0, value)) for value in values]


def load_samples(history_path: Path) -> tuple[list[Sample], dict[str, float]]:
    history = json.loads(history_path.read_text(encoding="utf-8"))
    rows: list[tuple[dict[str, Any], float]] = []
    seen: set[str] = set()
    for generation in history:
        for item in generation.get("population", []) or []:
            params = item.get("params") or {}
            key = json.dumps(params, sort_keys=True, ensure_ascii=False)
            if key in seen:
                continue
            seen.add(key)
            rows.append((params, float(item.get("fitness", 0.0) or 0.0)))
    if not rows:
        raise ValueError(f"{history_path} does not contain optimizer population samples")
    mean = sum(y for _params, y in rows) / len(rows)
    variance = sum((y - mean) ** 2 for _params, y in rows) / max(1, len(rows))
    std = math.sqrt(variance) or 1.0
    samples = [Sample(params, feature_vector(params), (y - mean) / std) for params, y in rows]
    return samples, {"mean": mean, "std": std}


def random_params(rng: random.Random) -> dict[str, Any]:
    params = dict(BASE_PARAMS)
    for key, (lo, hi, kind) in PARAM_SPACE.items():
        if kind == "int":
            params[key] = rng.randint(int(lo), int(hi))
        else:
            params[key] = round(rng.uniform(float(lo), float(hi)), 3)
    for key in BOOL_PARAMS:
        params[key] = rng.random() < 0.65
    for key, choices in CHOICE_PARAMS.items():
        params[key] = rng.choice(choices)
    normalize_params(params)
    return params


def mutate_params(parent: dict[str, Any], rng: random.Random, strength: float = 0.18) -> dict[str, Any]:
    params = dict(BASE_PARAMS)
    params.update(parent)
    for key, (lo, hi, kind) in PARAM_SPACE.items():
        if rng.random() > 0.7:
            continue
        span = float(hi) - float(lo)
        value = float(params.get(key, lo) or lo) + rng.gauss(0.0, span * strength)
        value = max(float(lo), min(float(hi), value))
        params[key] = int(round(value)) if kind == "int" else round(value, 3)
    for key in BOOL_PARAMS:
        if rng.random() < 0.08:
            params[key] = not bool(params.get(key, False))
    for key, choices in CHOICE_PARAMS.items():
        if rng.random() < 0.18:
            params[key] = rng.choice(choices)
    normalize_params(params)
    return params


def normalize_params(params: dict[str, Any]) -> None:
    if not params.get("grab_horses"):
        params["fast_horse_target"] = 0
        params["short_horse_target"] = 0
    if not params.get("use_horses"):
        params["horse_min_frames"] = 999


def propose_candidates(model: TinyMLP, samples: list[Sample], target_stats: dict[str, float],
                       count: int, pool: int, rng: random.Random) -> list[dict[str, Any]]:
    parents = sorted(samples, key=lambda s: s.y, reverse=True)[:max(2, min(8, len(samples)))]
    proposals: list[tuple[float, dict[str, Any]]] = []
    seen: set[str] = set()
    for i in range(pool):
        if i < len(parents):
            params = dict(parents[i].params)
        elif rng.random() < 0.7:
            params = mutate_params(rng.choice(parents).params, rng)
        else:
            params = random_params(rng)
        key = json.dumps(params, sort_keys=True, ensure_ascii=False)
        if key in seen:
            continue
        seen.add(key)
        pred = model.predict(feature_vector(params)) * target_stats["std"] + target_stats["mean"]
        proposals.append((pred, params))
    proposals.sort(key=lambda item: item[0], reverse=True)
    return [
        {"rank": idx + 1, "predictedFitness": round(pred, 3), "params": params}
        for idx, (pred, params) in enumerate(proposals[:count])
    ]


def train(history_path: Path, out_dir: Path, hidden: int, epochs: int, lr: float,
          candidate_count: int, pool: int, rng_seed: int) -> dict[str, Any]:
    rng = random.Random(rng_seed)
    samples, target_stats = load_samples(history_path)
    model = TinyMLP(inputs=len(FEATURE_KEYS), hidden=hidden, rng=rng)
    losses: list[float] = []
    for epoch in range(epochs):
        decay = 0.985 ** epoch
        losses.append(model.train_epoch(samples, lr * decay, rng))
    candidates = propose_candidates(model, samples, target_stats, candidate_count, pool, rng)
    out_dir.mkdir(parents=True, exist_ok=True)
    model_payload = model.to_json()
    model_payload["targetMean"] = target_stats["mean"]
    model_payload["targetStd"] = target_stats["std"]
    model_payload["loss"] = losses[-20:]
    (out_dir / "model.json").write_text(json.dumps(model_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "neural_candidates.json").write_text(
        json.dumps(candidates, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if candidates:
        (out_dir / "best_predicted_params.json").write_text(
            json.dumps(candidates[0]["params"], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return {
        "samples": len(samples),
        "finalLoss": round(losses[-1], 6) if losses else 0,
        "modelFile": str(out_dir / "model.json"),
        "candidatesFile": str(out_dir / "neural_candidates.json"),
        "bestPredictedParamsFile": str(out_dir / "best_predicted_params.json"),
        "bestPredicted": candidates[0] if candidates else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Train a neural surrogate over optimizer history.")
    parser.add_argument("--history", type=Path, default=Path("runs") / "optimizer" / "history.json")
    parser.add_argument("--out", type=Path, default=Path("runs") / "neural_surrogate")
    parser.add_argument("--hidden", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=350)
    parser.add_argument("--lr", type=float, default=0.035)
    parser.add_argument("--candidates", type=int, default=12)
    parser.add_argument("--pool", type=int, default=300)
    parser.add_argument("--rng-seed", type=int, default=20260704)
    args = parser.parse_args()
    result = train(
        history_path=args.history,
        out_dir=args.out,
        hidden=args.hidden,
        epochs=args.epochs,
        lr=args.lr,
        candidate_count=args.candidates,
        pool=args.pool,
        rng_seed=args.rng_seed,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
