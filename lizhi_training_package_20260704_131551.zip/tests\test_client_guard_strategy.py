from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLIENT_DIR = ROOT / "client"
if str(CLIENT_DIR) not in sys.path:
    sys.path.insert(0, str(CLIENT_DIR))

from core import Agent, World  # noqa: E402


class ClientGuardStrategyTests(unittest.TestCase):
    def make_world(self, resources: dict[str, int] | None = None) -> World:
        w = World()
        w.round = 1
        w.my_id = 1001
        w.my_team = "RED"
        w.opp_id = 1002
        w.opp_team = "BLUE"
        w.gate_node = "D"
        w.terminal_nodes = ["D"]
        w.nodes = {
            nid: {"nodeId": nid, "nodeType": "NORMAL", "processType": "", "processRound": 0}
            for nid in ("A", "B", "C", "D")
        }
        w.node_state = {nid: dict(node) for nid, node in w.nodes.items()}
        w.node_state["B"]["guard"] = {"ownerTeamId": "BLUE", "defense": 6}
        w.adj = {
            "A": [
                {"to": "B", "routeType": "ROAD", "distance": 100, "edgeId": "AB"},
                {"to": "C", "routeType": "ROAD", "distance": 1, "edgeId": "AC"},
            ],
            "B": [
                {"to": "A", "routeType": "ROAD", "distance": 100, "edgeId": "AB"},
                {"to": "D", "routeType": "ROAD", "distance": 100, "edgeId": "BD"},
            ],
            "C": [
                {"to": "A", "routeType": "ROAD", "distance": 1, "edgeId": "AC"},
                {"to": "D", "routeType": "ROAD", "distance": 1, "edgeId": "CD"},
            ],
            "D": [
                {"to": "B", "routeType": "ROAD", "distance": 100, "edgeId": "BD"},
                {"to": "C", "routeType": "ROAD", "distance": 1, "edgeId": "CD"},
            ],
        }
        w.me = {
            "playerId": 1001,
            "teamId": "RED",
            "currentNodeId": "A",
            "goodFruit": 0,
            "badFruit": 0,
            "freshness": 90,
            "guardActionPoint": 0,
            "resources": resources or {},
            "buffs": [],
        }
        w.opp = {"playerId": 1002, "teamId": "BLUE", "guardActionPoint": 0, "resources": {}}
        return w

    def test_pass_token_prefers_forced_pass_over_large_detour(self) -> None:
        agent = Agent(self.make_world({"PASS_TOKEN": 1}), {
            "guard_reroute_margin": 24,
            "guard_penalty": 12,
        })
        action = agent._handle_guard("A", "B", "D")
        self.assertEqual(action, {"action": "FORCED_PASS", "targetNodeId": "B"})

    def test_guard_detour_only_when_clearly_cheaper_without_token(self) -> None:
        agent = Agent(self.make_world(), {
            "guard_reroute_margin": 24,
            "guard_penalty": 12,
        })
        action = agent._handle_guard("A", "B", "D")
        self.assertEqual(action, {"action": "MOVE", "targetNodeId": "C"})

    def test_pass_window_uses_xian_gong_against_bing_zheng_threat(self) -> None:
        w = self.make_world({"PASS_TOKEN": 1})
        w.me["goodFruit"] = 1
        w.opp["guardActionPoint"] = 1
        agent = Agent(w)
        card = agent._best_card({"contestType": "PASS", "attackerTeamId": "RED"})
        self.assertEqual(card, "XIAN_GONG")

    def test_pass_window_uses_token_when_no_bing_zheng_threat(self) -> None:
        w = self.make_world({"PASS_TOKEN": 1})
        w.me["goodFruit"] = 1
        agent = Agent(w)
        card = agent._best_card({"contestType": "PASS", "attackerTeamId": "RED"})
        self.assertEqual(card, "YAN_DIE")


if __name__ == "__main__":
    unittest.main()
