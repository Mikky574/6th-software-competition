#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 3 ]; then
  echo "Usage: start.sh <playerId> <host> <port> [playerName]" >&2
  exit 1
fi

export WINDOW_BAITER=1
PLAYER_NAME="${4:-window_baiter}"
python "$(dirname "$0")/../direct_runner/main.py" --playerId "$1" --host "$2" --port "$3" --playerName "$PLAYER_NAME"
