from __future__ import annotations

import json
import os
import selectors
import socket
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .engine import GameEngine
from .protocol import FrameBuffer, ProtocolError, error_message, read_frame, write_frame


@dataclass
class ClientSpec:
    player_id: Any
    name: str
    path: Optional[Path] = None
    command: Optional[list[str]] = None
    env: Optional[dict[str, str]] = None


class ClientConn:
    def __init__(self, sock: socket.socket, addr: Any) -> None:
        self.sock = sock
        self.addr = addr
        self.buffer = FrameBuffer()
        self.player_id: Any = None
        self.name: str = ""
        self.version: str = ""
        self.ready = False
        self.closed = False
        self.seen_rounds: set[int] = set()

    def close(self) -> None:
        self.closed = True
        try:
            self.sock.close()
        except OSError:
            pass


class MatchServer:
    def __init__(self, host: str = "127.0.0.1", port: int = 30000,
                 red_id: Any = 1001, blue_id: Any = 1002,
                 red_name: str = "RED", blue_name: str = "BLUE",
                 seed: int = 1, duration_round: int = 600,
                 action_timeout: float = 0.5, connect_timeout: float = 20.0,
                 obstacle_count: int = 0) -> None:
        self.host = host
        self.port = port
        self.action_timeout = action_timeout
        self.connect_timeout = connect_timeout
        self.engine = GameEngine(red_id, blue_id, red_name, blue_name, seed, duration_round, obstacle_count)
        self.listener: Optional[socket.socket] = None
        self.clients: dict[Any, ClientConn] = {}
        self.selector = selectors.DefaultSelector()

    def listen(self) -> int:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((self.host, self.port))
        sock.listen()
        sock.setblocking(False)
        self.listener = sock
        self.port = int(sock.getsockname()[1])
        self.selector.register(sock, selectors.EVENT_READ, self._accept)
        return self.port

    def close(self) -> None:
        for conn in list(self.clients.values()):
            conn.close()
        if self.listener:
            try:
                self.selector.unregister(self.listener)
            except Exception:
                pass
            try:
                self.listener.close()
            except OSError:
                pass
        try:
            self.selector.close()
        except Exception:
            pass

    def run(self) -> dict[str, Any]:
        if not self.listener:
            self.listen()
        try:
            self._wait_for_registrations()
            self._send_start_and_wait_ready()
            self._send_all(self.engine.inquire_message())
            while True:
                actions = self._collect_actions()
                self.engine.run_round(actions)
                over, reason = self.engine.is_over()
                if over:
                    msg = self.engine.over_message(reason)
                    self._send_all(msg)
                    return msg["msg_data"]
                self._send_all(self.engine.inquire_message())
        finally:
            self.close()

    def _accept(self, sock: socket.socket) -> None:
        conn_sock, addr = sock.accept()
        conn_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        conn_sock.setblocking(False)
        conn = ClientConn(conn_sock, addr)
        self.selector.register(conn_sock, selectors.EVENT_READ, conn)

    def _wait_for_registrations(self) -> None:
        deadline = time.monotonic() + self.connect_timeout
        expected = set(self.engine.players.keys())
        while time.monotonic() < deadline and set(self.clients.keys()) != expected:
            self._pump(0.2, registration_phase=True)
        missing = expected - set(self.clients.keys())
        for pid in missing:
            self.engine.players[pid].abnormal = True
            self.engine.players[pid].online = False

    def _send_start_and_wait_ready(self) -> None:
        start = self.engine.start_message()
        self._send_all(start)
        deadline = time.monotonic() + self.connect_timeout
        while time.monotonic() < deadline:
            if all(conn.ready for conn in self.clients.values()):
                return
            self._pump(0.2, registration_phase=False)

    def _collect_actions(self) -> dict[Any, Optional[list[dict[str, Any]]]]:
        for conn in self.clients.values():
            conn.seen_rounds.discard(self.engine.round)
        actions: dict[Any, Optional[list[dict[str, Any]]]] = {pid: None for pid in self.engine.players}
        deadline = time.monotonic() + self.action_timeout
        while time.monotonic() < deadline:
            self._pump(max(0.0, min(0.05, deadline - time.monotonic())), registration_phase=False,
                       action_bucket=actions)
            if all(actions.get(pid) is not None or pid not in self.clients for pid in self.engine.players):
                break
        return actions

    def _pump(self, timeout: float, registration_phase: bool,
              action_bucket: Optional[dict[Any, Optional[list[dict[str, Any]]]]] = None) -> None:
        for key, _ in self.selector.select(timeout):
            data = key.data
            if callable(data):
                data(key.fileobj)
                continue
            conn: ClientConn = data
            try:
                chunk = conn.sock.recv(65536)
                if not chunk:
                    self._mark_closed(conn)
                    continue
                frames = conn.buffer.feed(chunk)
            except ProtocolError as exc:
                self._send_error(conn, 0, exc.code, exc.message)
                continue
            except OSError:
                self._mark_closed(conn)
                continue
            for msg in frames:
                self._handle_message(conn, msg, registration_phase, action_bucket)

    def _handle_message(self, conn: ClientConn, msg: dict[str, Any], registration_phase: bool,
                        action_bucket: Optional[dict[Any, Optional[list[dict[str, Any]]]]]) -> None:
        name = msg.get("msg_name")
        data = msg.get("msg_data") or {}
        if name == "registration":
            pid = data.get("playerId")
            matched = self._match_player_id(pid)
            if matched is None:
                self._send_error(conn, 0, "PLAYER_ADDRESS_MISMATCH", "unexpected playerId")
                return
            conn.player_id = matched
            conn.name = str(data.get("playerName", ""))
            conn.version = str(data.get("version", ""))
            self.clients[matched] = conn
            self.engine.register_player(matched, conn.name)
            return
        if conn.player_id is None:
            self._send_error(conn, int(data.get("round", 0) or 0), "ACTION_REJECTED", "not registered")
            return
        if name == "ready":
            if data.get("matchId") != self.engine.match_id:
                self._send_error(conn, int(data.get("round", 0) or 0), "MATCH_ID_MISMATCH", "bad matchId")
                return
            conn.ready = True
            return
        if name == "action":
            if action_bucket is None:
                return
            round_no = int(data.get("round", 0) or 0)
            if data.get("matchId") != self.engine.match_id:
                self._send_error(conn, round_no, "MATCH_ID_MISMATCH", "bad matchId")
                return
            if round_no != self.engine.round:
                self._send_error(conn, round_no, "ROUND_MISMATCH", f"expected {self.engine.round}")
                return
            if round_no in conn.seen_rounds:
                self._send_error(conn, round_no, "DUPLICATE_ACTION", "duplicate action for round")
                return
            if self._match_player_id(data.get("playerId")) != conn.player_id:
                self._send_error(conn, round_no, "PLAYER_ADDRESS_MISMATCH", "playerId mismatch")
                return
            actions = data.get("actions")
            if not isinstance(actions, list):
                self._send_error(conn, round_no, "INVALID_ACTION_FORMAT", "actions must be a list")
                return
            conn.seen_rounds.add(round_no)
            action_bucket[conn.player_id] = actions
            return
        self._send_error(conn, int(data.get("round", 0) or 0), "ACTION_REJECTED", f"unknown msg_name {name}")

    def _match_player_id(self, raw: Any) -> Any:
        for pid in self.engine.players:
            if str(pid) == str(raw):
                return pid
        return None

    def _send_all(self, msg: dict[str, Any]) -> None:
        for pid, conn in list(self.clients.items()):
            if conn.closed:
                continue
            try:
                write_frame(conn.sock, msg)
            except OSError:
                self._mark_closed(conn)

    def _send_error(self, conn: ClientConn, round_no: int, code: str, message: str) -> None:
        try:
            write_frame(conn.sock, error_message(round_no, conn.player_id, code, message))
        except OSError:
            self._mark_closed(conn)

    def _mark_closed(self, conn: ClientConn) -> None:
        if conn.closed:
            return
        pid = conn.player_id
        conn.close()
        try:
            self.selector.unregister(conn.sock)
        except Exception:
            pass
        if pid in self.engine.players:
            self.engine.set_online(pid, False)


def launch_client(spec: ClientSpec, host: str, port: int, extra_env: Optional[dict[str, str]] = None,
                  quiet: bool = False) -> subprocess.Popen:
    if spec.command:
        cmd = [part.format(playerId=spec.player_id, host=host, port=port, playerName=spec.name)
               for part in spec.command]
        cwd = None
    elif spec.path:
        path = spec.path.resolve()
        if os.name == "nt":
            script = path / "start.bat"
            cmd = [str(script), str(spec.player_id), host, str(port), spec.name]
        else:
            script = path / "start.sh"
            cmd = [str(script), str(spec.player_id), host, str(port)]
        cwd = str(path)
    else:
        raise ValueError("client spec needs path or command")
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    if spec.env:
        env.update(spec.env)
    stdout = subprocess.DEVNULL if quiet else None
    stderr = subprocess.DEVNULL if quiet else None
    return subprocess.Popen(cmd, cwd=cwd, env=env, stdout=stdout, stderr=stderr)


def run_with_clients(red_path: Path, blue_path: Path, host: str = "127.0.0.1", port: int = 30000,
                     red_id: Any = 1001, blue_id: Any = 1002, seed: int = 1,
                     duration_round: int = 600, action_timeout: float = 0.5,
                     obstacle_count: int = 0, output_dir: Optional[Path] = None,
                     red_env: Optional[dict[str, str]] = None,
                     blue_env: Optional[dict[str, str]] = None,
                     quiet: bool = False) -> dict[str, Any]:
    server = MatchServer(host, port, red_id, blue_id, "RED", "BLUE", seed, duration_round,
                         action_timeout, obstacle_count=obstacle_count)
    actual_port = server.listen()
    procs: list[subprocess.Popen] = []
    try:
        procs.append(launch_client(ClientSpec(red_id, "RED", red_path, env=red_env), host, actual_port, quiet=quiet))
        procs.append(launch_client(ClientSpec(blue_id, "BLUE", blue_path, env=blue_env), host, actual_port, quiet=quiet))
        result = server.run()
        if output_dir:
            output_dir.mkdir(parents=True, exist_ok=True)
            (output_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            (output_dir / "replay.jsonl").write_text(
                "\n".join(json.dumps(row, ensure_ascii=False) for row in server.engine.replay),
                encoding="utf-8",
            )
        return result
    finally:
        for proc in procs:
            if proc.poll() is None:
                proc.terminate()
        deadline = time.monotonic() + 2
        for proc in procs:
            if proc.poll() is None:
                try:
                    proc.wait(max(0.1, deadline - time.monotonic()))
                except subprocess.TimeoutExpired:
                    proc.kill()
