# guard_trapper

Adversarial guard opponent for training.

It reuses `direct_runner` with `GUARD_TRAPPER=1` and intentionally places
guards on chokepoints such as `S10`, `S11`, and `S13`, then reinforces friendly
guards with squads when possible.
