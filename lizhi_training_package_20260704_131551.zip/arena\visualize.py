from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .default_map import build_default_map


def write_viewer(run_dir: Path) -> Path:
    result_path = run_dir / "result.json"
    replay_path = run_dir / "replay.jsonl"
    if not result_path.exists() or not replay_path.exists():
        raise FileNotFoundError("run directory must contain result.json and replay.jsonl")
    result = json.loads(result_path.read_text(encoding="utf-8"))
    replay = [json.loads(line) for line in replay_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    payload = {
        "map": build_default_map(),
        "result": result,
        "replay": replay,
    }
    html = HTML_TEMPLATE.replace("__PAYLOAD__", json.dumps(payload, ensure_ascii=False))
    out = run_dir / "viewer.html"
    out.write_text(html, encoding="utf-8")
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a replay viewer for a match output directory.")
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    out = write_viewer(args.run_dir)
    print(out)
    return 0


HTML_TEMPLATE = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lychee Arena Replay</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #101214;
      --panel: #191d20;
      --panel-2: #22282c;
      --line: #3c464d;
      --text: #eef2f3;
      --muted: #aab4b9;
      --red: #e55050;
      --blue: #4e8cff;
      --road: #c6a56d;
      --water: #3f9fc4;
      --mountain: #6eb071;
      --branch: #b47bc3;
      --good: #8fcf67;
      --warn: #e0b84f;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      background: var(--bg);
      color: var(--text);
      font-family: Inter, "Segoe UI", Arial, sans-serif;
      letter-spacing: 0;
    }
    .app {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 360px;
      grid-template-rows: 64px minmax(0, 1fr);
      height: 100vh;
    }
    header {
      grid-column: 1 / 3;
      display: grid;
      grid-template-columns: minmax(220px, 1fr) auto;
      align-items: center;
      gap: 16px;
      padding: 10px 16px;
      border-bottom: 1px solid var(--line);
      background: #15191c;
    }
    h1 {
      margin: 0;
      font-size: 18px;
      font-weight: 700;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .controls {
      display: grid;
      grid-template-columns: repeat(5, 38px) minmax(220px, 40vw) 80px;
      align-items: center;
      gap: 8px;
    }
    button {
      width: 38px;
      height: 38px;
      border: 1px solid var(--line);
      background: var(--panel-2);
      color: var(--text);
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }
    button:hover { border-color: var(--muted); }
    input[type="range"] { width: 100%; accent-color: var(--good); }
    .round {
      text-align: right;
      font-variant-numeric: tabular-nums;
      color: var(--muted);
      font-size: 13px;
    }
    main {
      min-width: 0;
      min-height: 0;
      display: grid;
      grid-template-rows: minmax(0, 1fr) auto;
    }
    .map-shell {
      min-height: 0;
      padding: 16px;
    }
    svg {
      width: 100%;
      height: 100%;
      min-height: 360px;
      background: #14181a;
      border: 1px solid var(--line);
      border-radius: 8px;
    }
    .edge { fill: none; stroke-width: 0.9; opacity: 0.9; }
    .node { fill: #242b2f; stroke: #d6dcde; stroke-width: 0.35; }
    .node.process { fill: #2e352c; }
    .node.finish { fill: #384042; }
    .node-label { fill: var(--text); font-size: 2.2px; paint-order: stroke; stroke: #101214; stroke-width: 0.55; }
    .piece { stroke: #fff; stroke-width: 0.55; }
    .piece-label { fill: #fff; font-size: 2.1px; font-weight: 700; text-anchor: middle; dominant-baseline: central; }
    .timeline {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
      padding: 0 16px 16px;
    }
    .team {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
      padding: 12px;
      min-width: 0;
    }
    .team-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 8px;
    }
    .team-name { font-size: 14px; font-weight: 700; }
    .score { font-size: 24px; font-weight: 800; font-variant-numeric: tabular-nums; }
    .stats {
      display: grid;
      grid-template-columns: repeat(6, minmax(0, 1fr));
      gap: 8px;
      color: var(--muted);
      font-size: 12px;
      font-variant-numeric: tabular-nums;
    }
    .stats b { display: block; color: var(--text); font-size: 13px; overflow-wrap: anywhere; }
    .stats.compact {
      grid-template-columns: repeat(8, minmax(0, 1fr));
      margin-top: 8px;
    }
    .stats.routes {
      grid-template-columns: repeat(4, minmax(0, 1fr));
      margin-top: 8px;
    }
    .stats.routes span {
      border-top: 2px solid var(--line);
      padding-top: 5px;
    }
    .stats.routes span:nth-child(1) { border-color: var(--road); }
    .stats.routes span:nth-child(2) { border-color: var(--water); }
    .stats.routes span:nth-child(3) { border-color: var(--mountain); }
    .stats.routes span:nth-child(4) { border-color: var(--branch); }
    aside {
      min-height: 0;
      display: grid;
      grid-template-rows: auto auto minmax(0, 1fr);
      gap: 12px;
      padding: 16px 16px 16px 0;
    }
    .result, .tasks, .events {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
      padding: 12px;
    }
    .result h2, .tasks h2, .events h2 {
      margin: 0 0 10px;
      font-size: 14px;
    }
    .result-grid {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 8px;
      font-size: 13px;
      color: var(--muted);
    }
    .result-grid b { color: var(--text); }
    .events {
      overflow: auto;
      min-height: 0;
    }
    .task-list {
      display: grid;
      gap: 7px;
      max-height: 190px;
      overflow: auto;
    }
    .task-row {
      display: grid;
      grid-template-columns: 72px 1fr auto;
      gap: 8px;
      align-items: center;
      font-size: 12px;
      color: var(--muted);
      border-top: 1px solid #2c3439;
      padding-top: 7px;
    }
    .task-row:first-child { border-top: 0; padding-top: 0; }
    .task-row b { color: var(--text); }
    .tier-high { color: var(--warn); }
    .event {
      display: grid;
      gap: 3px;
      padding: 8px 0;
      border-top: 1px solid #2c3439;
      font-size: 12px;
      color: var(--muted);
    }
    .event:first-of-type { border-top: 0; }
    .event b { color: var(--text); font-size: 12px; }
    .red { color: var(--red); }
    .blue { color: var(--blue); }
    @media (max-width: 980px) {
      .app { grid-template-columns: 1fr; grid-template-rows: auto auto auto; height: auto; min-height: 100vh; }
      header { grid-column: 1; grid-template-columns: 1fr; }
      .controls { grid-template-columns: repeat(5, 38px) minmax(160px, 1fr) 70px; }
      main { min-height: 680px; }
      aside { padding: 0 16px 16px; }
      .timeline { grid-template-columns: 1fr; }
      .stats.compact { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    }
  </style>
</head>
<body>
  <div class="app">
    <header>
      <h1 id="title">一骑红尘：荔枝争运战</h1>
      <div class="controls">
        <button id="first" title="第一帧">|&lt;</button>
        <button id="prev" title="上一帧">&lt;</button>
        <button id="play" title="播放">▶</button>
        <button id="next" title="下一帧">&gt;</button>
        <button id="last" title="最后一帧">&gt;|</button>
        <input id="slider" type="range" min="0" max="0" value="0">
        <div class="round" id="round">0 / 0</div>
      </div>
    </header>
    <main>
      <section class="map-shell">
        <svg id="map" viewBox="0 0 80 60" role="img" aria-label="match map"></svg>
      </section>
      <section class="timeline" id="teams"></section>
    </main>
    <aside>
      <section class="result">
        <h2>Result</h2>
        <div class="result-grid" id="result"></div>
      </section>
      <section class="tasks">
        <h2>Active Tasks</h2>
        <div class="task-list" id="tasks"></div>
      </section>
      <section class="events">
        <h2>Events</h2>
        <div id="events"></div>
      </section>
    </aside>
  </div>
  <script>
    const DATA = __PAYLOAD__;
    const replay = DATA.replay;
    const nodes = new Map(DATA.map.nodes.map(n => [n.nodeId, n]));
    const edges = DATA.map.edges;
    const map = document.getElementById("map");
    const slider = document.getElementById("slider");
    const play = document.getElementById("play");
    let index = 0;
    let timer = null;

    slider.max = Math.max(0, replay.length - 1);
    drawMap();
    renderResult();
    render(0);

    document.getElementById("first").onclick = () => render(0);
    document.getElementById("prev").onclick = () => render(index - 1);
    document.getElementById("next").onclick = () => render(index + 1);
    document.getElementById("last").onclick = () => render(replay.length - 1);
    slider.oninput = () => render(Number(slider.value));
    play.onclick = () => {
      if (timer) {
        clearInterval(timer);
        timer = null;
        play.textContent = "▶";
        return;
      }
      play.textContent = "Ⅱ";
      timer = setInterval(() => {
        if (index >= replay.length - 1) {
          clearInterval(timer);
          timer = null;
          play.textContent = "▶";
        } else {
          render(index + 1);
        }
      }, 140);
    };

    function drawMap() {
      map.innerHTML = "";
      for (const e of edges) {
        const a = nodes.get(e.fromNodeId);
        const b = nodes.get(e.toNodeId);
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", a.x);
        line.setAttribute("y1", a.y);
        line.setAttribute("x2", b.x);
        line.setAttribute("y2", b.y);
        line.setAttribute("class", "edge");
        line.setAttribute("stroke", routeColor(e.routeType));
        map.appendChild(line);
      }
      for (const n of DATA.map.nodes) {
        const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        c.setAttribute("cx", n.x);
        c.setAttribute("cy", n.y);
        c.setAttribute("r", n.terminal || n.nodeId === "S14" ? 1.35 : 1.05);
        c.setAttribute("class", `node ${n.processType ? "process" : ""} ${n.terminal ? "finish" : ""}`);
        map.appendChild(c);
        const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
        label.setAttribute("x", n.x + 1.35);
        label.setAttribute("y", n.y - 1.1);
        label.setAttribute("class", "node-label");
        label.textContent = n.nodeId;
        map.appendChild(label);
      }
    }

    function render(i) {
      index = Math.max(0, Math.min(replay.length - 1, i));
      slider.value = index;
      const frame = replay[index];
      document.getElementById("round").textContent = `${frame.round} / ${replay[replay.length - 1].round}`;
      drawMap();
      drawPieces(frame.players || []);
      renderTeams(frame.players || []);
      renderTasks(frame.tasks || []);
      renderEvents(frame.events || []);
    }

    function drawPieces(players) {
      for (const p of players) {
        const pos = playerPosition(p);
        const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
        const offset = p.teamId === "RED" ? -0.85 : 0.85;
        const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        c.setAttribute("cx", pos.x);
        c.setAttribute("cy", pos.y + offset);
        c.setAttribute("r", 1.45);
        c.setAttribute("fill", p.teamId === "RED" ? "var(--red)" : "var(--blue)");
        c.setAttribute("class", "piece");
        const t = document.createElementNS("http://www.w3.org/2000/svg", "text");
        t.setAttribute("x", pos.x);
        t.setAttribute("y", pos.y + offset);
        t.setAttribute("class", "piece-label");
        t.textContent = p.teamId === "RED" ? "R" : "B";
        g.appendChild(c);
        g.appendChild(t);
        map.appendChild(g);
      }
    }

    function playerPosition(p) {
      const a = nodes.get(p.currentNodeId) || nodes.get("S01");
      if (!p.nextNodeId) return { x: a.x, y: a.y };
      const b = nodes.get(p.nextNodeId);
      if (!b) return { x: a.x, y: a.y };
      const progress = Math.max(0, Math.min(1, p.moveProgress || 0));
      return { x: a.x + (b.x - a.x) * progress, y: a.y + (b.y - a.y) * progress };
    }

    function renderTeams(players) {
      document.getElementById("teams").innerHTML = players.map(p => `
        <article class="team">
          <div class="team-head">
            <div class="team-name ${p.teamId === "RED" ? "red" : "blue"}">${p.teamId} · ${escapeHtml(p.playerName || "")}</div>
            <div class="score">${p.totalScore ?? 0}</div>
          </div>
          <div class="stats">
            <span><b>${escapeHtml(p.state || "")}</b>State</span>
            <span><b>${escapeHtml(p.currentNodeId || "")}</b>Node</span>
            <span><b>${Math.round((p.freshness || 0) * 10) / 10}</b>Fresh</span>
            <span><b>${p.goodFruit ?? 0}</b>Good</span>
            <span><b>${p.taskScore ?? 0}</b>Tasks</span>
            <span><b>${p.movePerFrame ?? 1000}</b>Speed</span>
          </div>
          <div class="stats compact">
            ${scoreDetailHtml(p.scoreDetail || {})}
          </div>
          <div class="stats routes">
            <span><b>${p.roadRounds ?? 0}</b>Road</span>
            <span><b>${p.waterRounds ?? 0}</b>Water</span>
            <span><b>${p.mountainRounds ?? 0}</b>Mountain</span>
            <span><b>${p.branchRounds ?? 0}</b>Branch</span>
          </div>
          <div class="stats" style="grid-template-columns: repeat(2, minmax(0, 1fr)); margin-top: 8px;">
            <span><b>${escapeHtml(formatBuffs(p.buffs || []))}</b>Buffs</span>
            <span><b>${escapeHtml(formatResources(p.resources || {}))}</b>Resources</span>
          </div>
        </article>
      `).join("");
    }

    function scoreDetailHtml(sd) {
      const keys = [
        ["delivery", "Delivery"],
        ["goodFruit", "Good"],
        ["freshness", "FreshScore"],
        ["time", "Time"],
        ["tasks", "TaskScore"],
        ["bounty", "Bounty"],
        ["penalty", "Penalty"],
        ["total", "Total"],
      ];
      return keys.map(([key, label]) => `<span><b>${sd[key] ?? 0}</b>${label}</span>`).join("");
    }

    function renderResult() {
      const r = DATA.result;
      const winner = r.winnerPlayerId == null ? "DRAW" : r.winnerPlayerId;
      document.getElementById("result").innerHTML = `
        <span>Winner</span><b>${winner}</b>
        <span>Reason</span><b>${escapeHtml(r.overReason || "")}</b>
        <span>Round</span><b>${r.overRound}</b>
        <span>League</span><b>${escapeHtml(JSON.stringify(r.leaguePoints || {}))}</b>
      `;
    }

    function renderTasks(tasks) {
      const active = tasks.slice(0, 12);
      document.getElementById("tasks").innerHTML = active.length ? active.map(t => {
        const tier = String(t.scoreTier || "").toUpperCase();
        const buckets = (t.routeBuckets && t.routeBuckets.length ? t.routeBuckets : [t.routeBucket || "ANY"]).join("/");
        return `
          <div class="task-row">
            <b>${escapeHtml(t.taskTemplateId || "")}</b>
            <span>
              ${escapeHtml(t.targetNodeId || t.nodeId || "")}
              · <span class="${tier === "HIGH" ? "tier-high" : ""}">${escapeHtml(tier || "STANDARD")}</span>
              · ${escapeHtml(buckets)}
            </span>
            <span>${t.score ?? 0} / ${t.expireRound ?? "-"}</span>
          </div>
        `;
      }).join("") : `<div class="event"><span>No active tasks</span></div>`;
    }

    function renderEvents(events) {
      const keep = events.slice(-18).reverse();
      document.getElementById("events").innerHTML = keep.map(e => `
        <div class="event">
          <b>${escapeHtml(e.type || "")}</b>
          <span>${escapeHtml(summarize(e.payload || {}))}</span>
        </div>
      `).join("");
    }

    function summarize(p) {
      const parts = [];
      for (const key of ["playerId", "teamId", "action", "nodeId", "targetNodeId", "routeType", "taskId", "resourceType", "errorCode", "score", "taskScore", "freshness", "totalScore"]) {
        if (p[key] !== undefined && p[key] !== null) parts.push(`${key}:${p[key]}`);
      }
      return parts.join("  ");
    }

    function formatBuffs(buffs) {
      if (!buffs.length) return "-";
      return buffs.map(b => `${b.type}:${b.remainingRound}`).join(" ");
    }

    function formatResources(resources) {
      const entries = Object.entries(resources).filter(([, v]) => Number(v) > 0);
      if (!entries.length) return "-";
      return entries.map(([k, v]) => `${k}:${v}`).join(" ");
    }

    function routeColor(type) {
      return {
        ROAD: "var(--road)",
        WATER: "var(--water)",
        MOUNTAIN: "var(--mountain)",
        BRANCH: "var(--branch)",
      }[type] || "var(--line)";
    }

    function escapeHtml(value) {
      return String(value).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
    }
  </script>
</body>
</html>
"""


if __name__ == "__main__":
    raise SystemExit(main())
