from __future__ import annotations

from copy import deepcopy
from typing import Any


RESOURCE_TYPES = [
    "ICE_BOX",
    "FAST_HORSE",
    "SHORT_HORSE",
    "BOAT_RIGHT",
    "PASS_TOKEN",
    "OFFICIAL_PERMIT",
    "INTEL",
]


TASK_TEMPLATES: dict[str, dict[str, Any]] = {
    "T01": {"name": "Timed pass", "score": 30, "processRound": 3, "processType": "TASK"},
    "T02": {"name": "Station rush", "score": 30, "processRound": 4, "processType": "TASK"},
    "T04": {"name": "Obstacle clear", "score": 30, "processRound": 6, "processType": "CLEAR_OBSTACLE"},
    "T06": {"name": "Horse exchange", "score": 30, "processRound": 3, "processType": "HORSE_EXCHANGE"},
    "T08": {"name": "Dock boat", "score": 30, "processRound": 4, "processType": "TASK"},
    "T11": {"name": "Plank review", "score": 30, "processRound": 4, "processType": "TASK"},
    "T12": {"name": "Road permit", "score": 15, "processRound": 5, "processType": "TASK"},
    "T13": {"name": "Intermodal", "score": 15, "processRound": 5, "processType": "TASK"},
    "T14": {"name": "Mountain dispatch", "score": 15, "processRound": 5, "processType": "TASK"},
}


def build_default_map() -> dict[str, Any]:
    nodes = [
        node("S01", 101, "Lingnan Orchard", "START", 5, 50, start=True),
        node("S02", 102, "Nanling Relay", "CHECKPOINT", 15, 45),
        node("S03", 103, "Meiguan Relay", "PASS", 25, 42),
        node("S04", 104, "Jiangnan Dock", "DOCK", 22, 54),
        node("S05", 105, "Dongting Water Relay", "WATER_STATION", 36, 50),
        node("S06", 106, "Wuling Mountain Road", "MOUNTAIN_NODE", 18, 30),
        node("S07", 107, "Jingxiang Relay", "STATION", 42, 40),
        node("S08", 108, "Qinling Plank Road", "MOUNTAIN_PASS", 45, 28),
        node("S09", 109, "Luoyang Relay", "STATION", 56, 39),
        node("S10", 110, "Wuguan Pass", "KEY_PASS", 55, 36),
        node("S11", 111, "Tongguan Relay", "PASS", 66, 30),
        node("S12", 112, "Guanzhong Plain", "JUNCTION", 70, 23),
        node("S13", 113, "Baqiao Relay", "PALACE_STATION", 74, 20),
        node("S14", 114, "Zhuque Gate", "GATE", 76, 18),
        node("S15", 115, "Xingqing Palace", "FINISH", 78, 18, terminal=True),
    ]
    edges = [
        edge("E01", "S01", "S02", "ROAD", 30),
        edge("E02", "S02", "S03", "ROAD", 25),
        edge("E03", "S03", "S07", "ROAD", 54),
        edge("E04", "S07", "S09", "ROAD", 46),
        edge("E05", "S09", "S10", "ROAD", 40),
        edge("E06", "S10", "S11", "ROAD", 36),
        edge("E07", "S11", "S12", "ROAD", 20),
        edge("E08", "S12", "S13", "ROAD", 25),
        edge("E09", "S13", "S14", "ROAD", 18),
        edge("E10", "S14", "S15", "ROAD", 10),
        edge("E11", "S02", "S04", "ROAD", 20),
        edge("E12", "S04", "S05", "WATER", 44),
        edge("E13", "S05", "S07", "BRANCH", 46),
        edge("E15", "S01", "S06", "MOUNTAIN", 44),
        edge("E16", "S06", "S08", "MOUNTAIN", 54),
        edge("E17", "S08", "S10", "BRANCH", 46),
        edge("E18", "S03", "S06", "BRANCH", 38),
        edge("E19", "S05", "S09", "WATER", 48),
        edge("E20", "S07", "S08", "MOUNTAIN", 42),
        edge("E21", "S04", "S07", "BRANCH", 54),
        edge("E22", "S08", "S09", "BRANCH", 64),
    ]
    process_nodes = [
        process("S02", "TRANSFER", 4),
        process("S04", "BOARD", 7),
        process("S05", "WATER_TRANSFER", 6),
        process("S11", "PASS_TRANSFER", 5),
        process("S13", "PALACE_TRANSFER", 5),
        process("S14", "VERIFY", 6),
    ]
    resources = [
        res("S03", "ICE_BOX"), res("S03", "PASS_TOKEN"), res("S03", "INTEL"),
        res("S04", "SHORT_HORSE"), res("S04", "BOAT_RIGHT"), res("S04", "INTEL"),
        res("S06", "ICE_BOX"), res("S06", "INTEL"),
        res("S08", "SHORT_HORSE"), res("S08", "PASS_TOKEN"), res("S08", "INTEL"),
        res("S07", "ICE_BOX"), res("S07", "SHORT_HORSE"),
        res("S09", "FAST_HORSE"), res("S09", "OFFICIAL_PERMIT"),
        res("S10", "INTEL"),
        res("S11", "INTEL"),
        res("S13", "PASS_TOKEN"), res("S13", "OFFICIAL_PERMIT"), res("S13", "INTEL"),
    ]
    task_candidates = {
        "T01": ["S03"],
        "T02": ["S07", "S10"],
        "T04": ["S06", "S08"],
        "T06": ["S09", "S04", "S06"],
        "T08": ["S04", "S05"],
        "T11": ["S08", "S10", "S11"],
        "T12": ["S11", "S13"],
        "T13": ["S13", "S09", "S12"],
        "T14": ["S10", "S11", "S12"],
    }
    route_task_buckets = {
        "ROAD": ["S03", "S07", "S09", "S10", "S11", "S12", "S13"],
        "WATER": ["S04", "S05", "S09"],
        "MOUNTAIN": ["S06", "S08", "S10"],
        "BRANCH": ["S04", "S05", "S07", "S08", "S09", "S10"],
    }
    gameplay = {
        "roles": {
            "startNodeId": "S01",
            "gateNodeId": "S14",
            "terminalNodeIds": ["S15"],
            "safeZoneNodeIds": ["S15"],
            "rushExcludedNodeIds": ["S11", "S12", "S13"],
        },
        "resources": deepcopy(resources),
        "processNodes": deepcopy(process_nodes),
        "taskCandidates": deepcopy(task_candidates),
        "routeTaskBuckets": deepcopy(route_task_buckets),
        "obstacleCandidateNodeIds": ["S06", "S08", "S10", "S11"],
    }
    return {
        "schemaVersion": "1.0",
        "mapId": "lychee_default",
        "mapName": "Lychee Transport Arena",
        "designVersion": "local-1",
        "maxX": 80,
        "maxY": 60,
        "nodes": nodes,
        "edges": edges,
        "resources": resources,
        "processNodes": process_nodes,
        "taskCandidates": task_candidates,
        "routeTaskBuckets": route_task_buckets,
        "taskTemplates": task_template_list(),
        "gameplay": gameplay,
    }


def node(node_id: str, code: int, name: str, node_type: str, x: int, y: int,
         start: bool = False, terminal: bool = False) -> dict[str, Any]:
    return {
        "nodeId": node_id,
        "code": str(code),
        "name": name,
        "x": x,
        "y": y,
        "type": node_type,
        "nodeType": node_type,
        "icon": node_type,
        "start": start,
        "terminal": terminal,
        "visible": True,
    }


def edge(edge_id: str, from_node: str, to_node: str, route_type: str, distance: int,
         bidirectional: bool = True) -> dict[str, Any]:
    return {
        "edgeId": edge_id,
        "fromNode": from_node,
        "toNode": to_node,
        "fromNodeId": from_node,
        "toNodeId": to_node,
        "routeType": route_type,
        "distance": distance,
        "bidirectional": bidirectional,
        "pathId": edge_id,
    }


def process(node_id: str, process_type: str, process_round: int,
            can_window: bool = True) -> dict[str, Any]:
    return {
        "nodeId": node_id,
        "processType": process_type,
        "processRound": process_round,
        "canWindow": can_window,
    }


def res(node_id: str, resource_type: str, count: int = 1, claim_round: int = 2) -> dict[str, Any]:
    return {
        "nodeId": node_id,
        "resourceType": resource_type,
        "count": count,
        "claimRound": claim_round,
    }


def task_template_list() -> list[dict[str, Any]]:
    rows = []
    for tid, cfg in TASK_TEMPLATES.items():
        rows.append({
            "taskTemplateId": tid,
            "name": cfg["name"],
            "score": cfg["score"],
            "processType": cfg["processType"],
            "processRound": cfg["processRound"],
            "requiredResourceTypes": ["FAST_HORSE", "SHORT_HORSE"] if tid == "T06" else [],
        })
    return rows
