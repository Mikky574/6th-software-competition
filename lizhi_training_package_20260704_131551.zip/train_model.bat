@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "MODE=%~1"
if "%MODE%"=="" set "MODE=smoke"

if /I "%MODE%"=="help" goto :help
if /I "%MODE%"=="-h" goto :help
if /I "%MODE%"=="--help" goto :help

set "GENERATION_OVERRIDE=%~3"
set "RESUME_MODE=%~4"
if /I "%GENERATION_OVERRIDE%"=="resume" (
  set "RESUME_MODE=resume"
  set "GENERATION_OVERRIDE="
)

set "JOBS=%~2"
if "%JOBS%"=="" set "JOBS=4"
set "JOBS_RAW=%JOBS%"
for /f "tokens=1 delims=." %%J in ("%JOBS%") do set "JOBS=%%J"
set "BAD_JOBS="
for /f "delims=0123456789" %%J in ("%JOBS%") do set "BAD_JOBS=%%J"
if defined BAD_JOBS (
  echo Invalid jobs value: %JOBS_RAW%
  echo Use an integer, for example: train_model.bat big 8
  exit /b 1
)
if not "%JOBS_RAW%"=="%JOBS%" (
  echo [train_model] normalized jobs "%JOBS_RAW%" to "%JOBS%".
)

set "OPPONENTS=.\players\direct_runner,.\players\guard_trapper,.\players\window_baiter,.\players\rules_showcase"
set "TIMEOUT_MS=80"
set "ROUNDS=600"
set "RUN_NN=0"
set "MATCH_LOG_EVERY=0"
set "SEED_WINDOW_SIZE=0"
set "SEED_BLOCK_SIZE=0"
set "ANCHOR_SEED_COUNT=0"

if /I "%MODE%"=="smoke" (
  set "OUT=.\runs\train_smoke"
  set "SEEDS=1"
  set "OBSTACLES=0"
  set "POPULATION=3"
  set "GENERATIONS=1"
  set "MATCH_LOG_EVERY=2"
) else if /I "%MODE%"=="fast" (
  set "OUT=.\runs\train_fast"
  set "SEEDS=1,2"
  set "OBSTACLES=0,1"
  set "POPULATION=4"
  set "GENERATIONS=2"
  set "MATCH_LOG_EVERY=8"
) else if /I "%MODE%"=="mid" (
  set "OUT=.\runs\train_mid"
  set "SEEDS=1,2,3"
  set "OBSTACLES=0,2"
  set "POPULATION=6"
  set "GENERATIONS=4"
  set "RUN_NN=1"
  set "MATCH_LOG_EVERY=16"
) else if /I "%MODE%"=="big" (
  set "OUT=.\runs\train_big"
  set "SEEDS=1,2,3,4,5,6,7,8"
  set "OBSTACLES=0,1,2,3"
  set "POPULATION=12"
  set "GENERATIONS=8"
  set "RUN_NN=1"
  set "MATCH_LOG_EVERY=32"
) else if /I "%MODE%"=="hard" (
  set "OUT=.\runs\train_hard"
  set "OPPONENTS=.\players\direct_runner,.\players\guard_trapper,.\players\window_baiter,.\players\rules_showcase,.\players\horse_showcase,.\client@.\configs\score_attack_params.json,.\client@.\configs\full_rules_params.json,.\client@.\configs\horse_params.json"
  set "SEEDS=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18"
  set "OBSTACLES=0,1,2,3"
  set "POPULATION=10"
  set "GENERATIONS=8"
  set "RUN_NN=1"
  set "MATCH_LOG_EVERY=32"
  set "SEED_WINDOW_SIZE=6"
  set "SEED_BLOCK_SIZE=3"
  set "ANCHOR_SEED_COUNT=2"
) else (
  echo Unknown mode: %MODE%
  goto :help
)

if /I "%MODE%"=="hard" (
  if exist ".\runs\train_big\best_params.json" set "OPPONENTS=%OPPONENTS%,.\client@.\runs\train_big\best_params.json"
  if exist ".\runs\train_hard\best_params.json" set "OPPONENTS=%OPPONENTS%,.\client@.\runs\train_hard\best_params.json"
  if exist ".\runs\train_big_nn\best_predicted_params.json" set "OPPONENTS=%OPPONENTS%,.\client@.\runs\train_big_nn\best_predicted_params.json"
  if exist ".\runs\train_hard_nn\best_predicted_params.json" set "OPPONENTS=%OPPONENTS%,.\client@.\runs\train_hard_nn\best_predicted_params.json"
)

if not "%LIZHI_MATCH_LOG_EVERY%"=="" (
  set "MATCH_LOG_EVERY=%LIZHI_MATCH_LOG_EVERY%"
  echo [train_model] using LIZHI_MATCH_LOG_EVERY=%LIZHI_MATCH_LOG_EVERY%
)

if not "%GENERATION_OVERRIDE%"=="" (
  set "GENERATION_RAW=%GENERATION_OVERRIDE%"
  for /f "tokens=1 delims=." %%G in ("%GENERATION_OVERRIDE%") do set "GENERATION_OVERRIDE=%%G"
  set "BAD_GENERATIONS="
  for /f "delims=0123456789" %%G in ("!GENERATION_OVERRIDE!") do set "BAD_GENERATIONS=%%G"
  if defined BAD_GENERATIONS (
    echo Invalid generations value: !GENERATION_RAW!
    echo Use a positive integer, for example: train_model.bat big 8 50 resume
    exit /b 1
  )
  if "!GENERATION_OVERRIDE!"=="" (
    echo Invalid generations value: !GENERATION_RAW!
    exit /b 1
  )
  if "!GENERATION_OVERRIDE!"=="0" (
    echo Invalid generations value: !GENERATION_RAW!
    echo Generations must be at least 1.
    exit /b 1
  )
  if not "!GENERATION_RAW!"=="!GENERATION_OVERRIDE!" (
    echo [train_model] normalized generations "!GENERATION_RAW!" to "!GENERATION_OVERRIDE!".
  )
  set "GENERATIONS=!GENERATION_OVERRIDE!"
)

set "RESUME_FLAG="
if not "%RESUME_MODE%"=="" (
  if /I "%RESUME_MODE%"=="resume" (
    set "RESUME_FLAG=--resume"
  ) else (
    echo Unknown resume flag: %RESUME_MODE%
    echo Use "resume" as the last argument, for example: train_model.bat big 8 50 resume
    exit /b 1
  )
)

echo.
echo [train_model] mode=%MODE% jobs=%JOBS%
echo [train_model] out=%OUT%
echo [train_model] opponents=%OPPONENTS%
echo [train_model] seeds=%SEEDS% obstacles=%OBSTACLES% population=%POPULATION% generations=%GENERATIONS%
if not "%SEED_WINDOW_SIZE%"=="0" echo [train_model] seedWindow=%SEED_WINDOW_SIZE% seedBlock=%SEED_BLOCK_SIZE% anchorSeeds=%ANCHOR_SEED_COUNT%
echo [train_model] matchLogEvery=%MATCH_LOG_EVERY% resume=%RESUME_MODE%
echo.
echo The optimizer prints one score line per generation:
echo   fitness, W/L/D, league points, avgScore, opponent avg score, avgMargin, worstScore
echo It also prints per-candidate match progress every %MATCH_LOG_EVERY% matches.
echo.

python -m arena.optimizer ^
  --candidate ".\client" ^
  --opponents "%OPPONENTS%" ^
  --out "%OUT%" ^
  --seeds "%SEEDS%" ^
  --obstacles "%OBSTACLES%" ^
  --population %POPULATION% ^
  --generations %GENERATIONS% ^
  --timeout-ms %TIMEOUT_MS% ^
  --rounds %ROUNDS% ^
  --jobs %JOBS% ^
  --seed-window-size %SEED_WINDOW_SIZE% ^
  --seed-block-size %SEED_BLOCK_SIZE% ^
  --anchor-seed-count %ANCHOR_SEED_COUNT% ^
  --match-log-every %MATCH_LOG_EVERY% %RESUME_FLAG%

if errorlevel 1 (
  echo.
  echo [train_model] optimizer failed.
  exit /b 1
)

echo.
echo [train_model] Best params:
type "%OUT%\best_params.json"
echo.
echo.
echo [train_model] Saved:
echo   %OUT%\best_params.json
echo   %OUT%\history.json

if "%RUN_NN%"=="1" (
  echo.
  echo [train_model] Training neural surrogate from optimizer history...
  python -m arena.neural_surrogate ^
    --history "%OUT%\history.json" ^
    --out "%OUT%_nn" ^
    --epochs 500 ^
    --candidates 32 ^
    --pool 2000
  if errorlevel 1 (
    echo.
    echo [train_model] neural surrogate failed, optimizer result is still usable.
  ) else (
    echo.
    echo [train_model] Neural candidate params:
    echo   %OUT%_nn\best_predicted_params.json
  )
)

echo.
echo [train_model] Validate best params with:
echo python .\run_match.py --red .\client --blue .\players\window_baiter --red-params "@%OUT%\best_params.json" --out .\runs\validate_best --port 0 --timeout-ms 80 --rounds 600 --quiet-clients
echo.
exit /b 0

:help
echo Usage:
echo   train_model.bat [smoke^|fast^|mid^|big^|hard] [jobs] [target_generations] [resume]
echo.
echo Examples:
echo   train_model.bat smoke 2
echo   train_model.bat fast 4
echo   train_model.bat fast 4 20
echo   train_model.bat mid 4
echo   train_model.bat big 8
echo   train_model.bat hard 8
echo   train_model.bat big 8 100 resume
echo   train_model.bat hard 8 50 resume
echo   train_model.bat mid 4 resume
echo.
echo smoke: quick syntax and pipeline check.
echo fast:  quicker visible evolution, good first real run.
echo mid:   useful overnight-ish search on a laptop.
echo big:   larger adversarial search; use more jobs if CPU allows.
echo hard:  stronger adversarial search against fixed bots plus client parameter snapshots.
echo        Uses a larger seed pool, but rotates only part of it every few generations.
echo Set LIZHI_MATCH_LOG_EVERY=1 before running if you want one progress line per match.
echo.
echo target_generations is the total generation target. With resume, training
echo continues from runs\train_MODE\history.json until that target is reached.
exit /b 0
