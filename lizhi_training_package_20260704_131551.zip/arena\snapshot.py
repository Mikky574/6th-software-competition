from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont

from .default_map import build_default_map


COLORS = {
    "bg": (18, 21, 23),
    "panel": (25, 29, 32),
    "text": (238, 242, 243),
    "muted": (170, 180, 185),
    "ROAD": (198, 165, 109),
    "WATER": (63, 159, 196),
    "MOUNTAIN": (110, 176, 113),
    "BRANCH": (180, 123, 195),
    "RED": (229, 80, 80),
    "BLUE": (78, 140, 255),
    "node": (44, 52, 57),
    "finish": (224, 184, 79),
}


def write_snapshot(run_dir: Path, frame_index: int = -1, out: Path | None = None) -> Path:
    replay_path = run_dir / "replay.jsonl"
    result_path = run_dir / "result.json"
    replay = [json.loads(line) for line in replay_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if not replay:
        raise ValueError("empty replay")
    if frame_index < 0:
        frame_index = len(replay) - 1
    frame = replay[max(0, min(len(replay) - 1, frame_index))]
    map_data = build_default_map()
    image = Image.new("RGB", (1280, 820), COLORS["bg"])
    draw = ImageDraw.Draw(image)
    font = load_font(18)
    small = load_font(14)
    title_font = load_font(24)

    draw.rectangle((0, 0, 1280, 70), fill=(21, 25, 28))
    draw.text((24, 20), "一骑红尘：荔枝争运战 对战回放", fill=COLORS["text"], font=title_font)
    winner = result.get("winnerPlayerId")
    subtitle = f"Round {frame.get('round')} / Over {result.get('overRound')}   Winner: {winner if winner is not None else 'DRAW'}"
    draw.text((760, 24), subtitle, fill=COLORS["muted"], font=font)

    box = (28, 92, 900, 782)
    draw.rounded_rectangle(box, radius=8, fill=(20, 24, 26), outline=(60, 70, 77), width=2)
    nodes = {n["nodeId"]: n for n in map_data["nodes"]}

    def sx(x: float) -> int:
        return int(box[0] + 34 + x / 80 * (box[2] - box[0] - 68))

    def sy(y: float) -> int:
        return int(box[1] + 34 + y / 60 * (box[3] - box[1] - 68))

    for edge in map_data["edges"]:
        a = nodes[edge["fromNodeId"]]
        b = nodes[edge["toNodeId"]]
        draw.line((sx(a["x"]), sy(a["y"]), sx(b["x"]), sy(b["y"])),
                  fill=COLORS.get(edge["routeType"], (90, 100, 105)), width=5)
    for node in map_data["nodes"]:
        x, y = sx(node["x"]), sy(node["y"])
        fill = COLORS["finish"] if node["terminal"] or node["nodeId"] == "S14" else COLORS["node"]
        draw.ellipse((x - 10, y - 10, x + 10, y + 10), fill=fill, outline=COLORS["text"], width=2)
        draw.text((x + 12, y - 20), node["nodeId"], fill=COLORS["text"], font=small)

    for player in frame.get("players", []):
        x, y = player_xy(player, nodes, sx, sy)
        offset = -13 if player.get("teamId") == "RED" else 13
        color = COLORS[player.get("teamId", "RED")]
        draw.ellipse((x - 17, y + offset - 17, x + 17, y + offset + 17), fill=color, outline=(255, 255, 255), width=3)
        draw.text((x - 6, y + offset - 11), "R" if player.get("teamId") == "RED" else "B",
                  fill=(255, 255, 255), font=font)

    draw_side_panel(draw, frame, result, font, small)
    out = out or (run_dir / "preview.png")
    image.save(out)
    return out


def player_xy(player: dict[str, Any], nodes: dict[str, dict[str, Any]], sx, sy) -> tuple[int, int]:
    current = nodes.get(player.get("currentNodeId")) or nodes["S01"]
    nxt = nodes.get(player.get("nextNodeId"))
    if not nxt:
        return sx(current["x"]), sy(current["y"])
    progress = max(0.0, min(1.0, float(player.get("moveProgress") or 0)))
    x = current["x"] + (nxt["x"] - current["x"]) * progress
    y = current["y"] + (nxt["y"] - current["y"]) * progress
    return sx(x), sy(y)


def draw_side_panel(draw: ImageDraw.ImageDraw, frame: dict[str, Any], result: dict[str, Any],
                    font: ImageFont.ImageFont, small: ImageFont.ImageFont) -> None:
    draw.rounded_rectangle((930, 92, 1252, 782), radius=8, fill=COLORS["panel"], outline=(60, 70, 77), width=2)
    y = 116
    for player in frame.get("players", []):
        team = player.get("teamId")
        color = COLORS.get(team, COLORS["text"])
        draw.text((956, y), f"{team}  {player.get('playerName')}", fill=color, font=font)
        draw.text((956, y + 32), f"Score {player.get('totalScore', 0)}", fill=COLORS["text"], font=load_font(30))
        lines = [
            f"State: {player.get('state')}",
            f"Node: {player.get('currentNodeId')} -> {player.get('nextNodeId') or '-'}",
            f"Speed: {player.get('movePerFrame', 1000)}",
            f"Fresh: {round(float(player.get('freshness') or 0), 1)}",
            f"Good/Bad: {player.get('goodFruit')} / {player.get('badFruit')}",
            f"Tasks: {player.get('taskScore')}   Penalty: {player.get('penaltyScore')}",
            f"Score parts: {format_score_detail(player.get('scoreDetail') or {})}",
            f"Routes: {format_route_rounds(player)}",
            f"Buffs: {format_buffs(player.get('buffs') or [])}",
            f"Resources: {format_resources(player.get('resources') or {})}",
        ]
        yy = y + 76
        for line in lines:
            draw.text((956, yy), line, fill=COLORS["muted"], font=small)
            yy += 22
        y += 300
    draw.text((956, y + 12), f"Result: {result.get('resultType')}", fill=COLORS["text"], font=font)
    draw.text((956, y + 44), f"Reason: {result.get('overReason')}", fill=COLORS["muted"], font=small)
    draw.text((956, y + 72), f"League: {result.get('leaguePoints')}", fill=COLORS["muted"], font=small)


def load_font(size: int) -> ImageFont.ImageFont:
    for name in ("msyh.ttc", "simhei.ttf", "arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def format_buffs(buffs: list[dict[str, Any]]) -> str:
    if not buffs:
        return "-"
    return " ".join(f"{b.get('type')}:{b.get('remainingRound')}" for b in buffs)


def format_resources(resources: dict[str, Any]) -> str:
    items = [f"{k}:{v}" for k, v in resources.items() if int(v or 0) > 0]
    return " ".join(items) if items else "-"


def format_score_detail(detail: dict[str, Any]) -> str:
    if not detail:
        return "-"
    return (
        f"D{detail.get('delivery', 0)} G{detail.get('goodFruit', 0)} "
        f"F{detail.get('freshness', 0)} T{detail.get('tasks', 0)} "
        f"Tm{detail.get('time', 0)}"
    )


def format_route_rounds(player: dict[str, Any]) -> str:
    return (
        f"R{player.get('roadRounds', 0)} W{player.get('waterRounds', 0)} "
        f"M{player.get('mountainRounds', 0)} B{player.get('branchRounds', 0)}"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a PNG snapshot from a replay directory.")
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--frame", type=int, default=-1)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    print(write_snapshot(args.run_dir, args.frame, args.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
