# horse_showcase

Display strategy for horse mechanics.

It reuses `direct_runner` with `HORSE_SHOWCASE=1`:

- route to S07 and claim/use `SHORT_HORSE` (`movePerFrame = 1150`, 14 frames);
- route to S09 and claim/use `FAST_HORSE` (`movePerFrame = 1200`, 20 frames);
- then continue to gate verification and delivery.

This player is for visualization and validation, not for strongest play.
