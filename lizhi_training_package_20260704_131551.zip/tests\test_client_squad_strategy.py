import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLIENT_DIR = ROOT / "client"
if str(CLIENT_DIR) not in sys.path:
    sys.path.insert(0, str(CLIENT_DIR))

from core import Agent, World  # noqa: E402


class ClientSquadStrategyTests(unittest.TestCase):
    def make_world(self) -> World:
        w = World()
        w.round = 10
        w.phase = "NORMAL"
        w.my_id = 1001
        w.my_team = "RED"
        w.opp_id = 1002
        w.opp_team = "BLUE"
        w.gate_node = "S03"
        w.terminal_nodes = ["S04"]
        w.me = {
            "playerId": 1001,
            "teamId": "RED",
            "state": "IDLE",
            "currentNodeId": "S01",
            "squadAvailable": 8,
            "resources": {},
            "goodFruit": 100,
            "freshness": 100,
            "verified": False,
        }
        w.opp = {"playerId": 1002, "teamId": "BLUE"}
        w.nodes = {
            "S01": {"nodeId": "S01"},
            "S02": {"nodeId": "S02", "processRound": 5, "processType": "TRANSFER"},
            "S03": {"nodeId": "S03"},
            "S04": {"nodeId": "S04"},
        }
        w.node_state = {nid: dict(node) for nid, node in w.nodes.items()}
        w.adj = {
            "S01": [{"to": "S02", "routeType": "ROAD", "distance": 10, "edgeId": "E01"}],
            "S02": [
                {"to": "S01", "routeType": "ROAD", "distance": 10, "edgeId": "E01"},
                {"to": "S03", "routeType": "ROAD", "distance": 10, "edgeId": "E02"},
            ],
            "S03": [{"to": "S02", "routeType": "ROAD", "distance": 10, "edgeId": "E02"}],
        }
        return w

    def test_scout_mode_marks_heavy_process_ahead(self) -> None:
        w = self.make_world()
        action = Agent(w, {
            "squad_mode": "scout",
            "squad_min_gap": 0,
            "squad_scout_max_eta": 80,
            "do_tasks": False,
            "ice_target": 0,
        }).decide_squad()
        self.assertEqual(action, {"action": "SQUAD_SCOUT", "targetNodeId": "S02"})

    def test_combat_mode_weakens_enemy_guard_ahead(self) -> None:
        w = self.make_world()
        w.node_state["S02"]["guard"] = {"ownerTeamId": "BLUE", "defense": 3}
        action = Agent(w, {
            "squad_mode": "combat",
            "squad_min_gap": 0,
            "do_tasks": False,
            "ice_target": 0,
        }).decide_squad()
        self.assertEqual(action, {"action": "SQUAD_WEAKEN", "targetNodeId": "S02"})

    def test_combat_mode_does_not_weaken_without_enough_hands(self) -> None:
        w = self.make_world()
        w.me["squadAvailable"] = 1
        w.nodes["S02"]["processRound"] = 0
        w.node_state["S02"]["processRound"] = 0
        w.node_state["S02"]["guard"] = {"ownerTeamId": "BLUE", "defense": 3}
        action = Agent(w, {
            "squad_mode": "combat",
            "squad_min_gap": 0,
            "do_tasks": False,
            "ice_target": 0,
        }).decide_squad()
        self.assertIsNone(action)


if __name__ == "__main__":
    unittest.main()
