from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .server import run_with_clients
from .visualize import write_viewer


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a local Lychee arena match.")
    parser.add_argument("--client", type=Path, default=Path("client"),
                        help="client directory used for both sides unless --red/--blue are set")
    parser.add_argument("--red", type=Path, default=None, help="red client directory")
    parser.add_argument("--blue", type=Path, default=None, help="blue client directory")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=30000)
    parser.add_argument("--red-id", default="1001")
    parser.add_argument("--blue-id", default="1002")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--rounds", type=int, default=600)
    parser.add_argument("--timeout-ms", type=int, default=500)
    parser.add_argument("--obstacle-count", type=int, default=0)
    parser.add_argument("--out", type=Path, default=Path("runs") / "latest")
    parser.add_argument("--no-viewer", action="store_true", help="do not generate viewer.html")
    parser.add_argument("--red-params", default="", help="JSON params for red client, or @path")
    parser.add_argument("--blue-params", default="", help="JSON params for blue client, or @path")
    parser.add_argument("--quiet-clients", action="store_true", help="hide client stdout/stderr")
    args = parser.parse_args()

    red = args.red or args.client
    blue = args.blue or args.client
    result = run_with_clients(
        red_path=red,
        blue_path=blue,
        host=args.host,
        port=args.port,
        red_id=_coerce_id(args.red_id),
        blue_id=_coerce_id(args.blue_id),
        seed=args.seed,
        duration_round=args.rounds,
        action_timeout=args.timeout_ms / 1000.0,
        obstacle_count=args.obstacle_count,
        output_dir=args.out,
        red_env=_params_env(args.red_params),
        blue_env=_params_env(args.blue_params),
        quiet=args.quiet_clients,
    )
    if not args.no_viewer:
        viewer = write_viewer(args.out)
        print(f"viewer: {viewer}")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def _coerce_id(raw: str):
    return int(raw) if str(raw).lstrip("-").isdigit() else raw


def _params_env(raw: str) -> dict[str, str] | None:
    params = _load_params(raw)
    if not params:
        return None
    return {"LYCHEE_PARAMS_JSON": json.dumps(params, ensure_ascii=False, separators=(",", ":"))}


def _load_params(raw: str) -> dict[str, Any]:
    raw = (raw or "").strip()
    if not raw:
        return {}
    if raw.startswith("@"):
        raw = Path(raw[1:]).read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("params must be a JSON object")
    return data


if __name__ == "__main__":
    raise SystemExit(main())
