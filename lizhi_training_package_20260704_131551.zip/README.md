# 荔枝争运训练包使用说明

这个包用于在另一台 Windows 机器上继续训练策略、验证比赛、生成最终 `client` 提交文件夹。

## 1. 环境

- 安装 Python 3.10 或更新版本。
- 解压后在命令行进入本目录：

```bat
cd /d 你的解压目录\lizhi_training_package
```

先跑一次测试：

```bat
python -m unittest discover -s tests
```

## 2. 快速验证

```bat
.\train_model.bat smoke 2
```

`smoke` 只用于检查环境和流程是否正常。

## 3. 正式训练

推荐先用：

```bat
.\train_model.bat fast 4 20
```

更大规模：

```bat
.\train_model.bat big 8 50 resume
```

参数含义：

- 第 1 个参数：`smoke`、`fast`、`mid`、`big`
- 第 2 个参数：并行数，例如 `8`
- 第 3 个参数：目标总代数，例如 `50`
- 第 4 个参数：写 `resume` 时从 `runs\train_big\history.json` 续跑到目标总代数

`big` 默认每个候选会打：

```text
4 个对手 × 8 个种子 × 4 种障碍 × 红蓝双方 = 256 场
12 个候选 = 3072 场 / 代
```

训练日志里：

- `last=0:0` 只表示最近打印点的最后一场，不代表全部没分。
- `scored=64/96` 表示当前候选已完成 96 场里有 64 场拿到非零分。
- `delivered=60/96` 表示当前候选已完成 96 场里有 60 场真正完成交付。
- `recentScore` 是最近一段比赛均分，更适合判断模型是否还在演进。

训练会跨不同随机种子评估，种子会改变天气日程。客户端路径估计会读取当前天气和 30 帧内预报，计算暴雨水路、山雾山路、炎热鲜度损耗以及水路处理加时；优化器会搜索 `fresh_weight`、偏好水路/陆路/山路任务、冰盒储备、终局冰盒释放阈值和使用间隔。

小分队也会进入训练：`squad_mode` 会在侦察、战斗、禁用之间搜索；侦察会优先处理高分任务点、重处理点和宫门前关键点；战斗模式会学习是否用小分队削弱守卫、清理障碍，以及派遣间隔和最大可接受 ETA。窗口策略会记忆对手已亮出的牌，低价值重复平局会倾向弃权，高价值窗口会尝试反制对手重复牌，避免被对方一直拖成平局损失时间和新鲜度。

## 4. 生成提交 client

训练完成后执行：

```bat
.\build_submit_client.bat
```

默认输出：

```text
submission\client
```

指定参数文件和目标目录：

```bat
.\build_submit_client.bat .\runs\train_big\best_params.json D:\my_submit\client
```

生成的提交目录会冻结 `best_params.json`，不依赖训练目录。

## 5. 手动验证一局

```bat
python .\run_match.py --red .\client --blue .\players\direct_runner --red-params "@.\runs\train_big\best_params.json" --out .\runs\validate_best --port 0 --timeout-ms 80 --rounds 600 --quiet-clients
```

验证可视化页面会在对应 `runs\...\viewer.html` 里生成。

## 6. 包内容说明

本迁移包包含：

- `arena` 比赛引擎、可视化、优化器、神经网络代理训练
- `client` 当前选手策略
- `players` 对抗基准策略
- `configs` 手工策略种子
- `tests` 单元测试
- 协议书和任务书
- `train_model.bat`、`build_submit_client.bat`

本迁移包不包含：

- `runs` 训练日志、回放、历史结果
- `submission` 生成的提交目录
- `__pycache__`、`.pyc` 缓存
