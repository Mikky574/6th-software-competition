from __future__ import annotations

import unittest

from arena.engine import GameEngine, Guard
from arena.protocol import FrameBuffer, encode_frame


class ProtocolTests(unittest.TestCase):
    def test_buffer_handles_sticky_frames(self) -> None:
        buf = FrameBuffer()
        a = {"msg_name": "action", "msg_data": {"round": 1, "actions": []}}
        b = {"msg_name": "ready", "msg_data": {"round": 1}}
        frames = buf.feed(encode_frame(a) + encode_frame(b))
        self.assertEqual([f["msg_name"] for f in frames], ["action", "ready"])

    def test_buffer_handles_split_frame(self) -> None:
        buf = FrameBuffer()
        raw = encode_frame({"msg_name": "ready", "msg_data": {}})
        self.assertEqual(buf.feed(raw[:3]), [])
        self.assertEqual(buf.feed(raw[3:])[0]["msg_name"], "ready")


class EngineTests(unittest.TestCase):
    def test_empty_heartbeats_do_not_count_missing(self) -> None:
        engine = GameEngine(seed=1, duration_round=3)
        engine.run_round({1001: [], 1002: []})
        self.assertEqual(engine.players[1001].missing_action_rounds, 0)
        self.assertEqual(engine.players[1002].missing_action_rounds, 0)

    def test_move_rejects_non_adjacent_as_illegal(self) -> None:
        engine = GameEngine(seed=1, duration_round=3)
        engine.run_round({1001: [{"action": "MOVE", "targetNodeId": "S15"}], 1002: []})
        self.assertEqual(engine.players[1001].illegal_action_count, 1)
        self.assertTrue(any(e["type"] == "INVALID_ACTION" for e in engine.events))

    def test_scoring_delivered_player(self) -> None:
        engine = GameEngine(seed=1, duration_round=600)
        p = engine.players[1001]
        p.delivered = True
        p.deliver_round = 500
        p.deliver_good_fruit = 90
        p.deliver_freshness = 80
        p.task_score_base = 90
        detail = engine.score_detail(p)
        self.assertGreater(detail["total"], 0)
        self.assertEqual(detail["delivery"], 240)

    def test_scoring_uses_task_book_600_frame_time_formula(self) -> None:
        engine = GameEngine(seed=1, duration_round=720)
        p = engine.players[1001]
        p.delivered = True
        p.deliver_round = 528
        p.deliver_good_fruit = 98
        p.deliver_freshness = 75.697
        p.task_score_base = 120
        detail = engine.score_detail(p)
        self.assertEqual(detail["delivery"], 240)
        self.assertEqual(detail["goodFruit"], 176)
        self.assertEqual(detail["freshness"], 136)
        self.assertEqual(detail["time"], 8)
        self.assertEqual(detail["tasks"], 170)
        self.assertEqual(detail["total"], 730)

    def test_ice_box_and_fast_horse_apply_distinct_effects(self) -> None:
        engine = GameEngine(seed=1, duration_round=20)
        p = engine.players[1001]
        p.resources["ICE_BOX"] = 1
        p.freshness = 74
        engine.run_round({1001: [{"action": "USE_RESOURCE", "resourceType": "ICE_BOX"}], 1002: []})
        self.assertGreater(p.freshness, 83)
        self.assertEqual(p.resources.get("ICE_BOX", 0), 0)

        p.resources["FAST_HORSE"] = 1
        engine.run_round({1001: [{"action": "USE_RESOURCE", "resourceType": "FAST_HORSE"}], 1002: []})
        self.assertGreater(p.buffs.get("FAST_HORSE", 0), 0)
        self.assertEqual(p.move_per_frame(), 1200)

    def test_weather_distinguishes_water_routes(self) -> None:
        engine = GameEngine(seed=1, duration_round=20)
        engine.weather_events = [{"type": "HEAVY_RAIN", "region": "WATER", "startRound": 1, "durationRound": 5}]
        self.assertEqual(engine.weather_travel_multiplier("WATER", 1), 1350)
        self.assertEqual(engine.weather_travel_multiplier("ROAD", 1), 1000)
        self.assertEqual(engine.weather_fresh_multiplier("WATER", 1), 1.3)
        self.assertEqual(engine.weather_fresh_multiplier("ROAD", 1), 1.0)

    def test_replay_exposes_score_routes_and_task_tiers(self) -> None:
        engine = GameEngine(seed=1, duration_round=20)
        engine.run_round({1001: [], 1002: []})
        frame = engine.replay[-1]
        player = frame["players"][0]
        self.assertIn("scoreDetail", player)
        self.assertIn("roadRounds", player)
        self.assertIn("waterRounds", player)
        self.assertIn("weather", frame)
        self.assertTrue(frame["tasks"])
        task = frame["tasks"][0]
        self.assertIn("scoreTier", task)
        self.assertIn("routeBuckets", task)

    def test_forced_pass_against_guard_creates_pass_window(self) -> None:
        engine = GameEngine(seed=1, duration_round=20)
        engine.node_states["S02"].guard = Guard(
            owner_player_id=1002,
            owner_team_id="BLUE",
            defense=3,
            initial_defense=3,
            max_defense=6,
            complete_round=0,
            node_kind="NORMAL",
            first_weather_after=30,
            next_weather_round=30,
            order=1,
            active_from_round=1,
        )
        engine.run_round({
            1001: [{"action": "FORCED_PASS", "targetNodeId": "S02"}],
            1002: [],
        })
        self.assertEqual(len(engine.contests), 1)
        contest = next(iter(engine.contests.values()))
        self.assertEqual(contest.contest_type, "PASS")
        self.assertEqual(engine.players[1001].state, "CONTESTING")


if __name__ == "__main__":
    unittest.main()
