# rules_showcase

Display strategy for full rule visualization.

It reuses `direct_runner` with `RULES_SHOWCASE=1` and intentionally routes through:

- `S03` to claim and use `ICE_BOX`;
- `S04` to claim and use `SHORT_HORSE`;
- `S05` and `S05 -> S09` to exercise water route/process accounting;
- `S09` to claim and use `FAST_HORSE`;
- then `S14/S15` for verification and delivery.
